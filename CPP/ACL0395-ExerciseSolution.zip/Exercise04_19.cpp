#include <iostream>
#include <string>
using namespace std;

int main()
{
  cout << "Enter the first city: ";
  string s1, s2, s3;
  getline(cin, s1);

  cout << "Enter the second city: ";
  getline(cin, s2);
  
  cout << "Enter the third city: ";
  getline(cin, s3);

  if (s1 > s2)
  {
    // Swap s1 with s2
    string temp = s1;
    s1 = s2;
    s2 = temp;
  }
  
  if (s2 > s3)
  {
    // Swap s2 with s3
    string temp = s2;
    s2 = s3;
    s3 = temp;
  }  

  if (s1 > s2)
  {
    // Swap s1 with s2
    string temp = s1;
    s1 = s2;
    s2 = temp;
  }

  cout << "The three cities in alphabetical order are ";
  
  cout << s1 << " " << s2 << " " << s3 << endl;
  
  return 0;
}