#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  double pi = 1;
  int sign = 1;
    
  for (int i = 2; i <= 100000; i++) {
    sign = -sign;
    pi += sign / (2 * i - 1.0);
       
    if (i % 10000 == 0) {
      cout << "i: " << i << " The PI is " << setprecision(20) << showpoint << 4 * pi << endl;
	}
  }

  return 0;
}
