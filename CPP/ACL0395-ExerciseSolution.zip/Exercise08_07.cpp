#include <iostream>
#include <ctime> // for time function
#include <cstdlib> // for rand and srand functions
using namespace std;

int main()
{
  srand(time(0));
  const int SIZE = 4;
  int board[SIZE][SIZE];

  bool isSameOnARow = false, isSameOnAColumn = false,
    isSameOnADiagonal = false, isSameOnASubdiagonal = false;

  for (int i = 0; i < SIZE; i++)
  {
    for (int j = 0; j < SIZE; j++)
    {
      board[i] [j] = rand() % 2;
      cout << board[i][j];
    }

    cout << endl;
  }

  // Check rows
  for (int i = 0; i < SIZE; i++)
  {
    bool same = true;
    for (int j = 1; j < SIZE; j++)
    {
      if (board[i][0] != board[i][j])
      {
        same = false; break;
      }
    }

    if (same) {
      cout << "All " << board[i][0] << "'s on row " << i << endl;
      isSameOnARow = true;
    }
  }

  // Check columns
  for (int j = 0; j < SIZE; j++)
  {
    bool same = true;
    for (int i = 1; i < SIZE; i++)
    {
      if (board[0][j] != board[i][j])
      {
        same = false; break;
      }

    }
    if (same) {
      cout << "All " << board[0][j] << "'s on column " << j << endl;
      isSameOnAColumn = true;
    }
  }

  // Check major diagonal
  bool same = true;
  for (int i = 1; i < SIZE; i++)
  {
    if (board[0][0] != board[i][i])
    {
      same = false; break;
    }
  }

  if (same) {
    cout << "All " << board[0][0] << "'s on major diagonal" << endl;
    isSameOnADiagonal = true;
  }

  // Check subdiagonal
  same = true;
  for (int i = 1; i < SIZE; i++)
  {
    if (board[0][SIZE - 1] != board[i][SIZE - 1 - i])
    {
      same = false; break;
    }
  }

  if (same) {
    cout << "All " << board[0][SIZE - 1] << "'s on sub-diagonal" << endl;
    isSameOnASubdiagonal = true;
  }

  if (!isSameOnARow)
    cout << "No same numbers on the same row" << endl;


  if (!isSameOnAColumn)
    cout << "No same numbers on the same column" << endl;

  if (!isSameOnADiagonal)
    cout << "No same numbers on the same diagonal" << endl;

  if (!isSameOnASubdiagonal)
    cout << "No same numbers on the same subdiagonal" << endl;

  return 0;
}

