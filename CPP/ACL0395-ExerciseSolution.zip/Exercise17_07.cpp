#include <iostream>
using namespace std;

int count1 = 0;

long fib(long index)
{
  count1++;

  if (index == 0) // Base case
         return 0;
  else if (index == 1) // Base case
         return 1;
  else // Reduction and recursive calls
         return fib(index - 1) + fib(index - 2);
}

int main()
{
  int index;
  cout << "Enter an integer for index: ";
  cin >> index;
  fib(index);

  cout << "count is " << count1 << endl;

  return 0;
}
