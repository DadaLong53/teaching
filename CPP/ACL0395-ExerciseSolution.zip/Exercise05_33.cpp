#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  double deposit;
  cout << "Enter the initial deposit amount: ";
  cin >> deposit;

  double annualInterestRate;
  cout << "Enter annual percentage yield: ";
  cin >> annualInterestRate;
  double monthlyInterestRate = annualInterestRate / 1200;

  double numberOfMonths;
  cout << "Enter maturity period (number of months): ";
  cin >> numberOfMonths;

  cout << fixed << setprecision(2);
  cout << "Month\t\tCD Value\n";
  double currentValue = deposit;
  for (int i = 1; i <= numberOfMonths; i++) {
    currentValue = currentValue * (1 + monthlyInterestRate);
    cout << i << "\t\t" << currentValue << endl;
  }

  return 0;
}
