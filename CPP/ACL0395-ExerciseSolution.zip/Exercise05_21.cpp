#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

int main()
{
  int number = 0; // Number to print

  for (int row = 0; row <= 7; row++) {
    // Pad leading blanks
    for (int col = 1; col <= 7 - row; col++)
    cout << setw(5) << " ";

    // Print left half of the row
    for (int col = 0; col <= row; col++) {
      number = pow(2.0, col);

      // You can write a method in Chapter 4 for this section
      if (number > 100) {
        cout << "  " << number;
      }
      else if (number > 10) {
        cout << "   " << number;
      }
      else {
        cout << "    " << number;
      }
    }

    // Print the right half of the row
    for (int col = row - 1; col >= 0; col--) {
      number = pow(2.0, col);

      // You can write a method in Chapter 4 for this section
      if (number > 100) {
        cout << "  " << number;
      }
      else if (number > 10) {
        cout << "   " << number;
      }
      else {
        cout << "    " << number;
      }
    }

    // Start a new line
    cout << '\n';
  }

  return 0;
}
