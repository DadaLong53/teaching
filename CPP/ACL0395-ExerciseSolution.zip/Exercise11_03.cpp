#include <iostream>
using namespace std;

int* doubleCapacity(const int* list, int size)
{
  int* result = new int[2 * size];

  for (int i = 0; i < size; i++)
    *(result + i) = * (list + i);

  for (int i = size; i < 2 * size; i++)
    *(result + i) = 0;


  return result;
}

int main()
{
  int list[] =
  {
    1, 2, 3, 4, 5
  };

  int* newList = doubleCapacity(list, 5);

  for (int i = 0; i < 2 * 5; i++)
    cout << *(newList + i) << " ";

  return 0;
}
