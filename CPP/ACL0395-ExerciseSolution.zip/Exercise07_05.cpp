#include <iostream>
using namespace std;

int main()
{
  int numbers[10];
  int size = 0;

  cout << "Enter ten integers: ";
  for (int i = 0; i < 10; i++) {
    // Read and store numbers in an array if it is new
    int value;
    cin >> value;

    bool isInArray = false;

    for (int j = 0; j < size && !isInArray; j++)
      if (numbers[j] == value) {
        isInArray = true;
      }

    if (!isInArray) {
      numbers[size] = value;
      size++;
    }
  }

  cout << "The distinct numbers are: ";
  for (int i = 0; i < size; i++)
    cout << numbers[i] << " ";

  return 0;
}
