#include <iostream>
#include "Account.h"
using namespace std;

Account accounts[10];

void withdraw(int id)
{
  cout << "Enter an amount to withdraw: " << endl;
  int amount;
  cin >> amount;
  if (amount <= accounts[id].getBalance())
  {
    accounts[id].withdraw(amount);
  }
  else
  {
    cout << "The amount is too large, ignored";
  }
}

void deposit(int id)
{
  cout << "Enter an amount to deposit: " << endl;
  int amount;
  cin >> amount;
  if (amount >= 0)
  {
    accounts[id].deposit(amount);
  }
  else
  {
    cout << "The amount is negative, ignored";
  }
}

int getAChoice()
{
  int choice;

  while (true)
  {
    cout << "\nMain menu" << endl;
    cout << "1: check balance" << endl;
    cout << "2: withdraw" << endl;
    cout << "3: deposit" << endl;
    cout << "4: exit" << endl;
    cout << "Enter a choice: ";
    cin >> choice;
    if (choice < 1 || choice > 4)
    {
      cout << "Wrond choice, try again: " << endl;
    }
    else
    {
      break;
    }
  }

  return choice;
}

int main()
{
  for (int i = 0; i < 10; i++)
  {
    accounts[i].setId(i);
    accounts[i].setBalance(100);
  }

  while (true)
  {
    cout << "Enter an id: ";
    int id;
    cin >> id;
    if (id < 1 || id > 10)
    {
      cout << "Please enter a correct id" << endl;
    }

    bool sessionFinished = false;
    while (!sessionFinished)
    {
      int choice = getAChoice();
      switch (choice)
      {
        case 1:
          cout << "The balance is " << accounts[id].getBalance() << endl;
        break;
        case 2:
          withdraw(id);
        break;
        case 3:
          deposit(id);
        break;
        case 4:
          sessionFinished = true;
      }
    }
  }

  return 0;
}
