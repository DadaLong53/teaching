#include <iostream>
#include <cmath>
using namespace std;

int main()
{
  double investmentAmount, annualInterestRate, numberOfYears;
  cout << "Enter investment amount: ";
  cin >> investmentAmount;

  cout << "Enter annual interest rate: ";
  cin >> annualInterestRate;

  cout << "Enter number of years: ";
  cin >> numberOfYears;

  double monthlyInterestRate = annualInterestRate / 1200;

  double accumulatedValue =
    investmentAmount * pow(1 + monthlyInterestRate, numberOfYears * 12);

  cout << "Accumulated value is $" << accumulatedValue << endl;

  return 0;
}
