#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main()
{
  // Enter a source file
  cout << "Enter a source file name: ";
  string inputFilename;
  cin >> inputFilename;

  // Open input file
  ifstream input(inputFilename.c_str(), ios::binary);

  if (input.fail())
  {
    cout << inputFilename << " does not exist" << endl;
    cout << "Exit program" << endl;
    return 0;
  }

  ofstream output;

  cout << "Enter the number of bytes in each smaller file: ";
  int smallFileSize;
  cin >> smallFileSize;

  for (int i = 0; !input.eof(); i++)
  {
    char s[40];
    itoa(i, s, 10);
    string outputfilename = inputFilename + "." + s;
    output.open(outputfilename.c_str(), ios::binary);

    int count = 0;
    char ch[1024];
    while (!input.eof() && count <= smallFileSize) // Continue if not end of file
    {
      input.read(ch, 1024);
      output.write(ch, input.gcount());
      count += input.gcount();
    }

    cout << "File " << outputfilename << " produced " << endl;
    output.close();
  }

  input.close();
  cout << "\nSplit Done" << endl;

  return 0;
}
