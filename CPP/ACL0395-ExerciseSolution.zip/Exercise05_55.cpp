#include <iostream>
using namespace std;

int main()
{
  int choice;

  while (true) 
  {
    cout << "Main menu" << endl;
    cout << "1: Addition" << endl;
    cout << "2: Subtraction" << endl;
    cout << "3: Multiplication" << endl;
    cout << "4: Division" << endl;
    cout << "5: Exit" << endl;
    cout << "Enter a choice: ";
    cin >> choice;

    int number1 = rand() % 10;
    int number2 = rand() % 10;
    int answer;

    if (choice == 1)
    {
      cout << "What is " << number1 << " + " << number2 << "? ";
      cin >> answer;
      if (number1 + number2 == answer)
        cout << "Correct" << endl << endl;
      else
        cout << "Your answer is wrong. The correct answer is " << number1 + number2 << endl << endl;
    }
    else if (choice == 2)
    {
      if (number1 < number2) // Swap number1 with number2
      {
        int temp = number1;
        number1 = number2;
        number2 = temp;
      }

      cout << "What is " << number1 << " - " << number2 << "? ";
      cin >> answer;
      if (number1 - number2 == answer)
        cout << "Correct" << endl << endl;
      else
        cout << "Your answer is wrong. The correct answer is " << number1 - number2 << endl << endl;
    }
    else if (choice == 3)
    {
      cout << "What is " << number1 << " * " << number2 << "? ";
      cin >> answer;
      if (number1 * number2 == answer)
        cout << "Correct" << endl << endl;
      else
        cout << "Your answer is wrong. The correct answer is " << number1 * number2 << endl << endl;
    }
    else if (choice == 4)
    {
      while (number2 == 0) 
        number2 = rand() % 10;

      cout << "What is " << number1 << " / " << number2 << "? ";
      cin >> answer;
      if (number1 / number2 == answer)
        cout << "Correct" << endl << endl;
      else
        cout << "Your answer is wrong. The correct answer is " << number1 / number2 << endl << endl;
    }
    else if (choice == 5)
      break;
  }

  return 0;
}
