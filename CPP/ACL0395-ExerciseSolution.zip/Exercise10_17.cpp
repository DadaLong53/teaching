#include <iostream>
using namespace std;

class Location
{
public: 
  Location(int r, int c, double m)
  {
    row = r;
	column = c;
	maxValue = m;
  }
  int row;
  int column;
  double maxValue;
};

const int ROW_SIZE = 3;
const int COLUMN_SIZE = 4;
Location locateLargest(const double a[][COLUMN_SIZE])
{
  int row = 0;
  int column = 0;
  double maxValue = a[0][0];

  for (int i = 0; i < ROW_SIZE; i++)
    for (int j = 0; j < COLUMN_SIZE; j++)
      if (maxValue < a[i][j]) {
	    row = i;
		column = j;
	    maxValue = a[i][j];
	  }

  return Location(row, column, maxValue);
}

int main()
{
  double p[ROW_SIZE][COLUMN_SIZE];

  // Enter the two-dimensional array
  cout << "Enter a 3 by 4 two-dimensional array:";
  for (int i = 0; i < ROW_SIZE; i++)
    for (int j = 0; j < COLUMN_SIZE; j++)
      cin >> p[i][j];
 
  Location loc = locateLargest(p);
  
  cout << "The location of the largest element is " <<
  loc.maxValue << " at (" << loc.row << ", " << loc.column << ")" << endl;
 
  return 0;
}