#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Date
{
private:
  int year;
  int month;
  int day;

public:
  Date()
  {
    setDate(time(0));
  }

  Date(int elapseTime)
  {
    setDate(elapseTime);
  }

  Date(int y, int m, int d)
  {
    year = y;
    month = m;
    day = d;
  }

  setDate(int elapseTime)
  {
    long seconds = elapseTime;
    long minutes = seconds / 60;
    long hours = minutes / 60;
    day = hours / 24;

    // Get year
    year = 1970;
    while (day >= (isLeapYear(year) ? 366 : 365))
    {
      day = day - (isLeapYear(year) ? 366 : 365);
      year++;
    }

    // get month
    month = 1;
    while (day >= getNumberOfDaysInMonth(year, month))
    {
      day = day - getNumberOfDaysInMonth(year, month);
      month++;
    }
  }

  int getYear()
  {
    return year;
  }

  int getMonth()
  {
    return month;
  }

  int getDay()
  {
    return day;
  }

private:
  // Determine if it is a leap year
  bool isLeapYear(int year)
  {
    return year % 400 == 0 || (year % 4 == 0 && year % 100 != 0);
  }

  // Get the number of days in a month
  int getNumberOfDaysInMonth(int year, int month)
  {
    if (month == 1 || month == 3 || month == 5 || month == 7 ||
        month == 8 || month == 10 || month == 12)
      return 31;

    if (month == 4 || month == 6 || month == 9 || month == 11)
      return 30;

    if (month == 2) return isLeapYear(year) ? 29 : 28;

    return 0; // If month is incorrect
  }
};

class Transaction
{
private:
  Date date;
  char type;
  double amount;
  double balance;
  string description;

public:
  Transaction(char type, double amount, double balance,
      string description) {
    date = Date();
    this->type = type;
    this->amount = amount;
    this->balance = balance;
    this->description = description;
  }

  Date getDate()
  {
    return date;
  }

  char getType()
  {
    return type;
  }

  double getAmount()
  {
    return amount;
  }

  double getBalance()
  {
    return balance;
  }

  string getDescription()
  {
    return description;
  }
};

class Account
{
private:
  int id;
  double balance;
  static double annualInterestRate;
  string name;
  vector<Transaction> transactions;

public:
  Account();
  Account(string name, int id, double balance);
  string getName();
  int getId();
  double getBalance();
  static double getAnnualInterestRate();
  void setId(int id);
  void setBalance(double balance);
  static void setAnnualInterestRate(double newAnnualInterestRate);
  double getMonthlyInterest();
  void withdraw(double amount);
  void deposit(double amount);
  vector<Transaction> getTransactions();
};

double Account::annualInterestRate = 5.5;

Account::Account()
{
   id = 0;
   balance = 0;
   annualInterestRate = 0;
}

Account::Account(string name, int id, double balance)
{
  this->name = name;
  this->id = id;
  this->balance = balance;
}

vector<Transaction> Account::getTransactions()
{
  return transactions;
}

string Account::getName()
{
  return this->name;
}

int Account::getId()
{
  return this->id;
}

double Account::getBalance()
{
  return balance;
}

double Account::getAnnualInterestRate()
{
  return Account::annualInterestRate;
}

void Account::setId(int id)
{
  this->id = id;
}

void Account::setBalance(double balance)
{
  this->balance = balance;
}

void Account::setAnnualInterestRate(double newAnnualInterestRate)
{
  annualInterestRate = newAnnualInterestRate;
}

double Account::getMonthlyInterest()
{
  return balance * (annualInterestRate / 1200);
}

void Account::withdraw(double amount)
{
  balance -= amount;
  transactions.push_back(Transaction('W', amount, balance, ""));
}

void Account::deposit(double amount)
{
  balance += amount;
  transactions.push_back(Transaction('D', amount, balance, ""));
}

int main()
{
  Account::setAnnualInterestRate(5.5);

  Account account("George", 1122, 1000);
  account.deposit(30);
  account.deposit(40);
  account.deposit(50);

  account.withdraw(5);
  account.withdraw(4);
  account.withdraw(2);

  cout << "Name: " << account.getName() << endl;
  cout << "Annual interest rate: " << Account::getAnnualInterestRate() << endl;
  cout << "Balance: " << account.getBalance() << endl;

  vector<Transaction> v = account.getTransactions();

  cout << "Date" << "Type" << "Amount" << "Balance" << endl;

  for (int i = 0; i < v.size(); i++)
  {
    Transaction transaction = v[i];
    Date date = transaction.getDate();
    cout << date.getYear() << "/" << date.getMonth() << "/" << date.getDay()
      << " " << transaction.getType() << " " << transaction.getAmount()
      << " " << transaction.getBalance() << endl;
  }

  return 0;
}
