#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

void printChars(char ch1, char ch2, int numberPerLine)
{
  int count = 1;
  for (int i = ch1; i <= ch2; i++, count++)
    if (count % numberPerLine == 0)
      cout << (char)i << endl;
    else
      cout << (char)i;
}

int main()
{
  printChars('1', 'Z', 10);

  return 0;
}
