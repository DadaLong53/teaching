#include <iostream>
#include <vector>
using namespace std;

class StackOfIntegers
{
public:

StackOfIntegers::StackOfIntegers()
{
}

bool StackOfIntegers::empty()
{
  return v.empty();
}

int StackOfIntegers::peek()
{
  return v.at(v.size() - 1);
}

int StackOfIntegers::push(int value)
{
  v.push_back(value);
  return value;
}

int StackOfIntegers::pop()
{
  int temp = v.at(v.size() - 1);
  v.pop_back();
  return temp;
}

int StackOfIntegers::getSize()
{
  return v.size();
}

private:
  vector<int> v;
};

int main()
{
  StackOfIntegers s;
  s.push(1);
  s.push(2);

  while (!s.empty())
  {
    cout << s.pop() << endl;
  }

  return 0;
}
