#include <iostream>
#include <string>
using namespace std;

int main()
{
  cout << "Enter two characters: ";
  string s;
  cin >> s;

  if (s[0] == 'M')
    cout << "Mathematics ";
  else if (s[0] == 'C')
    cout << "Computer Science ";
  else if (s[1] == 'I')
    cout << "Information Technology ";
  else 
  {
    cout << "Invalid major code" << endl;
    exit(1);
  }

  if (s[1] == '1')
    cout << "Freshman" << endl;
  else if (s[1] == '2')
    cout << "Sophomore" << endl;
  else if (s[1] == '3')
    cout << "Junior" << endl;
  else if (s[1] == '4')
    cout << "Senior" << endl;
  else 
  {
    cout << "Invalid status code" << endl;
    exit(2);
  }

  return 0;
}