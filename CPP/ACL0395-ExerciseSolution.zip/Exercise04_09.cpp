#include <iostream>
using namespace std;

int main()
{
  cout << "Enter a character: ";
  char ch;
  cin >> ch;

  int code = static_cast<int>(ch);

  cout << "The ASCII code for the character is " << code << endl;

  return 0;
}
