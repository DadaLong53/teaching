#include <iostream>
using namespace std;

int main()
{
  cout << 4 * (1 - 1.0 / 3 + 1.0 / 5 - 1.0 / 7 +
        1.0 / 9 - 1.0 / 11 + 1.0 / 13) << endl;
  return 0;
}
