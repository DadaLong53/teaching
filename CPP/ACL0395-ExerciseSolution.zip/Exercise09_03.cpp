#include <iostream>
using namespace std;

class Account
{
private:
  int id;
  double balance;
  double annualInterestRate;

public:
  Account()
  {
     id = 0;
     balance = 0;
     annualInterestRate = 0;
  }

  Account(int id, double balance, double annualInterestRate)
  {
    this->id = id;
    this->balance = balance;
    this->annualInterestRate = annualInterestRate;
  }

  int getId()
  {
    return this->id;
  }

  double getBalance()
  {
    return balance;
  }

  double getAnnualInterestRate()
  {
    return annualInterestRate;
  }

  void setId(int id)
  {
    this->id = id;
  }

  void setBalance(double balance)
  {
    this->balance = balance;
  }

  void setAnnualInterestRate(double annualInterestRate)
  {
    this->annualInterestRate = annualInterestRate;
  }

  double getMonthlyInterest()
  {
    return balance * (annualInterestRate / 1200);
  }

  void withdraw(double amount)
  {
    balance -= amount;
  }

  void deposit(double amount)
  {
    balance += amount;
  }
};

int main()
{
  Account account(1122, 20000, 4.5);
  account.withdraw(2500);
  account.deposit(3000);
  cout << "Balance is " << account.getBalance() << endl;
  cout << "Monthly interest is " << account.getMonthlyInterest() << endl;

  return 0;
}
