#include <iostream>
using namespace std;

int main()
{
  cout << (9.5 * 4.5 - 2.5 * 3) / (45.5 - 3.5) << endl;

  return 0;
}
