#include <iostream>
using namespace std;

int main()
{
  cout << "Enter a degree in Celsius: ";
  double celsius;
  cin >> celsius;

  double fahrenheit = (9.0 / 5) * celsius + 32;
  cout << "Fahrenheit degree is " << fahrenheit;

  return 0;
}
