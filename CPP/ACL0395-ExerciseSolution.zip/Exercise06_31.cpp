#include <iostream>
using namespace std;

void sort(double& num1, double& num2, double& num3)
{
  if (num1 > num2)
  {
    double temp = num1;
    num1 = num2;
    num2 = temp;
  }

  if (num2 > num3)
  {
    double temp = num2;
    num2 = num3;
    num3 = temp;
  }

  if (num1 > num2)
  {
    double temp = num1;
    num1 = num2;
    num2 = temp;
  }
}

int main()
{
  double number1, number2, number3;
  cin >> number1 >> number2 >> number3;

  sort(number1, number2, number3);

  cout << "number1 is " << number1 << endl;
  cout << "number2 is " << number2 << endl;
  cout << "number3 is " << number3 << endl;

  return 0;
}