#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main()
{
  ofstream output;

  // Create a file
  output.open("Exercise13_1.txt", ios::out | ios::app);

  srand(time(0));

  for (int i = 0; i < 100; i++)
  {
    output << rand() << " ";
  }

  output.close();

  cout << "Done" << endl;

  return 0;
}
