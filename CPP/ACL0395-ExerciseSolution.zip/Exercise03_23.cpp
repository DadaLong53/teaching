#include <iostream>
using namespace std;

int main()
{
  cout << "Enter a point's x- and y-coordinates: ";
  double x, y;
  cin >> x >> y;

  if (x > 200 || x < 0 || y > 100 || y < 0)
    cout << "The point is not in the triangle" << endl;
  else
  {
    double slope = (200.0 - 0) / (0 - 100.0);
    double x1 = x + -y * slope;
    if (x1 <= 200)
      cout << "The point is in the triangle" << endl;
    else
      cout << "The point is not in the triangle" << endl;
  }

  return 0;
}
