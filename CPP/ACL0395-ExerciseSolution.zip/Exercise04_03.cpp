#include <iostream>
#include <cmath>
using namespace std;

int main()
{
  const double PI = 3.14159;

  double x1 = 35.2270869 * PI / 180, y1 = -80.8431267 * PI / 180; // Charlotte
  double x2 = 32.0835407 * PI / 180, y2 = -81.0998342 * PI / 180; // Savannah
  double x3 = 28.5383355 * PI / 180, y3 = -81.3792365 * PI / 180; // Orlando
  double x4 = 33.7489954 * PI / 180, y4 = -84.3879824 * PI / 180; // Atlanta

  double d1 = 6371.01 * acos(sin(x1) * sin(x2) +
      cos(x1) * cos(x2) * cos(y1 - y2));

  double d2 = 6371.01 * acos(sin(x3) * sin(x2 ) +
      cos(x3) * cos(x2) * cos(y3 - y2));

  double d3 = 6371.01 * acos(sin(x3) * sin(x4 ) +
      cos(x3) * cos(x4) * cos(y3 - y4));

  double d4 = 6371.01 * acos(sin(x1) * sin(x4 ) +
      cos(x1) * cos(x4) * cos(y1 - y4));

  double d5 = 6371.01 * acos(sin(x4) * sin(x2 ) +
      cos(x4) * cos(x2) * cos(y4 - y2));

  double s = (d1 + d4 + d5) / 2;
  double area1 = sqrt(s * (s - d1) * (s - d4) * (s - d5));

  s = (d2 + d3 + d5) / 2;
  double area2 = sqrt(s * (s - d2) * (s - d3) * (s - d5));

  cout << "The area is " << area1 + area2 << " square kilometers" << endl;
  
  return 0;
}

