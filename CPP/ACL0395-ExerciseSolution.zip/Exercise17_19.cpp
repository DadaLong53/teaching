#include <iostream>
using namespace std;

const int NUMBER_OF_QUEENS = 8;
int queens[NUMBER_OF_QUEENS];

bool isValid(int row, int column)
{
  for (int i = 1; i <= row; i++)
    if (queens[row - i] == column          // Check column
        || queens[row - i] == column - i   // diagonal to upper left
        || queens[row - i] == column + i)  // diagonal to upper right
      return false;
  return true;
}

void printResult()
{
  static count = 0;
  cout << "Solution " << ++count << ":\n---------------------------------\n";
  for (int row = 0; row < NUMBER_OF_QUEENS; row++)
  {
    for (int column = 0; column < NUMBER_OF_QUEENS; column++)
      printf(column == queens[row] ? "| Q " : "|   ");
    cout << "|\n---------------------------------\n";
  }
}

void search(int row)
{
  for (int column = 0; column < NUMBER_OF_QUEENS; column++)
  {
    queens[row] = column;
    if (isValid(row, column))
      if (row < NUMBER_OF_QUEENS - 1)
        search(row + 1);
      else
      {
        printResult();
      }
  }
}

int main()
{
  search(0); // Start search from row 0. Note row indices are 0, 1, 2, 3, ..., 7

  return 0;
}
