#include <iostream>
using namespace std;

int main()
{
  cout << "  CCCC    +        +     " << endl;  
  cout << " C        +        +     " << endl;
  cout << "C      +++++++  +++++++  " << endl;
  cout << " C        +        +     " << endl;
  cout << "  CCCC    +        +     " << endl;

  return 0;
}
