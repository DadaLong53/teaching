#include <iostream>
#include <string>
using namespace std;

void displayPermuation(const string& s1, const string& s2)
{
  if (s2.size() > 0)
  {
    for (unsigned i = 0; i < s2.size(); i++)
    {
      string t1 = s1 + s2[i];
      string t2 = s2.substr(0, i) + s2.substr(i + 1);
      displayPermuation(t1, t2);
    }
  }
  else
    cout << s1 << endl;
}

void displayPermuation(string s)
{
  displayPermuation("", s);
}

int main()
{
  cout << "Enter a string: ";
  string s;
  getline(cin, s);

  displayPermuation(s);

  return 0;
}
