#include <iostream>
using namespace std;

int largest(int list[], int high)
{
  if (high == 0)
  {
    return list[0];
  }
  else
  {
    return max(largest(list, high - 1), list[high]);
  }
}

int main()
{
  cout << "Enter 8 integers: ";
  int list[8];
  for (int i = 0; i < 8; i++)
  {
    cin >> list[i];
  }

  cout << largest(list, 8 - 1);

  return 0;
}
