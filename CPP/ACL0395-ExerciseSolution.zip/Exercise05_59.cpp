#include <iostream>
#include <string> 
#include <ctime> // for time function
#include <cstdlib> // for rand and srand functions
using namespace std;

int main()
{
  srand(time(0));

  string vehiclePlateNumber;    
  for (int i = 0; i < 7; i++) 
  {
    char ch = rand() % 2 == 0 ? 
      'A' + rand() % ('Z' - 'A' + 1) : '0' + rand() % 10;
    vehiclePlateNumber += ch;
  }

  cout << vehiclePlateNumber << endl;

  return 0;
}