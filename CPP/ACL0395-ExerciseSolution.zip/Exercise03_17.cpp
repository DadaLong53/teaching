#include <iostream>
#include <cmath>
using namespace std;

int main()
{
  // Enter the temperature in Fahrenheit
  cout << "Enter the temperature in Fahrenheit: ";
  double fahrenheit;
  cin >> fahrenheit;

  if (fahrenheit < -58 || fahrenheit > 41)
  {
    cout << "Temperature must be between -58�F and 41�";
    return 0;
  }

  // Enter the wind speed miles per hour
  cout << "Enter the wind speed miles per hour: ";
  double speed;
  cin >> speed;

  if (speed < 2)
  {
    cout << "Speed must be greater than or equal to 2";
    return 0;
  }

  // Compute wind chill index
  double windChillIndex = 35.74 + 0.6215 * fahrenheit - 35.75 *
    pow(speed, 0.16) + 0.4275 * fahrenheit * pow(speed, 0.16);

  // Display the result
  cout << "The wind chill index is " << windChillIndex << endl;

  return 0;
}
