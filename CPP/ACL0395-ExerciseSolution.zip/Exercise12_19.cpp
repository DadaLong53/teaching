#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include <cctype>
#include <ctime>
#include "ImprovedStack.h"

using namespace std;

const int NUMBER_OF_CARDS = 52;

// Test if list1 and list2 are identical
bool equal(int list1[], int list2[], int size);

void displayRank(int rank);

void displaySuit(int suit);

// Sort an array
void sort(int list[], int listSize);

// Split an expression into numbers, operators, and parenthese
vector<string> split(const string &expression);

// Evaluate an expression and return the result
double evaluateExpression(const string &expression);

// Perform an operation
void processAnOperator(
  Stack<double> &operandStack, Stack<char> &operatorStack);

// Find a solution for the cards shown
bool findSolution(int a, int b, int c, int d, string &solution);

vector<string> extractNumbers(const string &expression)
{
  vector<string> v; // A vector to store numbers as strings
  string numberString; // A numeric string

  for (int i = 0; i < expression.length(); i++)
  {
    if (isdigit(expression[i]))
      numberString.append(1, expression[i]); // Append a digit
    else
    {
      if (numberString.size() > 0)
      {
        v.push_back(numberString); // Store the numeric string
        numberString.erase(); // Empty the numeric string
      }
    }
  }

  // Store the last numeric string
  if (numberString.size() > 0)
    v.push_back(numberString);

  return v;
}

// Extract four string int numbers into an array of integers
void toArray(const vector<string> extractNumbers, int numbers[])
{
  for (int i = 0; i < extractNumbers.size(); i++)
    numbers[i] = atoi(extractNumbers[i].c_str());
}

int main()
{
  int deck[NUMBER_OF_CARDS];

  // Initialize cards
  for (int i = 0; i < NUMBER_OF_CARDS; i++)
    deck[i] = i;

  // Shuffle the cards
  srand(time(0));
  for (int i = 0; i < NUMBER_OF_CARDS; i++)
  {
    // Generate an index randomly
    int index = rand() % NUMBER_OF_CARDS;
    int temp = deck[i];
    deck[i] = deck[index];
    deck[index] = temp;
  }

  // Display the first four cards
  for (int i = 0; i < 4; i++)
  {
    cout << deck[i] << ": ";
    displayRank(deck[i] % 13);
    displaySuit(deck[i] / 13);
  }

  string expression;
  cout << "Enter an expression: ";
  getline(cin, expression);

  vector<string> v = extractNumbers(expression);

  if (v[0][0] != '0' && v.size() != 4)
  {
    cout << "Incorrect: must have four numbers in the expression" << endl;
    return 0;
  }

  int numbers[4];
  toArray(v, numbers);

  sort(numbers, 4);

  // Get four card values
  int fourCardValues[4];
  for (int i = 0; i < 4; i++)
  {
    fourCardValues[i] = deck[i] % 13 + 1;
  }

  sort(fourCardValues, 4);

  if (v[0][0] != '0' && !equal(numbers, fourCardValues, 4))
  {
    cout << "Incorrect: must use each of the four numbers once and only once" << endl;
    return 0;
  }

  int result = evaluateExpression(expression);
  if (result == 24)
    cout << "Correct: congratulations! you got it!" << endl;
  else {
    int a = fourCardValues[0];
    int b = fourCardValues[1];
    int c = fourCardValues[2];
    int d = fourCardValues[3];
    string solution;
    bool found = findSolution(a, b, c, d, solution);

    if (result == 0 && !found)
      cout << "Correct: no solutions" << endl;
    else if (result == 0 && found)
      cout << "Incorrect: the soltuon is " << solution << endl;
    else if (result != 0 && !found)
      cout << "Incorrect: the cards have no solutions " << endl;
    else // (result != 0 && found)
      cout << "Incorrect: the solution is " << solution << endl;
  }

  return 0;
}

vector<string> split(const string &expression)
{
  vector<string> v; // A vector to store split items as strings
  string numberString; // A numeric string

  for (int i = 0; i < expression.length(); i++)
  {
    if (isdigit(expression[i]))
      numberString.append(1, expression[i]); // Append a digit
    else
    {
      if (numberString.size() > 0)
      {
        v.push_back(numberString); // Store the numeric string
        numberString.erase(); // Empty the numeric string
      }

      if (!isspace(expression[i]))
      {
        string s;
        s.append(1, expression[i]);
        v.push_back(s); // Store an operator and parenthese
      }
    }
  }

  // Store the last numeric string
  if (numberString.size() > 0)
    v.push_back(numberString);

  return v;
}

// Evaluate an expression
double evaluateExpression(const string &expression)
{
  // Create operandStack to store operands
  Stack<double> operandStack;

  // Create operatorStack to store operators
  Stack<char> operatorStack;

  // Extract operands and operators
  vector<string> tokens = split(expression);

  // Phase 1: Scan tokens
  for (int i = 0; i < tokens.size(); i++)
  {
    if (tokens[i][0] == '+' || tokens[i][0] == '-')
    {
      // Process all +, -, *, / in the top of the operator stack
      while (!operatorStack.empty() && (operatorStack.peek() == '+'
       || operatorStack.peek() == '-' || operatorStack.peek() == '*'
       || operatorStack.peek() == '/'))
      {
        processAnOperator(operandStack, operatorStack);
      }

      // Push the + or - operator into the operator stack
      operatorStack.push(tokens[i][0]);
    }
    else if (tokens[i][0] == '*' || tokens[i][0] == '/')
    {
      // Process all *, / in the top of the operator stack
      while (!operatorStack.empty() && (operatorStack.peek() == '*'
        || operatorStack.peek() == '/'))
      {
        processAnOperator(operandStack, operatorStack);
      }

      // Push the * or / operator into the operator stack
      operatorStack.push(tokens[i][0]);
    }
    else if (tokens[i][0] == '(')
    {
      operatorStack.push('('); // Push '(' to stack
    }
    else if (tokens[i][0] == ')')
    {
      // Process all the operators in the stack until seeing '('
      while (operatorStack.peek() != '(')
      {
        processAnOperator(operandStack, operatorStack);
      }

      operatorStack.pop(); // Pop the '(' symbol from the stack
    }
    else
    { // An operand scanned. Push an operand to the stack as integer
      operandStack.push(atoi(tokens[i].c_str()));
    }
  }

  // Phase 2: process all the remaining operators in the stack
  while (!operatorStack.empty())
  {
    processAnOperator(operandStack, operatorStack);
  }

  // Return the result
  return operandStack.pop();
}

// Process one opeator: Take an operator from operatorStack and
// apply it on the operands in the operandStack
void processAnOperator(
    Stack<double> &operandStack, Stack<char> &operatorStack)
{
  char op = operatorStack.pop();
  double op1 = operandStack.pop();
  double op2 = operandStack.pop();
  if (op == '+')
    operandStack.push(op2 + op1);
  else if (op == '-')
    operandStack.push(op2 - op1);
  else if (op == '*')
    operandStack.push(op2 * op1);
  else if (op == '/')
    operandStack.push(op2 / op1);
}

void sort(int list[], int listSize)
{
  for (int i = 0; i < listSize; i++)
  {
    // Find the minimum in the list[i..listSize-1]
    int currentMin = list[i];
    int currentMinIndex = i;

    for (int j = i + 1; j < listSize; j++)
    {
      if (currentMin > list[j])
      {
        currentMin = list[j];
        currentMinIndex = j;
      }
    }

    // Swap list[i] with list[currentMinIndex] if necessary;
    if (currentMinIndex != i)
    {
      list[currentMinIndex] = list[i];
      list[i] = currentMin;
    }
  }
}

bool equal(int list1[], int list2[], int size)
{
  for (int i = 0; i < size; i++)
    if (list1[i] != list2[i])
      return false;

  return true;
}

void displayRank(int rank)
{
  if (rank == 0)
    cout << "Ace of ";
  else if (rank == 10)
    cout << "Jack of ";
  else if (rank == 11)
    cout << "Queen of ";
  else if (rank == 12)
    cout << "King of ";
  else
    cout << rank + 1 << " of ";
}

void displaySuit(int suit)
{
  if (suit == 0)
    cout << "Spades" << endl;
  else if (suit == 1)
    cout << "Hearts" << endl;
  else if (suit == 2)
    cout << "Diamonds" << endl;
  else if (suit == 3)
    cout << "Clubs" << endl;
}

/* Finds a solution for the cards shown */
bool findSolution(int a, int b, int c, int d, string &solution)
{
  solution = "No solution";
  char operators[] = {'+', '-', '*', '/'};

  int allCombinations[][4] = { { a, b, c, d }, { d, a, b, c },
      { c, d, a, b }, { b, c, d, a }, { a, b, d, c }, { c, a, b, d },
      { d, c, a, b }, { b, d, c, a }, { a, d, c, b }, { b, a, d, c },
      { c, b, a, d }, { d, c, b, a }, { a, c, b, d }, { d, a, c, b },
      { b, d, a, c }, { c, b, d, a }, { b, a, c, d }, { d, b, a, c },
      { c, d, b, a }, { a, c, d, b }, { a, d, b, c }, { c, a, d, b },
      { b, c, a, d }, { d, b, c, a } };

  for (int i1 = 0; i1 < 4; i1++)
    for (int i2 = 0; i2 < 4; i2++)
      for (int i3 = 0; i3 < 4; i3++)
        for (int row = 0; row < 24; row++)
          for (int i = 0; i < 3; i++)
            for (int j = 0; j < 5; j++)
            {
              char firstOp = operators[i1];
              char secondOp = operators[i2];
              char thirdOp = operators[i3];

              if (i == 0) {
                if (j == 0) {
                  stringstream ss;
                  ss << allCombinations[row][0] << firstOp
                      <<  allCombinations[row][1] << secondOp
                      <<  allCombinations[row][2] << thirdOp
                      << allCombinations[row][3];
                  solution = ss.str();
                  if (evaluateExpression(solution) == 24) {
                    return true;
                  }
                } else if (j == 1) {
                  stringstream ss;
                  ss << "(" << allCombinations[row][0] << firstOp
                      << allCombinations[row][1] << ")" << secondOp
                      << allCombinations[row][2] << thirdOp
                      << allCombinations[row][3];
                      solution = ss.str();
                  if (evaluateExpression(solution) == 24)
                    return true;
                } else if (j == 2) {
                  stringstream ss;
                  ss << allCombinations[row][0] << firstOp << "("
                      << allCombinations[row][1] << secondOp
                      << allCombinations[row][2] << ")" << thirdOp
                      << allCombinations[row][3];
                      solution = ss.str();
                  if (evaluateExpression(solution) == 24)
                    return true;
                } else if (j == 3) {
                  stringstream ss;
                  ss << allCombinations[row][0] << firstOp
                      << allCombinations[row][1] << secondOp << "("
                      << allCombinations[row][2] << thirdOp
                      << allCombinations[row][3] << ")";
                      solution = ss.str();
                  if (evaluateExpression(solution) == 24)
                    return true;
                } else if (j == 4) {
                  stringstream ss;
                  ss << "(" << allCombinations[row][0] << firstOp
                      << allCombinations[row][1] << ")" << secondOp
                      << "(" << allCombinations[row][2] << thirdOp
                      << allCombinations[row][3] << ")";
                      solution = ss.str();
                  if (evaluateExpression(solution) == 24)
                    return true;
                }
              } else if (i == 1) {
                if (j == 0) {
                  stringstream ss;
                  ss << "(" << allCombinations[row][0] << firstOp
                     << allCombinations[row][1] << secondOp
                     << allCombinations[row][2] << ")" << thirdOp
                     << allCombinations[row][3];
                     solution = ss.str();
                  if (evaluateExpression(solution) == 24)
                    return true;
                } else if (j == 1) {
                  stringstream ss;
                  ss << "((" << allCombinations[row][0] << firstOp
                     << allCombinations[row][1] << ")" << secondOp
                     << allCombinations[row][2] << ")" << thirdOp
                     << allCombinations[row][3];
                     solution = ss.str();
                  if (evaluateExpression(solution) == 24)
                    return true;
                } else if (j == 2) {
                  stringstream ss;
                  ss << "(" << allCombinations[row][0] << firstOp
                     << "(" << allCombinations[row][1] << secondOp
                     << allCombinations[row][2] << "))" << thirdOp
                     << allCombinations[row][3];
                     solution = ss.str();
                  if (evaluateExpression(solution) == 24)
                    return true;
                }
              } else if (i == 2) {
                if (j == 0) {
                  stringstream ss;
                  ss << allCombinations[row][0] << firstOp << "("
                     << allCombinations[row][1] << secondOp
                     << allCombinations[row][2] << thirdOp
                     << allCombinations[row][3] << ")";
                      solution = ss.str();
                  if (evaluateExpression(solution) == 24)
                    return true;

                } else if (j == 1) {
                  stringstream ss;
                  ss << allCombinations[row][0] << firstOp << "(("
                     << allCombinations[row][1] << secondOp
                     << allCombinations[row][2] << ")" << thirdOp
                     << allCombinations[row][3] << ")";
                      solution = ss.str();
                  if (evaluateExpression(solution) == 24)
                    return true;

                } else if (j == 2) {
                  stringstream ss;
                  ss << allCombinations[row][0] << firstOp << "("
                     << allCombinations[row][1] << secondOp << "("
                     << allCombinations[row][2] << thirdOp
                     << allCombinations[row][3] << "))";
                      solution = ss.str();
                  if (evaluateExpression(solution) == 24)
                    return true;
                }
              }
            }

  return false;
}
