#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

bool isPrime(int num)
{
  if ((num == 1) || (num == 2))
  {
    return true;
  }

  for (int i = 2; i <= num / 2; i++)
  {
    if (num % i == 0)
      return false;
  }

  return true;
}

int reversal(int num)
{
  int result = 0;

  while (num != 0)
  {
    long lastDigit = num % 10;
    result = result * 10 + lastDigit;
    num = num / 10;
  }

  return result;
}

bool isPalindrome(int num)
{
  return num == reversal(num);
}

int main()
{
  int beginTime = time(0);

  for (int p = 2; p <= 31; p++)
  {
    int i = pow(2.0, p) - 1;

    // Display each number in five positions
    if (isPrime(i))
    {
      cout << setw(7) << p;
      cout << setw(12) << i << endl;
    }
  }

  int endTime = time(0);
  cout << "time is " << (endTime - beginTime) << " seconds" << endl;

  return 0;
}
