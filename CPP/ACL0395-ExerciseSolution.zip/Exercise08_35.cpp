#include <iostream>
using namespace std;

const int N = 6;

bool isEvenParity(int matrix[][6]) 
{
  for (int i = 0; i < N; i++) 
  {
    int sum = 0;

    for (int j = 0; j < N; j++)
      sum += matrix[i][j];

    if (sum % 2 != 0)
      return false;
  }
    
  for (int j = 0; j < N; j++) 
  {
    int sum = 0;
    for (int i = 0; i < N; i++)
      sum += matrix[i][j];
    if (sum % 2 != 0)
      return false;
  }
        
  return true;  
}
  
void locateACell(int matrix[][6], int result[] ) 
{
  for (int i = 0; i < N; i++) {
    int sum = 0;
    for (int j = 0; j < N; j++)
      sum += matrix[i][j];
    if (sum % 2 != 0) 
    {
      result[0] = i;
      break;
    }
  }
    
  for (int j = 0; j < N; j++) 
  {
    int sum = 0;
    for (int i = 0; i < N; i++)
      sum += matrix[i][j];
    if (sum % 2 != 0) {
      result[1] = j;
      break;
    }
  }
}

int main()
{
  int matrix[6][6];
    
  // Prompt the user for input
  cout << "Enter a 6-by-6 matrix: ";
  for (int i = 0; i < N; i++) 
  {
    for (int j = 0; j < N; j++)
    {
      cin >> matrix[i][j];
    }
  }
    
  if (isEvenParity(matrix))
    cout << "All rows and columns are even" << endl;
  else {
    int location[2];
    locateACell(matrix, location);
    cout << "The first row and column where the parity is violated is at ("
      << location[0] << ", " << location[1] << ")" << endl; 
  }

  return 0;
}
