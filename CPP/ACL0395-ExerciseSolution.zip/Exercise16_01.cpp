#include<iostream>
#include<stdexcept>
#include<string>
#include<cctype>
using namespace std;

int hex2Dec(const string& hexString);
int convertHexToDec(char ch);

int hex2Dec(const string& hexString) 
{
  int value = 0; 
  for (unsigned int i = 0; i < hexString.size(); i++)
     value = value * 16 + convertHexToDec(toupper(hexString[i]));
  return value;
}

int convertHexToDec(char ch)
{ 
  if (ch >= 'A' && ch <= 'F')
    return 10 + (ch - 'A');
  else if (ch <= '9' && ch >= '0')
    return ch - '0';
  else
    throw invalid_argument("Invalid hex number");
}

int main()
{
  string hexString;
	
  try
  {
    cout << "Enter a hexadecimal number: ";
    cin >> hexString;
    cout << hex2Dec(hexString) << endl;
  }
  catch(invalid_argument& ex)
  {
    cout << ex.what() << endl;
  }

  return 0;
}
