#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

int numberOfDaysInAYear(int year);
bool isLeapYear(int year);

int main()
{
  for (int year = 2000; year <= 2010; year++)
  {
    cout << year << " has " << numberOfDaysInAYear(year) << endl;
  }

  return 0;
}

int numberOfDaysInAYear(int year)
{
  if (isLeapYear(year))
  {
    return 366;
  }
  else
  {
    return 365;
  }
}

/** Determine if it is a leap year */
bool isLeapYear(int year)
{
  return year % 400 == 0 || (year % 4 == 0 && year % 100 != 0);
}
