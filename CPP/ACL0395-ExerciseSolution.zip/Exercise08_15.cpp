#include <iostream>
using namespace std;

const int SIZE = 2;

void displayMatrix(double A[][SIZE])
{
  for (int i = 0; i < SIZE; i++)
  {
    for (int j = 0; j < SIZE; j++)
      cout << A[i][j] << " ";
    cout << endl;
  }
}

void inverse(double A[][SIZE], double inverseOfA[][SIZE])
{
  double determinant = A[0][0] * A[1][1] - A[0][1] * A[1][0];
  inverseOfA[0][0] = A[1][1] / determinant;
  inverseOfA[0][1] = -A[0][1] / determinant;
  inverseOfA[1][0] = -A[1][0] / determinant;
  inverseOfA[1][1] = A[0][0] / determinant;
}

int main()
{
  double A[SIZE][SIZE];
  cout << "Enter a, b, c, d: ";
  cin >> A[0][0] >> A[0][1] >> A[1][0] >> A[1][1];

  if (A[0][0] * A[1][1] - A[0][1] * A[1][0] == 0)
    cout << "No inverse matrix" << endl;
  else
  {
    double inverseA[SIZE][SIZE];
    inverse(A, inverseA);
    displayMatrix(inverseA);
  }

  return 0;
}
