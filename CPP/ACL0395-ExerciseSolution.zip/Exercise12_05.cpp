#include <iostream>
#include <string>
using namespace std;

template<typename T>
void swap1(T& var1, T& var2)
{
  T temp = var1;
  var1 = var2;
  var2 = temp;
}

int main()
{
  int v1 = 1;
  int v2 = 2;
  swap1(v1, v2);
  cout << v1 << " " << v2 << endl;

  double d1 = 1;
  double d2 = 2;
  swap1(d1, d2);
  cout << d1 << " " << d2 << endl;

  string s1 = "AB";
  string s2 = "CD";
  swap1(s1, s2);
  cout << s1 << " " << s2 << endl;

  return 0;
}
