#include <iostream>
#include <string>
using namespace std;

void reverseDisplay(const string& s)
{
  if (s.size() > 0)
  {
    cout << s[s.size() - 1];
    reverseDisplay(s.substr(0, s.size() - 1));
  }
}

int main()
{
  cout << "Enter a string: ";
  string s;
  cin >> s;

  reverseDisplay(s);

  return 0;
}
