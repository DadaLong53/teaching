#include <iostream>
using namespace std;

const int SIZE = 3;

bool equals(const int m1[][SIZE], const int m2[][SIZE]);
void selectionSort(int list[], int listSize);

int main()
{
  cout << "Enter m1 (a 3 by 3 matrix) row by row: ";
  int m1[SIZE][SIZE];
    
  for (int i = 0; i < SIZE; i++)
    for (int j = 0; j < SIZE; j++)
      cin >> m1[i][j];

  cout << "Enter m2 (a 3 by 3 matrix) row by row: ";
  int m2[SIZE][SIZE];
    
  for (int i = 0; i < SIZE; i++)
    for (int j = 0; j < SIZE; j++)
      cin >> m2[i][j];

  if (equals(m1, m2))
    cout << "The two arrays are equal" << endl;
  else
    cout << "The two arrays are not equal" << endl;

  return 0;
}

bool equals(const int m1[][SIZE], const int m2[][SIZE])
{
  int temp1[SIZE * SIZE];
  int temp2[SIZE * SIZE];
  	
  int k = 0;
  for (int i = 0; i < SIZE; i++) 
    for (int j = 0; j < SIZE; j++)
  	  temp1[k++] = m1[i][j];
  		
  k = 0;
  for (int i = 0; i < SIZE; i++) 
  	for (int j = 0; j < SIZE; j++)
  	  temp2[k++] = m2[i][j];
  		
  selectionSort(temp1, SIZE * SIZE);
  selectionSort(temp2, SIZE * SIZE);
  		
  for (int i = 0; i < SIZE * SIZE; i++)
    if (temp1[i] != temp2[i])
      return false;
  		
  return true;
}

void selectionSort(int list[], int listSize)
{
  for (int i = 0; i < listSize; i++)
  {
    // Find the minimum in the list[i..listSize-1]
    int currentMin = list[i];
    int currentMinIndex = i;

    for (int j = i + 1; j < listSize; j++)
    {
      if (currentMin > list[j])
      {
        currentMin = list[j];
        currentMinIndex = j;
      }
    }

    // Swap list[i] with list[currentMinIndex] if necessary;
    if (currentMinIndex != i)
    {
      list[currentMinIndex] = list[i];
      list[i] = currentMin;
    }
  }
}