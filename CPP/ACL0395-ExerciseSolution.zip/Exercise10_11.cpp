#include <iostream>
#include <cmath>
using namespace std;

class Loan
{
public:
  Loan();
  Loan(double newAnnualInterestRate, int newNumberOfYears, double newLoanAmount);
  double getAnnualInterestRate() const;
  int getNumberOfYears() const;
  double getLoanAmount() const;
  void setAnnualInterestRate(double newAnnualInterestRate);
  void setNumberOfYears(int newNumberOfYears);
  void setLoanAmount(double newLoanAmount);
  double getMonthlyPayment() const;
  double getTotalPayment() const;
  static double getMonthlyPayment(double annualInterestRate, int numberOfYears, double loanAmount);
  static double getTotalPayment(double annualInterestRate, int numberOfYears, double loanAmount);

private:
  double annualInterestRate;
  int numberOfYears;
  double loanAmount;
};

Loan::Loan()
{
  annualInterestRate = 9.5;
  numberOfYears = 30;
  loanAmount = 100000;
}

Loan::Loan(double newAnnualInterestRate, int newNumberOfYears, double newLoanAmount) 
{
  annualInterestRate = newAnnualInterestRate;
  numberOfYears = newNumberOfYears;
  loanAmount = newLoanAmount;
}

double Loan::getAnnualInterestRate() const
{
  return annualInterestRate;
}

int Loan::getNumberOfYears() const
{
  return numberOfYears;
}

double Loan::getLoanAmount() const
{
  return loanAmount;
}

void Loan::setAnnualInterestRate(double newAnnualInterestRate)
{
  annualInterestRate = newAnnualInterestRate;
}

void Loan::setNumberOfYears(int newNumberOfYears)
{
  numberOfYears = newNumberOfYears;
}

void Loan::setLoanAmount(double newLoanAmount)
{
  loanAmount = newLoanAmount;
}

double Loan::getMonthlyPayment() const
{
  double monthlyInterestRate = annualInterestRate / 1200;
  return loanAmount * monthlyInterestRate / (1 - (pow(1 / (1 + monthlyInterestRate), numberOfYears * 12)));
}

double Loan::getTotalPayment() const
{
  return getMonthlyPayment() * numberOfYears * 12;
}

double Loan::getMonthlyPayment(double annualInterestRate, int numberOfYears, double loanAmount)
{
  double monthlyInterestRate = annualInterestRate / 1200;
  return loanAmount * monthlyInterestRate / (1 - (pow(1 / (1 + monthlyInterestRate), numberOfYears * 12)));
}

double Loan::getTotalPayment(double annualInterestRate, int numberOfYears, double loanAmount)
{
  return Loan::getMonthlyPayment(annualInterestRate, numberOfYears, loanAmount) * numberOfYears * 12;
}

int main()
{
  Loan loan1(7.5, 15, 100000);
  cout << "Monthly payment: " << loan1.getMonthlyPayment() << endl;
  cout << "Total payment: " << loan1.getTotalPayment() << endl;

  cout << "Monthly payment: " << Loan::getMonthlyPayment(7.5, 15, 100000) << endl;
  cout << "Total payment: " << Loan::getTotalPayment(7.5, 15, 100000) << endl;

  return 0;
}