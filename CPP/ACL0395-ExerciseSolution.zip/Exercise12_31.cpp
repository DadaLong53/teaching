#include <iostream>
#include <string>
#include <vector>
using namespace std;

template<typename T>
int indexOf(vector<T> v, T name) 
{
  for (int i = 0; i < v.size(); i++)
    if (v[i] == name)
      return i;
    
  return -1;
}

template<typename T>
vector<T> intersection(const vector<T>& v1, const vector<T>& v2)
{
  vector<T> v;
  for (int i = 0; i < v1.size(); i++)
    if (indexOf(v2, v1[i]) >= 0)
      v.push_back(v1[i]);

  return v;
}

int main()
{
  cout << "Enter five strings for vector1: ";
  string s;
  vector<string> v1;
  for (int i = 0; i < 5; i++)
  {
    cin >> s;
    v1.push_back(s);
  }

  cout << "Enter five strings for vector2: ";
  vector<string> v2;
  for (int i = 0; i < 5; i++)
  {
    cin >> s;
    v2.push_back(s);
  }

  vector<string> v = intersection(v1, v2);
  cout << "The common strings are ";
  for (int i = 0; i < v.size(); i++)
    cout << v[i] << " ";

  cout << endl;

  return 0;
}
