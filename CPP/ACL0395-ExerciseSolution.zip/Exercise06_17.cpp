#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

bool isValid(
  double side1, double side2, double side3) {
  return (side1 + side2 > side3) &&
    (side1 + side3 > side2) && (side2 + side3 > side1);
}

double area(
  double side1, double side2, double side3) {
  double s = (side1 + side2 + side3) / 2;
  return sqrt(s * (s - side1) * (s - side2) * (s - side3));
}

int main()
{
  // Enter the first edge
  cout << "Enter the first edge length (double): ";
  double edge1;
  cin >> edge1;

  // Enter the second edge
  cout << "Enter the second edge length (double): ";
  double edge2;
  cin >> edge2;

  // Enter the third edge
  cout << "Enter the third edge length (double): ";
  double edge3;
  cin >> edge3;

  // Display results
  bool valid = (edge1 + edge2 > edge3) &&
    (edge1 + edge3 > edge2) && (edge2 + edge3 > edge1);

  if (valid) {
    cout << "The are of the triangle is " <<
      area(edge1, edge2, edge3) << endl;
  }
  else
    cout << "Input is invalid" << endl;

  return 0;
}
