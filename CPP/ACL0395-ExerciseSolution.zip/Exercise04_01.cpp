#include <iostream>
#include <cmath>
using namespace std;

int main()
{
  const double PI = 3.14159;
  cout << "Enter the length from the center to a vertex: ";
  double length;
  cin >> length;

  double side = 2 * length * sin(PI / 5);
  double area = 5 * side * side / (4 * tan(PI / 5));

  cout << "The area of the pentagon is " << area << endl;

  return 0;
}
