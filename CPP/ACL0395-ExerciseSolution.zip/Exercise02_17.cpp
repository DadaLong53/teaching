#include <iostream>
#include <cmath>
using namespace std;

int main()
{
  // Enter the temperature in Fahrenheit
  cout << "Enter the temperature in Fahrenheit " <<
    "(must be between -58�F and 41�F): ";
  double fahrenheit;
  cin >> fahrenheit;

  // Enter the wind speed miles per hour
  cout << "Enter the wind speed miles per hour " <<
    "(must be greater than or equal to 2) : ";
  double speed;
  cin >> speed;

  // Compute wind chill index
  double windChillIndex = 35.74 + 0.6215 * fahrenheit - 35.75 *
    pow(speed, 0.16) + 0.4275 * fahrenheit *
    pow(speed, 0.16);

  // Display the result
  cout << "The wind chill index is " << windChillIndex << endl;

  return 0;
}
