#include <iostream>
using namespace std;

int main()
{
  // Prompt the user to enter the first number
  int number;
  cout << "Enter an integer: ";
  cin >> number;
  int max = number; 
  int count = 1;

  // Prompt the user to enter the remaining numbers
  while (number != 0) 
	{
    cout << "Enter an integer: ";
    cin >> number; // Read the next number
		
		if (number > max) 
		{
      max = number;
      count = 1;
    }
    else if (number == max)
      count++;
	}

  cout << "\n" <<
    "max is " << max << "\n" <<
    "the occurrence count is " << count << endl;

  return 0;
}
