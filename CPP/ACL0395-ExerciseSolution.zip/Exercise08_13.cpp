#include <iostream>
using namespace std;

void sort(int m[][2], int numberOfRows);
void printArray(int m[][2], int numberOfRows); // Function prototype

int main()
{
  cout << "Enter ten points: ";
  int m[10][2]; // = {{4, 2}, {1, 7}, {4, 5}, {1, 2}, {1, 1}, {4, 1}};
  for (int i = 0; i < 10; i++)
    cin >> m[i][0] >> m[i][1];

  sort(m, 10);

  printArray(m, 10);

  return 0;
}

void sort(int m[][2], int numberOfRows)
{
  for (int i = 0; i < numberOfRows; i++)
  {
    double currentMin = m[i][0];
    int currentMinIndex = i;

    for (int j = i; j < numberOfRows; j++)
    {
      if (currentMin > m[j][0] // primary sort
        || (currentMin == m[j][0] && m[currentMinIndex][1] > m[j][1])) // secondary sort
      {
        currentMin = m[j][0];
        currentMinIndex = j;
      }
    }

    // Swap list[i] with list[currentMinIndex] if necessary;
    if (currentMinIndex != i)
    {
      int temp0 = m[currentMinIndex][0];
      int temp1 = m[currentMinIndex][1] ;
      m[currentMinIndex][0] = m[i][0];
      m[currentMinIndex][1] = m[i][1];
      m[i][0] = temp0;
      m[i][1] = temp1;
    }
  }
}

void printArray(int m[][2], int numberOfRows)
{
  for (int i = 0; i < numberOfRows; i++)
  {
    cout << m[i][0] <<", " << m[i][1] <<  endl;
  }
}
