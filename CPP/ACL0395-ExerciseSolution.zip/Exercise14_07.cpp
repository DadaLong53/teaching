#include <sstream>
#include <cmath>
#include <string>
#include <iostream>
using namespace std;

class Complex
{
public:
  Complex();
  Complex(double a, double b);
  Complex(double a);
  double getA() const;
  double getB() const;
  Complex add(const Complex &secondComplex) const;
  Complex subtract(const Complex &secondComplex) const;
  Complex multiply(const Complex &secondComplex) const;
  Complex divide(const Complex &secondComplex) const;
  double abs() const;
  string toString() const;

  Complex &operator+=(Complex &secondComplex);
  Complex &operator-= (Complex &secondComplex);
  Complex &operator*=(Complex &secondComplex);
  Complex &operator/=(Complex &secondComplex);

  double &operator[](const int & index);

  Complex &operator++(); // Prefix ++
  Complex &operator--(); // Prefix ++

  Complex operator++(int dummy); // Postfix ++
  Complex operator--(int dummy); // Postfix --

  Complex operator+(); // Unary +  
  Complex operator-(); // Unary - 

  friend ostream &operator<<(ostream &stream, const Complex &complex);
  friend istream &operator>>(istream &stream, Complex &complex);

private:
  double a;
  double b;
};

Complex operator+(const Complex &c1, const Complex &c2) 
{
  return c1.add(c2);
}

Complex operator-(const Complex &c1, const Complex &c2)  
{
  return c1.subtract(c2);
}

Complex operator*(const Complex &c1, const Complex &c2)  
{
  return c1.multiply(c2);
}

Complex operator/(const Complex &c1, const Complex &c2) 
{
  return c1.divide(c2);
}

Complex::Complex()
{
  a = 0;
  b = 0;
}

Complex::Complex(double a, double b)
{
  this->a = a;
  this->b = b;
}

Complex::Complex(double a)
{
  this->a = a;
  this->b = 0;
}

double Complex::getA() const 
{
  return a;
}

double Complex::getB() const 
{
  return b;
}

Complex Complex::add(const Complex &secondComplex) const 
{
  double newA = a + secondComplex.getA();
  double newB = b + secondComplex.getB();
  return Complex(newA, newB);
}

Complex Complex::subtract(const Complex &secondComplex) const 
{
  double newA = a - secondComplex.getA();
  double newB = b - secondComplex.getB();
  return Complex(newA, newB);
}

Complex Complex::multiply(const Complex &secondComplex) const 
{
  double newA = a * secondComplex.getA() - b * secondComplex.getB();
  double newB = b * secondComplex.getA() + a * secondComplex.getB();
  return Complex(newA, newB);
}

Complex Complex::divide(const Complex &secondComplex) const 
{
  double newA = (a * secondComplex.getA() + b * secondComplex.getB()) / (pow(secondComplex.getA(), 2.0) + pow(secondComplex.getB(), 2.0));
  double newB = (b * secondComplex.getA() - a * secondComplex.getB()) / (pow(secondComplex.getA(), 2.0) + pow(secondComplex.getB(), 2.0));
  return Complex(newA, newB);
}

double Complex::abs() const
{
  return sqrt(a * a + b * b);
}

string Complex::toString() const 
{
  stringstream ss;
  ss << a;
  if (b != 0)
    ss << " + " << b << "i";
  return ss.str();
}

Complex &Complex::operator+=(Complex &secondComplex)
{
  *this = this->add(secondComplex);
  return *this;
}

Complex &Complex::operator-=(Complex &secondComplex)
{
  *this = this->subtract(secondComplex);
  return *this;
}

Complex &Complex::operator*=(Complex &secondComplex)
{
  *this = this->multiply(secondComplex);
  return *this;
}

Complex &Complex::operator/=(Complex &secondComplex)
{
  *this = this->divide(secondComplex);
  return *this;
}

double &Complex::operator[](const int &index)
{
  if (index == 0)
    return a;
  else if (index == 1)
    return b;
  else
  {
    cout << "subscript error" << endl;
    exit(0);
  }
}

Complex &Complex::operator++() // Prefix ++
{
  a += 1;
  return *this;
}

Complex &Complex::operator--() // Prefix --
{
  a -= 1;
  return *this;
}

Complex Complex::operator++(int dummy) // Postfix ++
{
  Complex temp(a, b);
  a += 1;
  return temp;
}

Complex Complex::operator--(int dummy) // Postfix --
{
  Complex temp(a, b);
  a -= 1;
  return temp;
}

Complex Complex::operator+() // Unary +
{
  return *this;
}

Complex Complex::operator-() // Unary -
{
  a *= -1;
  return *this;
}

ostream &operator<<(ostream &str, const Complex &complex)
{
  if (complex.b == 0)
    str << complex.a;
  else
    str << complex.a << " + " << complex.b << "i";
  return str;
}

istream &operator>>(istream & str, Complex &complex)
{
  cout << "Enter a and b for (a + bi): ";
  str >> complex.a;
  str >> complex.b;
  return str;
}

int main()
{
  Complex number1;
  cout << "Enter the first complex number: ";
  cin >> number1;

  Complex number2;
  cout << "Enter the second complex number: ";
  cin >> number2;

  cout << "(" << number1 << ")" << " + " << "(" << number2 
	<< ") = " << (number1 + number2) << endl;
  cout << "(" << number1 << ")" << " - " << "(" << number2 
	<< ") = " << (number1 - number2) << endl;
  cout << "(" << number1 << ")" << " * " << "(" << number2 
	<< ") = " << (number1 * number2) << endl;
  cout << "(" << number1 << ")" << " / " << "(" << number2 
	<< ") = " << (number1 / number2) << endl;
  cout << "|" << number1 << "|" << " = " << number1.abs() << endl;

  number1[0] = 3.4;
  cout << number1++ << endl;
  cout << ++number2 << endl;
  cout << (3 + number2) << endl;
  cout << (number2 += number1) << endl;
  cout << (number2 *= number1) << endl;

  return 0;
}
