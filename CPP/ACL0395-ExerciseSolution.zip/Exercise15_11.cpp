#include <iostream>
#include <string>
using namespace std;

#ifndef STRING_H
#define STRING_H

class MyString : public string
{
public:
  // Create an empty MyString
  MyString();

  // Create a MyString with the specified string literal
  MyString(string s);

  // Return the index of the first occurrence of ch 
  // after fromIndex in the string. Return -1 if not matched.
  int indexOf(char ch, int fromIndex) const; 

  // Return the index of the last occurrence of ch 
  // before fromIndex in the string. Return -1 if not matched.
  int lastIndexOf(char ch, int fromIndex) const; 
};
#endif

MyString::MyString() : string()
{
}

MyString::MyString(string s) : string(s)
{
}

int MyString::indexOf(char ch, int fromIndex) const
{
  for (unsigned i = fromIndex; i < this->size(); i++)
    if (this->at(i) == ch)
      return i;

  return -1;
}

int MyString::lastIndexOf(char ch, int fromIndex) const
{
  for (unsigned i = fromIndex; i > 0; i--)
    if (this->at(i) == ch)
      return i;

  return -1;
}

int main()
{
  MyString s("Programming is fun. Programming is fun.");
  char ch = 'i';

  cout << s.indexOf(ch, 10) << endl;
  cout << s.indexOf(ch, 23) << endl;
  cout << s.lastIndexOf(ch, 29) << endl;
  cout << s.lastIndexOf(ch, 4) << endl;

  return 0;
}
