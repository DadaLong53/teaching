#include <iostream>
#include <ctime>
using namespace std;

class Time
{
private:
  int hour;
  int minute;
  int second;

public:
  Time()
  {
    setTime(time(0));
  }

  Time(int elapseTime)
  {
    setTime(elapseTime);
  }

  Time(int h, int m, int s)
  {
    hour = h;
    minute = m;
    second = s;
  }

  void setTime(int elapseTime)
  {
    // Obtain the total seconds since the midnight, Jan 1, 1970
    int totalSeconds = elapseTime;

    // Compute the current second in the minute in the hour
    second = totalSeconds % 60;

    // Obtain the total minutes
    int totalMinutes = totalSeconds / 60;

    // Compute the current minute in the hour
    minute = totalMinutes % 60;

    // Obtain the total hours
    int totalHours = totalMinutes / 60;

    // Compute the current hour
    hour = (int)(totalHours % 24);
  }

  int getHour()
  {
    return hour;
  }

  int getMinute()
  {
    return minute;
  }

  int getSecond()
  {
    return second;
  }
};

int main()
{
  Time time;
  cout << time.getHour() << ":" << time.getMinute() << ":" << time.getSecond() << endl;

  Time time1(555550);
  cout << time1.getHour() << ":" << time1.getMinute() << ":" << time1.getSecond() << endl;

  return 0;
}
