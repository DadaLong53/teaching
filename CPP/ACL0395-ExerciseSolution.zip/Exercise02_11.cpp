#include <iostream>
using namespace std;

int main()
{
  cout << "Enter the number of years: ";
	int numberOfYears;
  cin >> numberOfYears;
    
  double population = 312032486 + numberOfYears * 365 * 24 * 60 * 60 / 7.0 - 
        numberOfYears * 365 * 24 * 60 * 60 / 13.0 + numberOfYears * 365 * 24 * 60 * 60 / 45.0;
    
  // Display results
  cout << "The population in " << numberOfYears << " years is " << static_cast<int>(population) << endl;
  

  return 0;
}
