#include <iostream>
using namespace std;

class EvenNumber
{
public:
  EvenNumber()
  {
    value = 0;
  }

  // Constructor
  EvenNumber(int newValue)
  {
    value = newValue;
  }

  int getValue()
  {
    return value;
  }

  EvenNumber getNext()
  {
    return EvenNumber(value + 2);
  }

  EvenNumber getPrevious()
  {
    return EvenNumber(value - 2);
  } 
    
// Data members
private:
  int value;
};

int main() {
  EvenNumber t(16);
  cout << t.getValue() << endl;
  cout << t.getNext().getValue() << endl;
  cout << t.getPrevious().getValue() << endl;

  return 0;
}