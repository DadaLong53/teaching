#include <iostream>
using namespace std;

int main()
{
  /** Print Pattern IV */
  for (int i = 1; i <= 6; i++) {
    // Print leading space
    for (int j = i; j > 1; j--)
      cout << "  ";

    for (int j = 1; j <= 6 + 1 - i; j++)
      cout << j << " ";
    cout << endl;
  }

  return 0;
}
