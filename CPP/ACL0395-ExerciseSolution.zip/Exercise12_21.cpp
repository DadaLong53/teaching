#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include <cctype>
#include <ctime>
#include "ImprovedStack.h"

using namespace std;

// Split an expression into numbers, operators, and parenthese
vector<string> split(const string &expression);

// Evaluate an expression and return the result
double evaluateExpression(const string &expression);

// Perform an operation
void processAnOperator(
  Stack<double> &operandStack, Stack<char> &operatorStack);

// Find a solution for the cards shown
bool findSolution(int a, int b, int c, int d, string &solution);

int main()
{
  const int N = 52;
  int deck[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13,
      1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13,
      1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13,
      1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13};

  long startTime = time(0);

  string solution;
  int totalNumberOfCombinations = 0;
  int noSolutionCount = 0;
  for (int i1 = 0; i1 < N; i1++)
    for (int i2 = i1 + 1; i2 < N; i2++)
      for (int i3 = i2 + 1; i3 < N; i3++)
        for (int i4 = i3 + 1; i4 < N; i4++) {
          totalNumberOfCombinations++;

          int a = deck[i1];
          int b = deck[i2];
          int c = deck[i3];
          int d = deck[i4];
          if (!findSolution(a, b, c, d, solution))
            noSolutionCount++;
        }

  cout << "Total number of combinations is "
    << totalNumberOfCombinations << endl;
  cout << "Total number of combinations without solutions is "
    << noSolutionCount << endl;
  cout << "The no solution ratio is "
    << 1.0 * noSolutionCount / totalNumberOfCombinations;

  long endTime = time(0);
  cout << "Total time spent " << (endTime - startTime) << endl;

  return 0;
}

vector<string> split(const string &expression)
{
  vector<string> v; // A vector to store split items as strings
  string numberString; // A numeric string

  for (int i = 0; i < expression.length(); i++)
  {
    if (isdigit(expression[i]))
      numberString.append(1, expression[i]); // Append a digit
    else
    {
      if (numberString.size() > 0)
      {
        v.push_back(numberString); // Store the numeric string
        numberString.erase(); // Empty the numeric string
      }

      if (!isspace(expression[i]))
      {
        string s;
        s.append(1, expression[i]);
        v.push_back(s); // Store an operator and parenthese
      }
    }
  }

  // Store the last numeric string
  if (numberString.size() > 0)
    v.push_back(numberString);

  return v;
}

// Evaluate an expression
double evaluateExpression(const string &expression)
{
  // Create operandStack to store operands
  Stack<double> operandStack;

  // Create operatorStack to store operators
  Stack<char> operatorStack;

  // Extract operands and operators
  vector<string> tokens = split(expression);

  // Phase 1: Scan tokens
  for (int i = 0; i < tokens.size(); i++)
  {
    if (tokens[i][0] == '+' || tokens[i][0] == '-')
    {
      // Process all +, -, *, / in the top of the operator stack
      while (!operatorStack.empty() && (operatorStack.peek() == '+'
       || operatorStack.peek() == '-' || operatorStack.peek() == '*'
       || operatorStack.peek() == '/'))
      {
        processAnOperator(operandStack, operatorStack);
      }

      // Push the + or - operator into the operator stack
      operatorStack.push(tokens[i][0]);
    }
    else if (tokens[i][0] == '*' || tokens[i][0] == '/')
    {
      // Process all *, / in the top of the operator stack
      while (!operatorStack.empty() && (operatorStack.peek() == '*'
        || operatorStack.peek() == '/'))
      {
        processAnOperator(operandStack, operatorStack);
      }

      // Push the * or / operator into the operator stack
      operatorStack.push(tokens[i][0]);
    }
    else if (tokens[i][0] == '(')
    {
      operatorStack.push('('); // Push '(' to stack
    }
    else if (tokens[i][0] == ')')
    {
      // Process all the operators in the stack until seeing '('
      while (operatorStack.peek() != '(')
      {
        processAnOperator(operandStack, operatorStack);
      }

      operatorStack.pop(); // Pop the '(' symbol from the stack
    }
    else
    { // An operand scanned. Push an operand to the stack as integer
      operandStack.push(atoi(tokens[i].c_str()));
    }
  }

  // Phase 2: process all the remaining operators in the stack
  while (!operatorStack.empty())
  {
    processAnOperator(operandStack, operatorStack);
  }

  // Return the result
  return operandStack.pop();
}

// Process one opeator: Take an operator from operatorStack and
// apply it on the operands in the operandStack
void processAnOperator(
    Stack<double> &operandStack, Stack<char> &operatorStack)
{
  char op = operatorStack.pop();
  double op1 = operandStack.pop();
  double op2 = operandStack.pop();
  if (op == '+')
    operandStack.push(op2 + op1);
  else if (op == '-')
    operandStack.push(op2 - op1);
  else if (op == '*')
    operandStack.push(op2 * op1);
  else if (op == '/')
    if (op1 != 0)
      operandStack.push(op2 / op1);
    else
      operandStack.push(99999999);
}

/* Finds a solution for the cards shown */
bool findSolution(int a, int b, int c, int d, string &solution)
{
  solution = "No solution";
  char operators[] = {'+', '-', '*', '/'};

  int allCombinations[][4] = { { a, b, c, d }, { d, a, b, c },
      { c, d, a, b }, { b, c, d, a }, { a, b, d, c }, { c, a, b, d },
      { d, c, a, b }, { b, d, c, a }, { a, d, c, b }, { b, a, d, c },
      { c, b, a, d }, { d, c, b, a }, { a, c, b, d }, { d, a, c, b },
      { b, d, a, c }, { c, b, d, a }, { b, a, c, d }, { d, b, a, c },
      { c, d, b, a }, { a, c, d, b }, { a, d, b, c }, { c, a, d, b },
      { b, c, a, d }, { d, b, c, a } };

  for (int i1 = 0; i1 < 4; i1++)
    for (int i2 = 0; i2 < 4; i2++)
      for (int i3 = 0; i3 < 4; i3++)
        for (int row = 0; row < 24; row++)
          for (int i = 0; i < 3; i++)
            for (int j = 0; j < 5; j++)
            {
              char firstOp = operators[i1];
              char secondOp = operators[i2];
              char thirdOp = operators[i3];

              if (i == 0) {
                if (j == 0) {
                  stringstream ss;
                  ss << allCombinations[row][0] << firstOp
                      <<  allCombinations[row][1] << secondOp
                      <<  allCombinations[row][2] << thirdOp
                      << allCombinations[row][3];
                  solution = ss.str();
                  if (evaluateExpression(solution) == 24) {
                    return true;
                  }

                } else if (j == 1) {
                  stringstream ss;
                  ss << "(" << allCombinations[row][0] << firstOp
                      << allCombinations[row][1] << ")" << secondOp
                      << allCombinations[row][2] << thirdOp
                      << allCombinations[row][3];
                      solution = ss.str();
                  if (evaluateExpression(solution) == 24)
                    return true;

                } else if (j == 2) {
                  stringstream ss;
                  ss << allCombinations[row][0] << firstOp << "("
                      << allCombinations[row][1] << secondOp
                      << allCombinations[row][2] << ")" << thirdOp
                      << allCombinations[row][3];
                      solution = ss.str();
                  if (evaluateExpression(solution) == 24)
                    return true;

                } else if (j == 3) {
                  stringstream ss;
                  ss << allCombinations[row][0] << firstOp
                      << allCombinations[row][1] << secondOp << "("
                      << allCombinations[row][2] << thirdOp
                      << allCombinations[row][3] << ")";
                      solution = ss.str();
                  if (evaluateExpression(solution) == 24)
                    return true;

                } else if (j == 4) {
                  stringstream ss;
                  ss << "(" << allCombinations[row][0] << firstOp
                      << allCombinations[row][1] << ")" << secondOp
                      << "(" << allCombinations[row][2] << thirdOp
                      << allCombinations[row][3] << ")";
                      solution = ss.str();
                  if (evaluateExpression(solution) == 24)
                    return true;

                }
              } else if (i == 1) {
                if (j == 0) {
                  stringstream ss;
                  ss << "(" << allCombinations[row][0] << firstOp
                     << allCombinations[row][1] << secondOp
                     << allCombinations[row][2] << ")" << thirdOp
                     << allCombinations[row][3];
                     solution = ss.str();
                  if (evaluateExpression(solution) == 24)
                    return true;

                } else if (j == 1) {
                  stringstream ss;
                  ss << "((" << allCombinations[row][0] << firstOp
                     << allCombinations[row][1] << ")" << secondOp
                     << allCombinations[row][2] << ")" << thirdOp
                     << allCombinations[row][3];
                     solution = ss.str();
                  if (evaluateExpression(solution) == 24)
                    return true;
                } else if (j == 2) {
                  stringstream ss;
                  ss << "(" << allCombinations[row][0] << firstOp
                     << "(" << allCombinations[row][1] << secondOp
                     << allCombinations[row][2] << "))" << thirdOp
                     << allCombinations[row][3];
                     solution = ss.str();
                  if (evaluateExpression(solution) == 24)
                    return true;
                }
              } else if (i == 2) {
                if (j == 0) {
                  stringstream ss;
                  ss << allCombinations[row][0] << firstOp << "("
                     << allCombinations[row][1] << secondOp
                     << allCombinations[row][2] << thirdOp
                     << allCombinations[row][3] << ")";
                      solution = ss.str();
                  if (evaluateExpression(solution) == 24)
                    return true;

                } else if (j == 1) {
                  stringstream ss;
                  ss << allCombinations[row][0] << firstOp << "(("
                     << allCombinations[row][1] << secondOp
                     << allCombinations[row][2] << ")" << thirdOp
                     << allCombinations[row][3] << ")";
                      solution = ss.str();
                  if (evaluateExpression(solution) == 24)
                    return true;

                } else if (j == 2) {
                  stringstream ss;
                  ss << allCombinations[row][0] << firstOp << "("
                     << allCombinations[row][1] << secondOp << "("
                     << allCombinations[row][2] << thirdOp
                     << allCombinations[row][3] << "))";
                      solution = ss.str();
                  if (evaluateExpression(solution) == 24)
                    return true;
                }
              }
            }

  return false;
}
