#include <iostream>
using namespace std;

int main()
{
  cout << "Enter an uppercase letter: ";
  char uppercase;
  cin >> uppercase;

  int offset = 'a' - 'A';
  char lowercase = (uppercase + offset);

  cout << "The lowercase letter is " << lowercase << endl;

  return 0;
}
