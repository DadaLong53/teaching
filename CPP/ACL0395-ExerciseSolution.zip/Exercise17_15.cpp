#include <iostream>
#include <string>
using namespace std;

int count(const string& s, char a, int high) 
{
  int result = 0;

  if (high >= 0)
    result = count(s, a, high - 1) + ((s[high] == a) ? 1 : 0);

  return result;
}

int count(const string& s, char a) 
{
  return count(s, a, s.size());
}

int main()
{
  cout << "Enter a string: ";
  string s;
  getline(cin, s);

  cout << "Enter a character: ";
  char ch;
  cin >> ch;

  cout << count(s, ch) << endl;

  return 0;
}
