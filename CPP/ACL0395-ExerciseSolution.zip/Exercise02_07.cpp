#include <iostream>
using namespace std;

int main()
{
  // Prompt the user to enter the number of minutes
  cout << "Enter the number of minutes: ";
  long minutes;
  cin >> minutes;

  long numberOfDays = minutes / (24 * 60);
  long numberOfYears = numberOfDays / 365;

  // Display results
  cout << minutes << " minutes is approximately " <<
    numberOfYears << " years and " << (numberOfDays % 365)
    << " days." << endl;

  return 0;
}
