#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

int main()
{
  cout << setw(12) << "Degree" << setw(12) << "Sin" << setw(12) << "Cos" << endl;

  for (int degree = 0; degree <= 360; degree += 10) {
    cout << setw(12) << degree << setw(12) <<
      sin(degree * 3.14159 / 180) << setw(12) <<
      cos(degree * 3.14159 / 180) << endl;
  }

  return 0;
}
