#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  int count = 1;
  for (int i = '!'; i < '~'; i++)
     (count++ % 10 != 0) ? cout << setw(2) << (char)i :
                           cout << setw(2) << (char)i << "\n";

  return 0;
}
