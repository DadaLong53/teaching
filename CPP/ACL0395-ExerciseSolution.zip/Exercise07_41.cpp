#include <iostream>
#include <cstring>
using namespace std;

int bin2Dec(const char binaryString[])
{
  int value = binaryString[0] - '0';
  for (int i = 1; i < strlen(binaryString); i++)
  {
    value = value * 2 + binaryString[i] - '0';
  }

  return value;
}


int main()
{
  cout << "Enter a bianry number: ";
  char bianryString[80];
  cin >> bianryString;
  cout << bin2Dec(bianryString) << endl;

  return 0;
}
