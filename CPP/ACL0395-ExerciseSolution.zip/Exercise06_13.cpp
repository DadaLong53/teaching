#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

double m(int i) 
{
  double pi = 0;
  int sign = 1;

  for (int k = 1; k <= i; k++) 
  {
    pi += sign / (2 * k - 1.0);
    sign = -1 * sign;
  }

  return 4 * pi;
}

int main()
{
  cout << left << setw(10) << "i" << left << setw(10) << "m(i)" << endl;
  for (int i = 1; i <= 1000; i = i + 100)
    cout << left << setw(10) << i << fixed << setprecision(4) << m(i) << endl;

  return 0;
}