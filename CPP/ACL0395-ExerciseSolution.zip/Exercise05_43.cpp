#include <ctime>
#include <iostream>
using namespace std;

int main()
{
  int numberOfSeconds;
  cout << "Enter the number of second: ";
  cin >> numberOfSeconds;

  int startTime = time(0);
  int endTime = startTime + numberOfSeconds;

  while (time(0) < endTime) {
    while (startTime != time(0)) {
      startTime++;
      if (endTime - startTime > 1)
        cout << (endTime - startTime) << " seconds remaining" << endl;
      else if (endTime - startTime == 1)
        cout << "1 second remaining" << endl;
    }
  }

  cout << "Stopped" << endl;
  return 0;
}
