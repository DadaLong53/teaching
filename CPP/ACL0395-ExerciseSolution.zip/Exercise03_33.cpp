#include <iostream>
using namespace std;

int main()
{
  cout << "Enter year: (e.g., 2008): ";
  int year;
  cin >> year;

  cout << "Enter month: 1-12: ";
  int month;
  cin >> month;

  if (month == 1)
  {
    month = 13;
    year--;
  }
  else if (month == 2)
  {
    month = 14;
    year--;
  }

  cout << "Enter the day of the month: 1-31: ";
  int dayOfMonth;
  cin >> dayOfMonth;

  int k = year % 100;
  int j = (int)(year / 100);

  int dayOfWeek = (int)(dayOfMonth + (int)((month + 1) * 26.0 / 10) + k + (int)(k / 4.0) + (int)(j / 4.0) + 5 * j) % 7;

  if (dayOfWeek == 0)
    cout << "Day of the week is Saturday" << endl;
  else if (dayOfWeek == 1)
    cout << "Day of the week is Sunday" << endl;
  else if (dayOfWeek == 2)
    cout << "Day of the week is Monday" << endl;
  else if (dayOfWeek == 3)
    cout << "Day of the week is Tuesday" << endl;
  else if (dayOfWeek == 4)
    cout << "Day of the week is Wednesday" << endl;
  else if (dayOfWeek == 5)
    cout << "Day of the week is Thursday" << endl;
  else if (dayOfWeek == 6)
    cout << "Day of the week is Friday" << endl;

  return 0;
}
