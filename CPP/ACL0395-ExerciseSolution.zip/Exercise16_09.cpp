#include <iostream>
#include <stdexcept>
#include <vector>
using namespace std;

double deltaA(vector<vector<double> > a)
{
  double result = a[0][0] * a[1][1] * a[2][2] +
    a[2][0] * a[0][1] * a[1][2] + a[0][2] * a[1][0] * a[2][1] -
    a[0][2] * a[1][1] * a[2][0] - a[0][0] * a[1][2] * a[2][1] -
    a[2][2] * a[1][0] * a[0][1];
  return result;
}

vector<double> solveLinearEquation(
   vector<vector<double>> a, vector<double> b)
{
  if (a.size() != 3 || a[0].size() != 3 || a[1].size() != 3 
    || a[2].size() != 3 || b.size() != 3)
  {
    throw invalid_argument("array size incorrect");
  }

  vector<double> result(3);

  double delta = deltaA(a);
  if (delta == 0)
    throw runtime_error("no solution");
  else
  {
    result[0] = ((a[1][1] * a[2][2] - a[1][2] * a[2][1]) * b[0] +
      (a[0][2] * a[2][1] - a[0][1] * a[2][2]) * b[1] +
      (a[0][1] * a[1][2] - a[0][2] * a[1][1]) * b[2]) / delta;
    result[1] = ((a[1][2] * a[2][0] - a[1][0] * a[2][2]) * b[0] +
      (a[0][0] * a[2][2] - a[0][2] * a[2][0]) * b[1] +
      (a[0][2] * a[1][0] - a[0][0] * a[1][2]) * b[2]) / delta;
    result[2] = ((a[1][0] * a[2][1] - a[1][1] * a[2][0]) * b[0] +
      (a[0][1] * a[2][0] - a[0][0] * a[2][1]) * b[1] +
      (a[0][0] * a[1][1] - a[0][1] * a[1][0]) * b[2]) / delta;

    return result;
  }
}

int main()
{
  vector<vector<double> > a(3);
  a[0] = vector<double>(3);
  a[1] = vector<double>(3);
  a[2] = vector<double>(3);

  cout << "Enter a11, a12, a13, a21, a22, a23, a31, a32, a33: ";
  cin >> a[0][0] >> a[0][1] >> a[0][2] >>
    a[1][0] >> a[1][1] >> a[1][2] >>
    a[2][0] >> a[2][1] >> a[2][2];

  vector<double> b(3);
  cout << "Enter b1, b2, b3: ";
  cin >> b[0] >> b[1] >> b[2];

  try 
  {
    vector<double> result = solveLinearEquation(a, b);
    cout << "The solution is " << result[0] << " " << result[1] << " " << result[2] << endl;
  }
  catch (runtime_error& ex)
  {
    cout << ex.what() << endl;
  }
  catch (invalid_argument& ex)
  {
    cout << ex.what() << endl;
  }

  return 0;
}
