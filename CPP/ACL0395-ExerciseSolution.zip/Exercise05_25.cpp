#include <iostream>
using namespace std;

int main()
{
  const int N = 50000;
  double sum = 0.0;

  for (int i = 1; i <= N; i++)
    sum += 1.0 / i;
  cout << "Foreward: " << sum << endl;

  sum = 0;
  for (int i = N; i >= 1; i--)
    sum += 1.0 / i;
  cout << "Backward: " << sum << endl;

  return 0;
}
