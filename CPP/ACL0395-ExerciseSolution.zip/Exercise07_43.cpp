#include <iostream>
#include <cstring>
using namespace std;

void reverse(char s[]) 
{
  for (int i = 0, j = strlen(s) - 1; i < strlen(s) / 2; i++, j--)
  {
    char temp = s[i];
    s[i] = s[j];
    s[j] = temp;
  }
}

void dec2Bin(int value, char binaryString[])
{
  int i = 0;
  while (value != 0)
  {
    int bit = value % 2;
    value = value / 2;
    binaryString[i++] = bit + '0';
  }

  binaryString[i] = '\0';
  reverse(binaryString);
}

int main()
{
  cout << "Enter a decimal number: ";
  int number;
  cin >> number;
  char binary[80];
  dec2Bin(number, binary);
  cout << binary << endl;

  return 0;
}
