#include <iostream>
using namespace std;

int main()
{
  cout << "The area is " << 4.5 * 7.9 << endl;
  cout << "The perimeter is " << 2 * (4.5 + 7.9) << endl;
  return 0;
}
