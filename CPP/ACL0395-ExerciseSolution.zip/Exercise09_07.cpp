#include <iostream>
#include <ctime>
using namespace std;

class StopWatch
{
public:
  StopWatch()
  {
    startTime = time(0);
  }

  void start() {
    startTime = time(0);
  }

  void stop() {
    endTime = time(0);
  }

  long getElapsedTime() {
    return endTime - startTime;
  }  

private:
  long startTime;
  long endTime;
};

void selectionSort(double list[], int listSize) 
{
  for (int i = 0; i < listSize - 1; i++) 
  {
    // Find the minimum in the list[i..listSize-1]
    double currentMin = list[i];
    int currentMinIndex = i;

    for (int j = i + 1; j < listSize; j++) 
    {
      if (currentMin > list[j]) 
      {
        currentMin = list[j];
        currentMinIndex = j;
      }
    }

    // Swap list[i] with list[currentMinIndex] if necessary;
    if (currentMinIndex != i) 
    {
      list[currentMinIndex] = list[i];
      list[i] = currentMin;
    }
  }
}

int main()
{
  const int N = 100000;
  double list[N];

  for (int i = 0; i < N; i++) 
  {
    list[i] = rand() % N;
  }

  StopWatch stopWatch;
  selectionSort(list, N);
  stopWatch.stop();
    
  cout << "The sort time is " << stopWatch.getElapsedTime() << endl;    

  return 0;
}
