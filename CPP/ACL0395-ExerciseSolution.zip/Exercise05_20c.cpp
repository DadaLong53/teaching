#include <iostream>
using namespace std;

int main()
{
  /** Print Pattern III */
  for (int i = 1; i <= 6; i++)
  {
    // Print leading space
    for (int j = 6 - i; j >= 1; j--)
      cout << "  ";

    for (int j = i; j >= 1; j--)
      cout << j << " ";
    cout << endl;
  }

  return 0;
}
