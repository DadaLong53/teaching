#include <iostream>
#include <vector> // to store factors
using namespace std;

int main()
{
  cout << "Enter an integer m: ";
  int m;
  cin >> m;
  vector<int> v;

  int number = m;
  int factor = 2;
  while (factor <= number)
  {
    if (number % factor == 0)
    {
      v.push_back(factor);
      number = number / factor;
    }
    else
      factor++;
  }

  int n = 1;
  unsigned i = 0;
  while (i < v.size() - 1)
  {
    if (v[i] != v[i + 1])
    {
      n *= v[i];
      i += 1;
    }
    else
      i += 2;
  }

  if (i == v.size() - 1)
    n *= v[i];


  cout << "The smallest number n for m * n to be a perfect square is " << n << endl;
  cout << "m * n is " << m * n << endl;
  
  return 0;
}
