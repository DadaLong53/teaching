#include <iostream>
#include <ctime> // for time function
#include <cmath> // for the srand and rand functions
using namespace std;

int main()
{
  int countPositive = 0, countNegative = 0;
  int count = 0, total = 0, num;

  cout << "Enter an int value, the program exits if the input is 0: ";
  cin >> num;

  while (num != 0)
  {
    if (num > 0)
      countPositive++;
    else if (num < 0)
      countNegative++;

    total += num;
    count++;

    // Read the next data
    cin >> num;
  }

  if (count == 0)
    cout << "You didn't enter any number";
  else
  {
    cout << "The number of postives is " << countPositive << endl;
    cout << "The number of negatives is " << countNegative << endl;
    cout << "The total is " << total << endl;
    cout << "The average is " << (total * 1.0 / count) << endl;
  }

  return 0;
}
