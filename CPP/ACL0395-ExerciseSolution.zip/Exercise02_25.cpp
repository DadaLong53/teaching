#include <iostream>
using namespace std;

int main()
{
  cout << "Enter the ball travel time in seconds: ";
  double t;
  cin >> t;
  
  double g = 9.8;
  double d = g * t * t / 2;
  cout << "The height of the building is " << d << " meters " << endl;

  return 0;
}
