#include <iostream>
#include <cmath>
using namespace std;

int main()
{
  cout << "Enter a numerator: ";
  int numerator;
  cin >> numerator;

  cout << "Enter a denominator: ";
  int denominator;
  cin >> denominator;

  if (numerator < denominator) 
  {
    cout << numerator << " / " << denominator <<
      " is a proper fraction" << endl;
  }
  else if (numerator % denominator != 0)
  {
    cout << numerator << " / " << denominator << 
      " is an improper fraction " << 
      "and its mixed fraction is " << numerator / denominator << " + " <<   
      numerator % denominator <<  " / " <<  denominator << endl; 
  }
  else
  {
    cout << numerator << " / " << denominator << 
      " is an improper fraction " << 
      "and it can be reduced to " << numerator / denominator << endl; 
  }

  return 0;
}