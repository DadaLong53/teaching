#include <iostream>
#include <cmath>
using namespace std;

int main()
{
  double sum = 0;

  for (int i = 1; i < 625; i++)
    sum += 1 / (sqrt(1.0 * i) + sqrt(1.0 * (i + 1)));

  cout << "Sum is " << sum << endl;

  return 0;
}
