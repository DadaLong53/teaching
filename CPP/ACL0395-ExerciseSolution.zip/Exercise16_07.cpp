#include "RationalWithOperators.h"
#include <cstring>
#include <cstdlib>
#include <stdexcept>
#include <iostream>

using namespace std;

class IllegalSubscriptException : public runtime_error
{
public:
  IllegalSubscriptException(int index) : runtime_error("Illegal index")
  {
    this->index = index;
  }

  char getIndex()
  {
    return index;
  }

private:
  int index;
};

Rational::Rational()
{
  numerator = 0;
  denominator = 1;
}

Rational::Rational(int numerator, int denominator)
{
  long factor = gcd(numerator, denominator);
  this->numerator = ((denominator > 0) ? 1 : -1) * numerator / factor;
  this->denominator = abs(denominator) / factor;
}

int Rational::getNumerator() const
{
  return numerator;
}

int Rational::getDenominator() const
{
  return denominator;
}

/** Find GCD of two numbers */
int Rational::gcd(int n, int d) 
{
  long n1 = abs(n);
  long n2 = abs(d);
  int gcd = 1;

  for (int k = 1; k <= n1 && k <= n2; k++)
  {
    if (n1 % k == 0 && n2 % k == 0)
      gcd = k;
  }

  return gcd;
}

Rational Rational::add(const Rational &secondRational) const
{
  long n = numerator * secondRational.getDenominator() +
    denominator * secondRational.getNumerator();
  long d = denominator * secondRational.getDenominator();
  return Rational(n, d);
}

Rational Rational::subtract(const Rational &secondRational) const
{
  long n = numerator * secondRational.getDenominator()
    - denominator * secondRational.getNumerator();
  long d = denominator * secondRational.getDenominator();
  return Rational(n, d);
}

Rational Rational::multiply(const Rational &secondRational) const
{
  long n = numerator * secondRational.getNumerator();
  long d = denominator * secondRational.getDenominator();
  return Rational(n, d);
}

Rational Rational::divide(const Rational &secondRational) const
{ 
  long n = numerator * secondRational.getDenominator();
  long d = denominator * secondRational.numerator;
  return Rational(n, d);
}

int Rational::compareTo(const Rational &secondRational) const
{
  Rational temp = this->subtract(secondRational);
  if (temp.getNumerator() < 0)
    return -1;
  else if (temp.getNumerator() == 0)
    return 0;
  else
    return 1;
}

bool Rational::equals(const Rational &secondRational) const
{
  if (this->compareTo(secondRational) == 0)
    return true;
  else
    return false;
}

int Rational::intValue() const
{
  return getNumerator() / getDenominator();
}

double Rational::doubleValue() const
{
  return 1.0 * getNumerator() / getDenominator();
}

string Rational::toString() const
{
  char s1[20], s2[20];
  itoa(numerator, s1, 10); // Convert int to string s1
  itoa(denominator, s2, 10); // Convert int to string s2

  if (denominator == 1)
    return string(s1);
  else
    return string(strcat(strcat(s1, "/"), s2));
}


// Define function operator []
int& Rational::operator[](int index) 
{
  if (index == 0)
    return numerator;
  else if (index == 1)
    return denominator;
  else
  {
    throw IllegalSubscriptException(index);
  }
}

// Define function operators for postfix ++ and --
Rational Rational::operator++(int dummy)
{
  Rational temp(numerator, denominator);
  numerator += denominator;
  return temp;
}

Rational Rational::operator--(int dummy)
{
  Rational temp(numerator, denominator);
  numerator -= denominator;
  return temp;
}

// Define function operators for unary + and -
Rational Rational::operator+()
{
  return *this;
}

Rational Rational::operator-()
{
  numerator *= -1;
  return *this;
}

// Define the output and input operator
ostream& operator<<(ostream& str, const Rational& rational)
{
  str << rational.numerator << " / " << rational.denominator;
  return str;
}

istream& operator>>(istream& str, Rational& rational)
{
  cout << "Enter numerator: ";
  str >> rational.numerator;

  cout << "Enter denominator: ";
  str >> rational[1];
  return str;
}

int main()
{
  Rational r;

  cout << "Done" << endl;
  return 0;
}