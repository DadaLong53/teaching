#include <iostream>
#include <ctime>
using namespace std;

int main()
{
  const int NUMBER_OF_CARDS = 52;
  int deck[52];
  bool found[4]; // found[0] is true is a Club suit is picked, etc.

  // Initialize cards
  for (int i = 0; i < 52; i++)
    deck[i] = i;

  // Initialize cards
  for (int i = 0; i < 4; i++)
    found[i] = false;

  // Count the number of picks
  int numberOfPicks = 0;

  // Count occurrence in each suit
  int count = 0;
  srand(time(0));
  while (count < 4) {
    numberOfPicks++;
    int index = rand() % NUMBER_OF_CARDS;
    if (!found[index / 13]) {
      found[index / 13] = true;
      count++;

      if (index % 13 == 0)
        cout << "Ace of ";
      else if (index % 13 == 10)
        cout << "Jack of ";
      else if (index % 13 == 11)
        cout << "Queen of ";
      else if (index % 13 == 12)
        cout << "King of ";
      else
        cout << (index % 13) + 1 << " of ";

      if (index / 13 == 0)
        cout << "Clubs" << endl;
      else if (index / 13 == 1)
        cout << "Diamonds" << endl;
      else if (index / 13 == 2)
        cout << "Hearts" << endl;
      else if (index / 13 == 3)
        cout << "Spades" << endl;
    }
  }

  cout << "Number of picks: " << numberOfPicks;

  return 0;
}
