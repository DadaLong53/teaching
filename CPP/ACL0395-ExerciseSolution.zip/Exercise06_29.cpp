#include <iostream>
using namespace std;

// Return sum of odd place digits in number
int sumOfOddPlace(int number)
{
  int result = 0;

  while (number != 0)
  {
    result += (int)(number % 10);
    number = number / 100; // Skip the next odd place
  }

  return result;
}

int main()
{
  cout << "Enter an integer: ";
  int n;
  cin >> n;
  cout << "The sum of the digits in the odd places in " << n
    << " is " << sumOfOddPlace(n) << endl;

  return 0;
}
