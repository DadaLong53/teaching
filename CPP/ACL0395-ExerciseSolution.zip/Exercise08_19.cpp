#include <iostream>
using namespace std;

const int SIZE = 100;

int main()
{
  double balances[SIZE]; // Balance for each bank
  double loan[SIZE][SIZE]; // loan[i][j] is the amount bank i loans to bank j

  // Read the number of banks
  int n;
  cin >> n;

  // Read the limit (minimum asset for keeping a bank safe)
  double limit;
  cin >> limit;

  for (int i = 0; i < n; i++)
  {
    // Read each line
    cin >> balances[i]; // Bank i's balance
    int numberOfBorrowers; // Number of banks borrowing from bank i
    cin >> numberOfBorrowers;
    for (int j = 0; j < numberOfBorrowers; j++) {
      int k; // Bank k borrows from bank i
      cin >> k;
      cin >> loan[i][k];  // the loan amount of Bank k borrowing from bank i
    }
  }

  double asset[SIZE]; // asset[i] is bank i's total asset
  bool isSafe[SIZE]; // All banks are safe initially
  for (int i = 0; i < n; i++)
    isSafe[i] = true;

  cout << "Unsafe banks: ";
  bool newUnsafeFound = true; // Indicate whether a new unsafe bank is discovered
  while (newUnsafeFound) {
    newUnsafeFound = false; // Assume no new unsafe banks are found
    for (int i = 0; i < n; i++) {
      asset[i] = balances[i];
      for (int j = 0; j < n; j++)
        asset[i] += loan[i][j];

      if (isSafe[i] && asset[i] < limit)
      {
        isSafe[i] = false;
        newUnsafeFound = true;
        // Remove bank i is unsafe
        cout << i << " ";

        for (int k = 0; k < n; k++)
          loan[k][i] = 0; // Bank i's borrowed loans are gone
      }
    }
  }

  return 0;
}
