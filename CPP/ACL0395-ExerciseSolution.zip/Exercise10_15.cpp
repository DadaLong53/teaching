#include <iostream>
#include <string>
#include <ctime>
#include <cstdlib>
using namespace std;

int main()
{
  const int NUMBER_OF_WORDS = 5;
  string words[] = {"write", "program", "that", "receive", "positive"};

  char anotherGame;
  srand(time(0));

  do
  {
    int i = rand() % NUMBER_OF_WORDS;

    string hiddenWord = words[i];
    string guessedWord(hiddenWord.length(), '*');

    unsigned numberOfCorrectLettersGuessed = 0;
    unsigned numberOfMisses = 0;

    while (numberOfCorrectLettersGuessed < hiddenWord.length())
    {
      cout << "(Guess) Enter a letter in word " << guessedWord << " > ";
      char letter;
      cin >> letter;
      unsigned index = hiddenWord.find(letter);

      if (guessedWord.find(letter) != string::npos)
      {
        cout << "\t" << letter << " is already in the word" << endl;
      }
      else if (index == string::npos)
      {
        cout << "\t" << letter << " is not in the word" << endl;
        numberOfMisses++;
      }
      else
      {
        while (index != string::npos)
        {
          guessedWord[index] = letter;
          numberOfCorrectLettersGuessed++;
          index = hiddenWord.find(letter, index + 1);
        }
      }
    }

    cout << "The word is " << hiddenWord << ". You missed " << numberOfMisses <<
      ((numberOfMisses <= 1) ? " time" : " times") << endl;

    cout << "Do you want to guess for another word? Enter y or n> ";
    cin >> anotherGame;
  }
  while (anotherGame == 'y');

  return 0;
}
