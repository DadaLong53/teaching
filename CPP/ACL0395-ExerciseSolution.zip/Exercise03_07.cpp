#include <iostream>
using namespace std;

int main()
{
  cout << "Enter three integers: ";
  int n1, n2, n3;
  cin >> n1 >> n2 >> n3;

  if (n1 > n2)
  {
    // Swap n1 with n2
    int temp = n1;
    n1 = n2;
    n2 = temp;
  }

  if (n2 > n3)
  {
    // Swap n2 with n3
    int temp = n2;
    n2 = n3;
    n3 = temp;
  } // After this statement, n3 is the largest

  if (n1 > n2)
  {
    // Swap n1 with n2
    int temp = n1;
    n1 = n2;
    n2 = temp;
  }

  cout << "n1, n2, and n3 are " << n1 << ", " << n2 << ", and " << n3;

  return 0;
}
