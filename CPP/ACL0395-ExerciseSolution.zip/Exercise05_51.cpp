#include <iostream>
#include <string>
using namespace std;

int main()
{
  // Prompt the user to enter an ISBN as a string
  cout << "Enter the first 12-digit of an ISBN number as a string: ";
  string s;
  cin >> s;

  if (s.size() != 12)
  {
    cout << s << " is an invalid input" << endl;
    exit(1);
  }

  // Calculate checksum
  int sum = 0;
  for (int i = 0; i < s.size(); i++)
    if (i % 2 == 0)
      sum += (s[i] - '0');
    else
      sum += (s[i] - '0') * 3;

  int checksum = 10 - sum % 10;

  cout << "The ISBN number is ";

  cout << s;
  if (checksum == 10)
    cout << "0" << endl;
  else
    cout << checksum << endl;

  return 0;
}
