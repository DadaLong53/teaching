#include <iostream>
#include <cmath>
using namespace std;

double area(int n, double side);

int main()
{
  // Enter the number of sides
  cout << "Enter the number of sides: ";
  int numberOfSides;
  cin >> numberOfSides;

  cout << "Enter the side: ";
  double side;
  cin >> side;

  cout << "The area of the polygon is " <<
    area(numberOfSides, side);

  return 0;
}

double area(int n, double side)
{
  return n * side * side / tan(3.14159 / n) / 4;
}
