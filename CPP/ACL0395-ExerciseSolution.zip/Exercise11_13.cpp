#include <iostream>
#include <string>
using namespace std;

#ifndef COURSE_H
#define COURSE_H
class Course
{
public:
  Course(const string& courseName, int capacity);
  ~Course(); // Destructor
  Course(Course&); // Copy constructor
  string getCourseName() const;
  void addStudent(const string& name);
  void dropStudent(const string& name);
  string* getStudents() const;
  int getNumberOfStudents() const;
  void clear();

private:
  string courseName;
  string* students;
  int numberOfStudents;
  int capacity;
};

#endif
	
Course::Course(const string& courseName, int capacity) 
{
  numberOfStudents = 0;
  this->courseName = courseName;
  this->capacity = capacity;
  students = new string[capacity];
}

Course::~Course() 
{
  delete [] students;
}

string Course::getCourseName() const 
{
  return courseName;
}

void Course::addStudent(const string& name) 
{
  if (numberOfStudents >= capacity) 
  {
    string *newArray;
    newArray = new string[2 * capacity];
		
    for (int k = 0; k < numberOfStudents; k++)
    {
      newArray[k] = students[k];	
    }
		
    students = newArray;
  }

  students[numberOfStudents] = name;
  numberOfStudents++;
}

void Course::dropStudent(const string& name) 
{
  for (int i = 0; i < numberOfStudents; i ++) 
  {
    if (students[i] == name) 
    {
      for (int k = i; k < numberOfStudents - 1; k ++)
      {
	students[k] = students[k + 1];
      }
 
      numberOfStudents--;		
      break;
    }
  }
}

string* Course::getStudents() const 
{
  return students;
}

int Course::getNumberOfStudents() const 
{
  return numberOfStudents;
}
	
void Course::clear() 
{
  for (int i = 0; i < numberOfStudents; i ++) 
  {
    students[i] = "";
  }
  numberOfStudents = 0;
}

Course::Course(Course &course) // Copy constructor
{
  courseName = course.courseName;
  numberOfStudents = course.numberOfStudents;
  capacity = course.capacity;
  students = new string[capacity];
}

int main() {
  Course course1("Data Structures", 10);
  Course course2("Database Systems", 2);

  course1.addStudent("Peter Jones");
  course1.addStudent("Brian Smith");
  course1.addStudent("Anne Kennedy");
  course1.addStudent("Susan Kennedy");
  course1.addStudent("John Kennedy");
  course1.addStudent("Kim Johnson");
  course1.addStudent("S1");
  course1.addStudent("S2");
  course1.addStudent("S3");
  course1.addStudent("S4");
  course1.addStudent("S5");
  course1.addStudent("S6");
  course1.addStudent("S7");

  course2.addStudent("Peter Jones");
  course2.addStudent("Steve Smith");
  
  cout << "Number of students in course1: "
    << course1.getNumberOfStudents() << endl;
      
  string *students = course1.getStudents();

  for (int i = 0; i < course1.getNumberOfStudents(); i++)
    cout << students[i] << ", ";

  cout << endl;
    
  cout << "Number of students in course2: "
    << course2.getNumberOfStudents() << endl;

  course1.dropStudent("S1");
  cout << "Number of students in course1: "
    << course1.getNumberOfStudents() << endl;
  students = course1.getStudents();
    
  for (int i = 0; i < course1.getNumberOfStudents(); i++)
    cout << students[i] << ", ";
      
  cout << endl;  
  course1.clear();
  cout << "Number of students in course1: "
  << course1.getNumberOfStudents();
	
  return 0;
}
