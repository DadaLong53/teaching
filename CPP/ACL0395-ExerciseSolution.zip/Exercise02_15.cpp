#include <iostream>
#include <cmath>
using namespace std;

int main()
{
  // Enter the first point with two double values
  cout << "Enter x1 and y1: ";
  double x1, y1;
  cin >> x1 >> y1;

  // Enter the second point with two double values
  cout << "Enter x2 and y2: ";
  double x2, y2;
  cin >> x2 >> y2;

  // Compute the distance
  double distance = pow((x1 - x2) * (x1 - x2) +
    (y1 - y2) * (y1 - y2), 0.5);

  cout << "The distance of the two points is " << distance;

  return 0;
}
