#include <iostream>
#include <vector>
using namespace std;

#ifndef VECTOR_H
#define VECTOR_H

template<typename T>
class MyVector : public vector<T>
{
public:
  // Return the index of the first matching element in to the vector
  // Return -1 if there is no match
  int indexOf(T element) const; 

  // Return the index of the last matching element in to the vector
  // Return -1 if there is no match
  int lastIndexOf(T element) const; 
};
#endif

template<typename T>
int MyVector<T>::indexOf(T element) const
{
  for (unsigned i = 0; i < this->size(); i++)
    if (this->at(i) == element)
      return i;

  return -1;
}

template<typename T>
int MyVector<T>::lastIndexOf(T element) const
{
  for (unsigned i = this->size() - 1; i >= 0; i--)
    if (this->at(i) == element)
      return i;

  return -1;
}

int main()
{
  MyVector<int> v;
  
  v.push_back(2);
  v.push_back(21);
  v.push_back(12);
  v.push_back(2);
  v.push_back(33);

  cout << v.indexOf(2) << endl;
  cout << v.lastIndexOf(2) << endl;
  cout << v.indexOf(42) << endl;

  return 0;
}
