#include <iostream>
#include <cmath>
using namespace std;

int main()
{
  cout << "Enter the radius of the bounding circle: ";
  double radius;
  cin >> radius;

  cout << "The coordinates of five points on the pentagon are" << endl;

  const double PI = 3.14159;
  double angle = PI / 2 - 2 * PI / 5;
  double x = radius * cos(angle);
  double y = radius * sin(angle);
  cout << "(" << x << ", " << y << ")" << endl;
  
  angle += 2 * PI / 5;
  x = radius * cos(angle);
  y = radius * sin(angle);
  cout << "(" << x << ", " << y << ")" << endl;

  angle += 2 * PI / 5;
  x = radius * cos(angle);
  y = radius * sin(angle);
  cout << "(" << x << ", " << y << ")" << endl;

  angle += 2 * PI / 5;
  x = radius * cos(angle);
  y = radius * sin(angle);
  cout << "(" << x << ", " << y << ")" << endl;

  angle += 2 * PI / 5;
  x = radius * cos(angle);
  y = radius * sin(angle);
  cout << "(" << x << ", " << y << ")" << endl;

  return 0;
}