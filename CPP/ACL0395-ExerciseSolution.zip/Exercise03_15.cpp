#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;

int main()
{
  // Generate scissor, rock, paper
  srand(time(0));
  int computerNumber = rand() % 3;

  // Prompt the user to enter scissor, rock, or paper
  cout << "scissor (0), rock (1), paper (2): ";
  int userNumber;
  cin >> userNumber;

  // Check the guess
  switch (computerNumber) {
    case 0:
      if (userNumber == 0)
        cout << "Computer is scissor. You are scissor too. It is a draw" << endl;
      else if (userNumber == 1)
        cout << "Computer is scissor. You are rock. You won" << endl;
      else if (userNumber == 2)
        cout << "Computer is scissor. You are paper. You lost" << endl;
      break;
    case 1:
      if (userNumber == 0)
        cout << "Computer is rock. You are scissor. You lost" << endl;
      else if (userNumber == 1)
        cout << "Computer is rock. You are rock too. It is a draw" << endl;
      else if (userNumber == 2)
        cout << "Computer is rock. You are paper. You won" << endl;
      break;
    case 2:
      if (userNumber == 0)
        cout << "Computer is paper. You are scissor. You won" << endl;
      else if (userNumber == 1)
        cout << "Computer is paper. You are rock. You lost" << endl;
      else if (userNumber == 2)
        cout << "Computer is paper. You are paper too. It is a draw" << endl;
      break;
    }

  return 0;
}
