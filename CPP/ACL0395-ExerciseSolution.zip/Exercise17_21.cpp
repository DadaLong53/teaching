#include <iostream>
#include <string> 
#include <sstream> 
using namespace std;

string decimalToBinary(int value)
{
  if (value == 0)
    return "";
  else
  {
    stringstream ss;
    ss << value % 2;
    return decimalToBinary(value / 2) + ss.str();   
  }
}

int main()
{
  cout << "Enter a decimal integer: ";
  int decimal;
  cin >> decimal;
  cout << decimal << " is binary " << decimalToBinary(decimal) << endl;

  return 0;
}