#include <iostream>
#include <vector>
using namespace std;

double getArea(double x1, double y1, double x2, double y2, double x3, double y3);

int main()
{
  cout << "Enter the number of points: ";
  int n;
  cin >> n;

  cout << "Enter the coordinates of the points: ";
  vector<double> x(n), y(n);
  for (int i = 0; i < n; i++) 
    cin >> x[i] >> y[i];
    
  double total = 0;
  for (int i = 1; i < n - 1; i++) 
    total += getArea(x[0], y[0], x[i], y[i], x[i + 1], y[i + 1]);
    
  cout << "The total area is " << total << endl;

  return 0;
}

double getArea(double x1, double y1, double x2, double y2, double x3, double y3)
{
  double s1 = sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 -y2));
  double s2 = sqrt((x1 - x3) * (x1 - x3) + (y1 - y3) * (y1 -y3));
  double s3 = sqrt((x3 - x2) * (x3 - x2) + (y3 - y2) * (y3 -y2));
    
  double s = (s1 + s2 + s3) / 2;
  return sqrt(s * (s - s1) * (s - s2) * (s - s3));
}
