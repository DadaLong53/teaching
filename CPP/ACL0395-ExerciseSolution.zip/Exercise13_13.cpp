#include <iostream>
#include <fstream>
#include <ctime>
#include <cmath>
using namespace std;

int main()
{
  fstream binaryio;
  binaryio.open("Exercise13_5.dat", ios::out | ios::binary | ios::app);

  srand(time(0));
  for (int i = 0; i < 100; i++)
  {
    int value = rand();
    binaryio.write(reinterpret_cast < char * > (& value), sizeof(value));
  }

  binaryio.close();

  cout << "Done" << endl;
  return 0;
}
