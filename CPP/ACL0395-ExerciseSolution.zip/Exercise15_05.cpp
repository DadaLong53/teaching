#include <iostream>
#include <vector>
using namespace std;

template<typename T>
class Stack : public vector<T>
{
public:
  Stack();
  bool empty() const;
  T peek() const;
  T push(T value);
  T pop();
  int getSize() const;
  void printStack() const;
  bool contains(T element) const;
};

template<typename T>
Stack<T>::Stack()
{
  clear();
}

template<typename T>
bool Stack<T>::empty() const
{
  return empty();
}

template<typename T>
T Stack<T>::peek() const
{
  return elements[size - 1];
}

template<typename T>
T Stack<T>::push(T value)
{
  push_back(value);
  return value;
}

template<typename T>
T Stack<T>::pop()
{
  return elements[--size];
}

template<typename T>
int Stack<T>::getSize() const
{
  return size();
}

template<typename T>
void Stack<T>::printStack() const
{
  for (int i = 0; i < getSize(); i++)
    cout << at(i) << " ";
}

template<typename T>
bool Stack<T>::contains(T element) const
{
  for (int i = 0; i < getSize(); i++)
    if (element == at(i)) 
      return true;

  return false;
}

int main()
{
  Stack<int> s;
  s.push(1);
  s.push(2);
  s.push_back(4);

  s.printStack();

  cout << "\n" << s.contains(4) << endl;
}
