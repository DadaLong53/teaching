#include <iostream>
#include <cmath>
using namespace std;

int main()
{
  // Enter a point with two double values
  cout << "Enter a point with two coordinates: ";
  double x, y;
  cin >> x >> y;

  // Compute the distance
  double distance = pow(x * x +  y * y, 0.5);
    
  if (distance <= 10)
    cout << "Point (" << x << ", " << y << ") is in the circle" << endl;
  else
    cout << "Point (" << x << ", " << y << ") is not in the circle" << endl;

  return 0;
}
