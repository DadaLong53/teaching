#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  cout << left;
  cout << setw(12) << "kilograms" << setw(12) << "pounds" << endl;
  cout << "---------------------------------" << endl;

  int kilograms = 1;
  while (kilograms <= 199)
  {
    cout << fixed << setprecision(2);
    cout << setw(12) << kilograms << setw(12) << kilograms * 2.2 << endl;
    kilograms += 2;
  }

/** Use for loop
  for (int kilograms = 1; kilograms <= 199; kilograms += 2)
  {
    cout << fixed << setprecision(2);
    cout << setw(12) << kilograms << setw(12) << kilograms * 2.2 << endl;
  }
*/

  return 0;
}
