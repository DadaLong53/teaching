#include <iostream>
#include <cmath>
using namespace std;

/** Method for computing mean of an array of double values */
double mean(double x[], int size)
{
  double sum = 0;

  for (int i = 0; i < size; i++)
    sum += x[i];

  return sum * 1.0 / size;
}

/** Method for computing mean of an array of int values */
double mean(int x[], int size)
{
  int sum = 0;

  for (int i = 0; i < size; i++)
    sum += x[i];

  return sum / size;
}

/** Method for computing deviation of double values */
double deviation(double x[], int size)
{
  double mean1 = mean(x, size);
  double squareSum = 0;

  for (int i = 0; i < size; i++)
  {
    squareSum += pow(x[i] - mean1, 2);
  }

  return sqrt(squareSum / (size - 1));
}

/** Method for computing deviation of int values */
double deviation(int x[], int size)
{
  double mean1 = mean(x, size);
  double squareSum = 0;

  for (int i = 0; i < size; i++)
  {
    squareSum += pow(x[i] - mean1, 2);
  }

  return sqrt(squareSum / (size - 1));
}

/** The method for sorting the numbers */
void sortAndKeepIndex(int list[], int indexList[], int size)
{
  int currentMax;
  int currentMaxIndex;

  // Initialize indexList
  for (int i = 0; i < size; i++)
    indexList[i] = i;

  for (int i = size - 1; i >= 1; i--)
  {
    // Find the maximum in the list[0..i]
    currentMax = list[i];
    currentMaxIndex = i;

    for (int j = i - 1; j >= 0; j--)
    {
      if (currentMax < list[j])
      {
        currentMax = list[j];
        currentMaxIndex = j;
      }
    }

    // Swap list[i] with list[currentMaxIndex] if necessary;
    if (currentMaxIndex != i)
    {
      list[currentMaxIndex] = list[i];
      list[i] = currentMax;

      // Swap the index in indexList too
      int temp = indexList[i];
      indexList[i] = indexList[currentMaxIndex];
      indexList[currentMaxIndex] = temp;
    }
  }
}

int main()
{
  const int NUMBER_OF_STUDENTS = 8;
  const int NUMBER_OF_QUESTIONS = 10;

  char answers[NUMBER_OF_STUDENTS][NUMBER_OF_QUESTIONS] =
  {
    {
      'A', 'B', 'A', 'C', 'C', 'D', 'E', 'E', 'A', 'D'
    },
    {
      'D', 'B', 'A', 'B', 'C', 'A', 'E', 'E', 'A', 'D'
    },
    {
      'E', 'D', 'D', 'A', 'C', 'B', 'E', 'E', 'A', 'D'
    },
    {
      'C', 'B', 'A', 'E', 'D', 'C', 'E', 'E', 'A', 'D'
    },
    {
      'A', 'B', 'D', 'C', 'C', 'D', 'E', 'E', 'A', 'D'
    },
    {
      'B', 'B', 'E', 'C', 'C', 'D', 'E', 'E', 'A', 'D'
    },
    {
      'B', 'B', 'A', 'C', 'C', 'D', 'E', 'E', 'A', 'D'
    },
    {
      'E', 'B', 'E', 'C', 'C', 'D', 'E', 'E', 'A', 'D'
    }
  };

  // Key to the questions
  char keys[NUMBER_OF_QUESTIONS] =
  {
    'D', 'B', 'D', 'C', 'C', 'D', 'A', 'E', 'A', 'D'
  };
  int correctCounts[NUMBER_OF_STUDENTS] = {0, 0, 0, 0, 0, 0, 0, 0};

  // Grade all answers
  for (int i = 0; i < NUMBER_OF_STUDENTS; i++)
  {
    // Grade one student
    for (int j = 0; j < NUMBER_OF_QUESTIONS; j++)
    {
      if (answers[i] [j] == keys[j])
        correctCounts[i] ++;
    }
  }

  int indexList[NUMBER_OF_STUDENTS];

  // Sort totalScores
  sortAndKeepIndex(correctCounts, indexList, NUMBER_OF_STUDENTS);

  // Display result
  for (int i = 0; i < NUMBER_OF_STUDENTS; i++)
    cout << "Student " << indexList[i] << ": " << correctCounts[i] << endl;

  cout << "Mean is " << mean(correctCounts, NUMBER_OF_STUDENTS) << endl;
  cout << "Deviation is " << deviation(correctCounts, NUMBER_OF_STUDENTS) << endl;

  return 0;
}
