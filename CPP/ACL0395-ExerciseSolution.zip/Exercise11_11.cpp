#include <iostream>
#include <cmath>
using namespace std;

const int SIZE = 2;

class Rectangle2D
{
private:
  double x, y; // Center of the rectangle
  double width, height;

public:
  Rectangle2D()
  {
    x = y = 0;
    width = height = 1;
  }

  Rectangle2D(double x, double y, double width, double height)
  {
    this->x = x;
    this->y = y;
    this->width = width;
    this->height = height;
  }

  double getX() const
  {
    return x;
  }

  void setX(double x)
  {
    this->x = x;
  }

  double getY() const
  {
    return y;
  }

  void setY(double y)
  {
    this->y = y;
  }

  double getWidth() const
  {
    return width;
  }

  void setWidth(double width)
  {
    this->width = width;
  }

  double getHeight() const
  {
    return height;
  }

  void setHeight(double height)
  {
    this->height = height;
  }

  double getPerimeter() const
  {
    return 2 * (width + height);
  }

  double getArea() const
  {
    return width * height;
  }

  bool contains(double x, double y) const
  {
    return abs(x - this->x) <= width / 2 && abs(y - this->y) <= height / 2;
  }

  bool contains(Rectangle2D & r) const
  {
    return contains(r.x - r.width / 2, r.y + r.height / 2) && contains(r.x - r.width / 2, r.y - r.height / 2)
         && contains(r.x + r.width / 2, r.y + r.height / 2) && contains(r.x + r.width / 2, r.y - r.height / 2);
  }

  bool overlaps(Rectangle2D & r) const
  {
    return abs(r.x - x) <= (r.width + width) / 2 && abs(r.y - y) <= (r.height + height) / 2;
  }

  double distance(double x1, double y1, double x2, double y2) const
  {
    return sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
  }
};

// MyRectangle2D getRectangle(const double points[][SIZE], int numberOfPoints);

double minX(const double points[][SIZE], int numberOfPoints) 
{
  double minX = points[0][0];
    
  for (int i = 0; i < numberOfPoints; i++)
    if (minX > points[i][0])
      minX = points[i][0];
    
  return minX;
}
  
double maxX(const double points[][SIZE], int numberOfPoints)
{
  double maxX = points[0][0];
    
  for (int i = 0; i < numberOfPoints; i++)
    if (maxX < points[i][0])
      maxX = points[i][0];
    
  return maxX;
}
  
double minY(const double points[][SIZE], int numberOfPoints)
{
  double minY = points[0][1];
    
  for (int i = 0; i < numberOfPoints; i++)
    if (minY > points[i][1])
      minY = points[i][1];
    
  return minY;
}
  
double maxY(const double points[][SIZE], int numberOfPoints) 
{
  double maxY = points[0][1];
    
  for (int i = 0; i < numberOfPoints; i++)
    if (maxY < points[i][1])
      maxY = points[i][1];
    
  return maxY;
}

Rectangle2D getRectangle(const double points[][SIZE], int numberOfPoints) 
{
  double minimalX = minX(points, numberOfPoints);
  double minimalY = minY(points, numberOfPoints);
  double maximalX = maxX(points, numberOfPoints);
  double maximalY = maxY(points, numberOfPoints);
    
  return Rectangle2D((minimalX + maximalX) / 2, (minimalY + maximalY) / 2, 
	maximalX - minimalX, maximalY - minimalY); 
}

int main()
{
  double points[5][2];
  cout << "Enter five points: ";
  for (int i = 0; i < 5; i++) 
  {
    cin >> points[i][0] >> points[i][1];
  }
     
  Rectangle2D boundingRectangle = getRectangle(points, 5);
    
  cout << "The bounding rectangle's center (" << boundingRectangle.getX() << ", " << 
      boundingRectangle.getY() << "), width " << boundingRectangle.getWidth() << 
	  ", height " << boundingRectangle.getHeight() << endl;

  return 0;
}