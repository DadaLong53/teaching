#include <iostream>
#include <string>
using namespace std;

void count(const string& s, int counts[], int size)
{
  for (int i = 0; i < 26; i++)
    counts[i] = 0;

  for (int i = 0; i < s.size(); i++)
  {
    if (isalpha(s[i]))
      counts[tolower(s[i]) - 'a'] ++;
  }
}

int main()
{
  string s;
  getline(cin, s, '\n');

  int counts[26];

  count(s, counts, 26);

  for (int i = 0; i < 26; i++)
    cout << (char)(i + 'a') << " " << counts[i] << endl;

  return 0;
}
