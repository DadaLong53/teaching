#include <iostream>
#include <fstream>
#include "Loan.h"
using namespace std;

void displayLoan(Loan loan)
{
  cout << loan.getAnnualInterestRate() << " ";
  cout << loan.getNumberOfYears() << " ";
  cout << loan.getLoanAmount() << endl;
}

int main()
{
  fstream binaryio; // Create stream object
  binaryio.open("Exercise13_15.dat", ios::in | ios::binary);

  Loan loan;

  while (true)
  {
    binaryio.read(reinterpret_cast < char * > (& loan), sizeof(Loan));

    if (binaryio.eof()) break;
    displayLoan(loan);
  }

  binaryio.close();

  return 0;
}
