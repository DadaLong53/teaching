#include <iostream>
using namespace std;

// Iterative method for computing factorial of n
long factorial(int n) 
{
  long result = 1;

  for (int i = 1; i <= n; i++)
    result *= i;

  return result;
}

int main()
{
  // Enter an integer
  cout << "Please enter a nonnegative integer: ";
  int n;
  cin >> n;

  cout << "Factorial of " << n << " is " << factorial(n) << endl;

  return 0;
}
