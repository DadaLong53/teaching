#ifndef COURSE_H
#define COURSE_H
#include <string>
#include <stdexcept>
using namespace std;

class Course
{
public:
  Course(const string& courseName, int capacity);
  ~Course();
  string getCourseName() const;
  void addStudent(const string& name);
  void dropStudent(const string& name);
  string* getStudents() const;
  int getNumberOfStudents() const;

private:
  string courseName;
  string* students;
  int numberOfStudents;
  int capacity;
};

#endif

#include <iostream>
using namespace std;

Course::Course(const string& courseName, int capacity)
{
  numberOfStudents = 0;
  this->courseName = courseName;
  this->capacity = capacity;
  students = new string[capacity];
}

Course::~Course()
{
  delete [] students;
}

string Course::getCourseName() const
{
  return courseName;
}

void Course::addStudent(const string& name)
{
  if (numberOfStudents >= capacity)
  {
    cout << "The maximum size of array exceeded" << endl;
    cout << "An exception is thrown" << endl;
    throw runtime_error("maximum enrollment exceeded");
  }

  students[numberOfStudents] = name;
  numberOfStudents++;
}

void Course::dropStudent(const string& name)
{
  // Left as an exercise
}

string* Course::getStudents() const
{
  return students;
}

int Course::getNumberOfStudents() const
{
  return numberOfStudents;
}

int main()
{
  Course course1("Data Structures", 10);
  Course course2("Database Systems", 15);

  course1.addStudent("Peter Jones");
  course1.addStudent("Brian Smith");
  course1.addStudent("Anne Kennedy");

  course2.addStudent("Peter Jones");
  course2.addStudent("Steve Smith");

  cout << "Number of students in course1: " <<
    course1.getNumberOfStudents() << "\n";
  string* students = course1.getStudents();
  for (int i = 0; i < course1.getNumberOfStudents(); i++)
    cout << students[i] << ", ";

  cout << "\nNumber of students in course2: "
    << course2.getNumberOfStudents() << "\n";
  students = course2.getStudents();
  for (int i = 0; i < course2.getNumberOfStudents(); i++)
    cout << students[i] << ", ";

  return 0;
}
