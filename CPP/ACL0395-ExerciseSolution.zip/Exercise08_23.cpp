#include <iostream>
#include <cmath>
using namespace std;

const int MAX_NUMBER_OF_CITIES = 20;

double distance(double c1[], double c2[])
{
  cout << "c1: " << c1[0] << " " << c1[1] << endl;
  cout << "c2: " << c2[0] << " " << c2[1] << endl;

  return sqrt((c1[0] - c2[0]) * (c1[0] - c2[0]) +
    (c1[1] - c2[1]) * (c1[1] - c2[1]));
}

// Return the total distance from i to all other cities
double totalDistance(double cities[][2], int numberOfCities, int i) 
{
  double total = 0;
  for (int j = 0; j < numberOfCities; j++) 
    total += distance(cities[i], cities[j]);
  return total;
}
  
int main()
{
  cout << "Enter the number of cities: ";
  int numberOfCities;
  cin >> numberOfCities;
    
  cout << "Enter the coordinates of the cities: ";
  double cities[MAX_NUMBER_OF_CITIES][2];
  for (int i = 0; i < numberOfCities; i++)
  {
    cin >> cities[i][0] >> cities[i][1];     
  }
    
  double minTotal = totalDistance(cities, numberOfCities, 0);
  int minIndex = 0;
  for (int i = 1; i < numberOfCities; i++) 
  {
    double total = totalDistance(cities, numberOfCities, i);
      
    if (minTotal > total) 
    {
      minTotal = total;
      minIndex = i;
    }
  }
    
  cout << "The central city is at (" <<
    cities[minIndex][0] << ", " << cities[minIndex][1] << ")" << endl;
  cout << "The total distance to all other cities is " <<
    minTotal << endl;

  return 0;
}
