#include <iostream>
#include "RationalWithOperators.h"
using namespace std;

int main()
{
  const int N = 10;
  Rational sum;
  for (int i = 1; i <= N; i++)
    sum = sum.add(Rational(i - 1, i));

  cout << "The sum of the first series is " << sum << " = " <<
    sum.doubleValue() << endl;

  return 0;
}
