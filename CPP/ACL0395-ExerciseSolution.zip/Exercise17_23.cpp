#include <iostream>
#include <string> 
using namespace std;

int binaryToDecimal(const string& binaryString, int low, int high) 
{
  if (high < low)
    return 0;
  else 
    return binaryToDecimal(binaryString, low, high - 1) * 2
      + (binaryString[high] - '0');
}

int binaryToDecimal(const string& binaryString)
{
  return binaryToDecimal(binaryString, 0, binaryString.length() - 1);
}
  
int main()
{
  cout << "Enter a binary number: ";
  string binary;
  cin >> binary;
  cout << binary << " is decimal " << binaryToDecimal(binary) << endl;

  return 0;
}