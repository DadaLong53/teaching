#include <iostream>
#include <string>
using namespace std;

int bin2Dec(const string &binaryString)
{
  int value = binaryString[0] - '0';
  for (int i = 1; i < binaryString.length(); i++)
  {
    value = value * 2 + binaryString[i] - '0';
  }

  return value;
}


int main()
{
  cout << "Enter a bianry number: ";
  string bianryString;
  cin >> bianryString;
  cout << bin2Dec(bianryString) << endl;

  return 0;
}
