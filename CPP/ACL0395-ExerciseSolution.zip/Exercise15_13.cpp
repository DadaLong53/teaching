#include <iostream>
#include <string>
using namespace std;

#ifndef STRING_H
#define STRING_H

class MyString : public string
{
public:
  // Return a copy of this string in which lowercase letters are changed
  // to uppercase and uppercase letters are changed to lowercase
  string swapCase() const; 
};
#endif

string MyString::swapCase() const
{
  string s;

  for (unsigned i = 0; i < this->size(); i++)
    if (islower(this->at(i)))
      s += toupper(this->at(i));
    else if (isupper(this->at(i)))
      s += tolower(this->at(i));
    else
      s += this->at(i);
   
  return s;
}

int main()
{
  MyString s;
  cout << "Enter a string: ";
  getline(cin, s);

  cout << "The case-swapped string is " << s.swapCase() << endl;
  
  return 0;
}
