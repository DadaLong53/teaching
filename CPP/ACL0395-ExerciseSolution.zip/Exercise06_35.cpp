#include <iostream>
using namespace std;

void solveEquation(double a, double b, double c, double d,
  double e, double f, double &x, double &y, bool &isSolvable)
{
  double detA = a * d - b * c;

  if (detA == 0)
    isSolvable = false;
  else
  {
    x = (e * d - b * f) / detA;
    y = (a * f - e * c) / detA;
    isSolvable = true;
  }
}

int main()
{
  double x1, y1, x2, y2, x3, y3, x4, y4;
  cout << "Enter the endpoints of the first line segment: ";
  cin >> x1 >> y1 >> x2 >> y2;
  cout << "Enter the endpoints of the second line segment: ";
  cin >> x3 >> y3 >> x4 >> y4;

  // Build a 2 by 2 linear equation
  double a = (y1 - y2);
  double b = (-x1 + x2);
  double c = (y3 - y4);
  double d = (-x3 + x4);
  double e = -y1 * (x1 - x2) + (y1 - y2) * x1;
  double f = -y3 * (x3 - x4) + (y3 - y4) * x3;

  double x, y;
  bool isSolvable;
  solveEquation(a, b, c, d, e, f, x, y, isSolvable);

  if (isSolvable)
    cout << "The intersecting point is: (" << x << ", " << y << ")" << endl;
  else
    cout << "The two lines do not cross " << endl;

  return 0;
}

/** Hint:
For the first line, you create an equation as:

(x � x1)/(y � y1) = (x1 � x2)/(y1 � y2), so you get

ax + by = e, where
a = (y1 � y2)
b = (x2 �x1)
e = -y1 * (x1 - x2) + (y1 - y2) * x1;


For the second line, you create an equation as:

(x � x3)/(y � y3) = (x3 � x4)/(y3 � y4), so you get
cx + dy = f, where
c = (y3 - y4);
d = (-x3 + x4);
f = -y3 * (x3 - x4) + (y3 - y4) * x3;

Now you will solve the 2 by 2 linear equation

ax + by = e
cx + dy = f

The solution is the common point of the two lines.

See Programming Exercise 6.3 on how to solve this equation.


*/
