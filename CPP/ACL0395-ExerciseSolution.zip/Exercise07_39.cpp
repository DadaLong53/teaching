#include <iostream>
using namespace std;

// Calculate checksum
int checksum(const char s[])
{
  int sum = 0;
  for (int i = 0; i < 12; i++)
		sum += (s[i] - '0') * (i % 2 == 0 ? 1 : 3);

  int checksum = 10 - sum % 10;
  if (checksum == 10)
		checksum = 0;
  
	return checksum;
}

int main()
{
  // Prompt the user to enter two strings
  cout << "Enter the first 12 digits of an ISBN as a string: ";
  char s[13];
  cin.getline(s, 13);

  cout << "The ISBN-13 number is " << s << checksum(s) << endl;

  return 0;
}
