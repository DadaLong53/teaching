#include <iostream>
using namespace std;

int main()
{
  cout << (24 / (1 + (40 + 35.0 / 60) / 60)) * 1.6 << endl;

  return 0;
}
