#include <iostream>
using namespace std;

const int N = 3;

/** The method for adding two matrices */
void addMatrix(const double a[][N], const double b[][N], double c[][N])
{
  for (int i = 0; i < N; i++)
    for (int j = 0; j < N; j++)
      c[i] [j] = a[i] [j] + b[i] [j];
}

/** Print result */
void printResult(double m1[][N], double m2[][N],
  double m3[][N], char op)
{
  for (int i = 0; i < N; i++)
  {
    for (int j = 0; j < N; j++)
      cout << " " << m1[i] [j];

    if (i == N / 2)
      cout << "  " << op << "  ";
    else
      cout << "     ";

    for (int j = 0; j < N; j++)
      cout << " " << m2[i] [j];

    if (i == N / 2)
      cout << "  =  ";
    else
      cout << "     ";

    for (int j = 0; j < N; j++)
      cout << " " << m3[i] [j];

    cout << endl;
  }
}

int main()
{
  // Create two matrices as two dimensional arrays
  double matrix1[N][N];
  double matrix2[N][N];
  double result[N][N];

  // Assign random values to matrix1 and matrix2
  cout << "Enter matrix1: ";
  for (int i = 0; i < N; i++)
    for (int j = 0; j < N; j++)
    {
      cin >> matrix1[i][j];
    }

  cout << "Enter matrix2: ";
  for (int i = 0; i < N; i++)
    for (int j = 0; j < N; j++)
    {
      cin >> matrix2[i][j];
    }

  // Add two matrices and print the result
  addMatrix(matrix1, matrix2, result);
  cout << "The addition of the matrices is " << endl;
  printResult(matrix1, matrix2, result, '+');
}
