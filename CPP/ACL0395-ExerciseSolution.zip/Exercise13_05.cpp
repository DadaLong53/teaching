#include <iostream>
#include <string>
#include <fstream>
using namespace std;

string boyNames[10][1000];
string girlNames[10][1000];

void readNames() 
{
  for (int i = 0; i < 10; i++) 
  {
    string filename;
    if (i == 9)
      filename = "C:\\cplusplusexercise\\Babynamesranking2010.txt";
    else
    {
      filename += "C:\\cplusplusexercise\\Babynamesranking200";
      filename += static_cast<char>((i + 1) + '0');
      filename += ".txt";
    }

    ifstream input(filename.c_str());
        
    int j = 0;
    while (!input.eof()) // (int j = 0; j < 1000; j++)
    {
      int dummy;
      input >> dummy; // Skip the ranking
      input >> boyNames[i][j];
      input >> dummy; // Skip the number of boy's name
      input >> girlNames[i][j];
      input >> dummy; // Skip the number of girl's name
      j++;
    }
  }
}

int search(const string names[][1000], int year, const string& name) 
{
  for (int i = 0; i < 1000; i++)
    if (names[year - 2001][i] == name)
      return i;
    
  return -1;
}

int main()
{
  readNames();

  cout << "Enter the year: ";
  int year;
  cin >> year;
  
  cout << "Enter the gender: ";
  char gender;
  cin >> gender;
  
  cout << "Enter the name: ";
  string name;
  cin >> name;
  
  if (gender == 'M') 
  {
    int index = search(boyNames, year, name);
    if (index >= 0)
      cout << "Boy name " << name << " is ranked #" << 
          (index + 1) << " in year " << year << endl;
    else
      cout << "Boy name " << name 
          << " is not ranked in year " << year << endl;
  }
  else 
  {
    int index = search(girlNames, year, name);
    if (index >= 0)
      cout << "Girl name " << name << " is ranked #" << 
          (index + 1) << " in year " << year << endl;
    else
      cout << "Girl name " << name 
          << " is not ranked in year " << year << endl;
  }

  return 0;
}
