#include <iostream>
using namespace std;

int main()
{
  double monthlyDeposit;
  cout << "Enter the monthly saving amount: ";
  cin >> monthlyDeposit;

  double currentValue = monthlyDeposit;

  // First month value
  currentValue = currentValue * (1 + 0.05 / 12);
  cout << "After the first month, the account value is " << currentValue << endl;

  // Second month value
  currentValue = (currentValue + monthlyDeposit) * (1 + 0.05 / 12);
  cout << "After the second month, the account value is " << currentValue << endl;

  // Third month value
  currentValue = (currentValue + monthlyDeposit) * (1 + 0.05 / 12);
  cout << "After the third month, the account value is " << currentValue << endl;

  // Fourth month value
  currentValue = (currentValue + monthlyDeposit) * (1 + 0.05 / 12);

  // Fifth month value
  currentValue = (currentValue + monthlyDeposit) * (1 + 0.05 / 12);

  // Sixth month value
  currentValue = (currentValue + monthlyDeposit) * (1 + 0.05 / 12);

  cout << "After the sixth month, the account value is " << currentValue << endl;
  return 0;
}
