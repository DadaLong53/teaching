#include <iostream>
using namespace std;

class LinearEquation
{
public:
  LinearEquation(double newA, double newB, double newC,
      double newD, double newE, double newF);
  double getA();
  double getB();
  double getC();
  double getD();
  double getE();
  double getF();
  bool isSolvable();
  double getX();
  double getY();

private:
  double a, b, c, d, e, f;
};

LinearEquation::LinearEquation(double newA, double newB, double newC,
      double newD, double newE, double newF)
{
  a = newA;
  b = newB;
  c = newC; 
  d = newD;
  e = newE;
  f = newF; 
}

double LinearEquation::getA()
{
  return a;
}

double LinearEquation::getB() 
{
  return b;
}

double LinearEquation::getC()
{
  return c;
}

double LinearEquation::getD() 
{
  return d;
}

double LinearEquation::getE() 
{
    return e;
  }

double LinearEquation::getF()
{
  return f;
}

bool LinearEquation::isSolvable()
{
  return a * d - b * c != 0;
}

double LinearEquation::getX() 
{
  double x = (e * d - b * f) / (a * d - b * c);
  return x; 
}

double LinearEquation::getY() 
{
  double y = (a * f - e * c) / (a * d - b * c);
  return y;
}

int main() {
  cout << "Enter a, b, c, d, e, f: ";
  double a, b, c, d, e, f;
  cin >> a >> b >> c >> d >> e >> f;

  LinearEquation equation(a, b, c, d, e, f);

  if (equation.isSolvable())
  {
    cout << "x is " <<
      equation.getX() << " and y is " << equation.getY() << endl;
  }
  else 
  {
    cout << "The equation has no solution" << endl;
  }

  return 0;
}