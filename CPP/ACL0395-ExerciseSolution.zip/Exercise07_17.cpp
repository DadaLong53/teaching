#include <iostream>
#include <ctime>
using namespace std;

/** Return the slot position of the ball for a path and also print the path */
int onePath(int numberOfSlots)
{
  int position = 0;

  for (int i = 0; i < numberOfSlots - 1; i++)
    if (rand() % 2 == 0)
    {
      cout << "L";
    }
    else
    {
      cout << "R";
      position++;
    }

  cout << endl;

  return position;
}

/** Get the max element in slots */
int max(int slots[], int numberOfSlots)
{
  int result = slots[0];

  for (int i = 1; i < numberOfSlots; i++)
  {
    if (result < slots[i])
      result = slots[i];
  }

  return result;
}

/** Print the histogram for the slots */
void printHistogram(int slots[], int numberOfSlots)
{
  int maxSlotHeight = max(slots, numberOfSlots);

  for (int h = maxSlotHeight; h > 0; h--)
  {
    for (int i = 0; i < numberOfSlots; i++)
      if (slots[i] < h)
        cout << " "; // Print nothing
      else
        cout << "O"; // Print a ball

    cout << endl;
  }
}

int main()
{
  srand(time(0));

  cout << "Enter the number of balls to drop: ";
  int numberOfBalls;
  cin >> numberOfBalls;

  cout << "Enter the number of slots (maximum 50): ";
  int numberOfSlots;
  cin >> numberOfSlots;

  int slots[50];

  for (int i = 0; i < numberOfSlots; i++)
  {
    slots[i] = 0;
  }

  for (int i = 0; i < numberOfBalls; i++)
  {
    slots[onePath(numberOfSlots)] ++;
  }

  printHistogram(slots, numberOfSlots);

  return 0;
}
