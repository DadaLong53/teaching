#include <iostream>
#include <cstring>
#include <stdexcept>
#include <typeinfo>
using namespace std;

class HexFormatException: public runtime_error
{
public:
  HexFormatException(char ch): runtime_error("Hex number format error")
  {
    this->ch = ch;
  }

  char getCh()
  {
    return ch;
  }

private:
  char ch;
};

int convertHexToDec(char ch)
{
  if (ch == 'A')
  {
    return 10;
  }
  else if (ch == 'B')
  {
    return 11;
  }
  else if (ch == 'C')
  {
    return 12;
  }
  else if (ch == 'D')
  {
    return 13;
  }
  else if (ch == 'E')
  {
    return 14;
  }
  else if (ch == 'F')
  {
    return 15;
  }
  else if (ch >= '0' && ch <= '9')
    return ch - '0';
  else
    throw HexFormatException(ch);
}

int parseHex(const char * const hexString)
{
  int value = convertHexToDec(hexString[0]);
  for (int i = 1; i < strlen(hexString); i++)
  {
    value = value * 16 + convertHexToDec(hexString[i]);
  }

  return value;
}

int main()
{
  try
  {
    cout << parseHex("A5") << endl;
    cout << parseHex("FAA") << endl;
    cout << parseHex("10") << endl;
    cout << parseHex("ABC") << endl;
    cout << parseHex("10A") << endl;
    cout << parseHex("10R") << endl;
  }
  catch (runtime_error ex)
  {
    cout << ex.what() << endl;
  }

  return 0;
}
