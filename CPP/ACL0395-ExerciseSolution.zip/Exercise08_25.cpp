#include <iostream>
using namespace std;

const int SIZE = 3;

bool isMarkovMatrix(const double m[][SIZE]);

int main()
{
  cout << "Enter a 3 by 3 matrix row by row: ";
  double m[SIZE][SIZE];
    
  for (int i = 0; i < SIZE; i++)
    for (int j = 0; j < SIZE; j++)
      cin >> m[i][j];

  if (isMarkovMatrix(m))
    cout << "It is a Markov matrix" << endl;
  else
    cout << "It is not a Markov matrix" << endl;

  return 0;
}

bool isMarkovMatrix(const double m[][SIZE])
{
  // Check positive
  for (int i = 0; i < SIZE; i++)
    for (int j = 0; j < SIZE; j++)
      if (m[i][j] < 0) return false;

  // Check the sum of each column
  for (int j = 0; j < SIZE; j++) 
  {
  	double sum = 0;
    for (int i = 0; i < SIZE; i++)
      sum += m[i][j];
      
    if (sum != 1)
      return false;
  }

  return true;
} 