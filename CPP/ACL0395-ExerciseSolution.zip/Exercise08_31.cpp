#include <iostream>
using namespace std;

const int SIZE = 2;

bool linearEquation(const double a[][SIZE], const double b[], 
  double result[]);
bool getIntersectingPoint(const double points[][SIZE], 
  double result[]);

int main()
{
  cout << "Enter x1, y1, x2, y2, x3, y3, x4, y4: ";
  double p[4][SIZE];
    
  for (int i = 0; i < 4; i++)
    for (int j = 0; j < SIZE; j++)
      cin >> p[i][j];

  double result[SIZE];
  double status = getIntersectingPoint(p, result);
        
  if (status < 0) 
    cout << "The two lines are parallel" << endl;
  else 
    cout << "The intersecting point is at (" << 
      result[0] << ", " <<  result[1] << ")" << endl;
  
  return 0;
}

bool getIntersectingPoint(const double p[][SIZE], 
  double result[])
{
  double k1 = (p[0][0] - p[1][0]) / (p[0][1] - p[1][1]);
  double k2 = (p[2][0] - p[3][0]) / (p[2][1] - p[3][1]);

  double a[2][2];
  double b[2];
  a[0][0] = 1;
  a[0][1] = k1;
  a[1][0] = 1;
  a[1][1] = k2;
  b[0] = p[0][0] - k1 * p[0][1];
  b[1] = p[2][0] - k2 * p[2][1];

  int status = linearEquation(a, b, result);

  return status;
}

bool linearEquation(const double a[][SIZE], const double b[], 
  double result[])
{
  double detA = a[0][0] * a[1][1] - a[0][1] * a[1][0];
  if (detA == 0) 
    return false;
  else 
  {
    result[0] = (b[0] * a[1][1] - b[1] * a[0][1]) / detA;
    result[1] = (b[1] * a[0][0] - b[0] * a[1][0]) / detA;
      
    return true;
  }
}