#include <iostream>
using namespace std;

int main()
{
  cout << "Welcome to C++" << endl;
  cout << "Welcome to Computer Science" << endl;
  cout << "Programming is fun" << endl;

  return 0;
}
