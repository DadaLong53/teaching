#include <iostream>
#include <cmath>
using namespace std;

int main()
{
  double distance, milesPerGallon, pricePerGallon;
  cout << "Enter the driving distance: ";
  cin >> distance;

  cout << "Enter miles per gallon: ";
  cin >> milesPerGallon;

  cout << "Enter price per gallon: ";
  cin >> pricePerGallon;

  cout << "The cost of driving is $" 
    << (distance / milesPerGallon) * pricePerGallon << endl;

  return 0;
}