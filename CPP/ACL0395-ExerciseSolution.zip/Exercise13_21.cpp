#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <ctime>
#include <cstdlib>
using namespace std;

int main()
{
  vector<string> words;

  // Read wrods from the file
  ifstream input("c:\\cplusplusexercise\\Exercise13_21.txt");

  if (input.fail())
  {
    cout << "File does not exist" << endl;
    cout << "Exit program" << endl;
    return 0;
  }

  int count = 0;
  while (!input.eof()) // Continue if not end of file
  {
    string s;
    input >> s;  // Read data
    words.push_back(s);
  }

  input.close();

  char anotherGame;
  srand(time(0));

  do
  {
    int i = rand() % words.size();

    string hiddenWord = words[i];
    string guessedWord(hiddenWord.length(), '*');

    unsigned numberOfCorrectLettersGuessed = 0;
    unsigned numberOfMisses = 0;

    while (numberOfCorrectLettersGuessed < hiddenWord.length())
    {
      cout << "(Guess) Enter a letter in word " << guessedWord << " > ";
      char letter;
      cin >> letter;
      unsigned index = hiddenWord.find(letter);

      if (guessedWord.find(letter) != string::npos)
      {
        cout << "\t" << letter << " is already in the word" << endl;
      }
      else if (index == string::npos)
      {
        cout << "\t" << letter << " is not in the word" << endl;
        numberOfMisses++;
      }
      else
      {
        while (index != string::npos)
        {
          guessedWord[index] = letter;
          numberOfCorrectLettersGuessed++;
          index = hiddenWord.find(letter, index + 1);
        }
      }
    }

    cout << "The word is " << hiddenWord << ". You missed " << numberOfMisses <<
      ((numberOfMisses <= 1) ? " time" : " times") << endl;

    cout << "Do you want to guess for another word? Enter y or n> ";
    cin >> anotherGame;
  }
  while (anotherGame == 'y');

  return 0;
}
