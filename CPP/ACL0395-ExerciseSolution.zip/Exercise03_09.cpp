#include <iostream>
using namespace std;

int main()
{
  cout << "Enter a month in the year (e.g., 1 for Jan): ";
  int month;
  cin >> month;

  cout << "Enter a year: ";
  int year;
  cin >> year;

  int numberOfDaysInMonth = 0;

  switch (month)
  {
    case 1:
      cout << "January " << year;
      numberOfDaysInMonth = 31;
    break;
    case 2:
      cout << "February " << year;
      if (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0))
        numberOfDaysInMonth = 29;
      else
        numberOfDaysInMonth = 28;
    break;
    case 3:
      cout << "March " << year;
      numberOfDaysInMonth = 31;
    break;
    case 4:
      cout << "April " << year;
      numberOfDaysInMonth = 30;
    break;
    case 5:
      cout << "May " << year;
      numberOfDaysInMonth = 31;
    break;
    case 6:
      cout << "June " << year;
      numberOfDaysInMonth = 30;
    break;
    case 7:
      cout << "July " << year;
      numberOfDaysInMonth = 31;
    break;
    case 8:
      cout << "August " << year;
      numberOfDaysInMonth = 31;
    break;
    case 9:
      cout << "September " << year;
      numberOfDaysInMonth = 30;
    break;
    case 10:
      cout << "October " << year;
      numberOfDaysInMonth = 31;
    break;
    case 11:
      cout << "November " << year;
      numberOfDaysInMonth = 30;
    break;
    case 12:
      cout << "December " << year;
      numberOfDaysInMonth = 31;
    break;
  }

  cout << " has " << numberOfDaysInMonth << " days";

  return 0;
}
