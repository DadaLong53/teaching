#include <iostream>
using namespace std;

void merge(int list1[], int size1, int list2[], int size2, 
  int list3[]);

int main()
{
  cout << "Enter list1: ";
  int list1[10], list2[10];
  for (int i = 0; i < 10; i++)
    cin >> list1[i];
    
  cout << "Enter list2: ";
  for (int i = 0; i < 10; i++)
    cin >> list1[i];    
  int[] list = commonElements(list1, list2);
    
  System.out.print("The common elements are ");
  for (int i = 0; i < list.length; i++)
    System.out.print(list[i] + " ");

  return 0;
}



  
  public static int[] commonElements(int[] list1, int[] list2) {
    int[] temp = new int[Math.min(list1.length, list2.length)];
    
    int j = 0;
    for (int i = 0; i < list2.length; i++)
      if (index(list1, list2[i]) >= 0)
        temp[j++] = list2[i];
    
    int[] result = new int[j];
    System.arraycopy(temp, 0, result, 0, j);
    return result;
  }
  
  public static int index(int[] list, int element) {
    for (int i = 0; i < list.length; i++)
      if (list[i] == element)
        return i;
    
    return -1;
  }  
}
