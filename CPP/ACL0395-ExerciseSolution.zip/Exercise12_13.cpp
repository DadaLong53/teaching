#include <iostream>
#include <vector>
#include <string>
#include <cctype>

using namespace std;

vector<string> split(const string &expression)
{
  vector<string> v; // a vector to store split items as strings
  string numberString; // A numeric string

  for (int i = 0; i < expression.length(); i++)
  {
    if (isdigit(expression[i]))
      numberString.append(1, expression[i]); // Append a digit
    else
    {
      if (numberString.size() > 0)
      {
        v.push_back(numberString); // Store the numeric string
        numberString.erase(); // Empty the numeric string
      }

      if (!isspace(expression[i]))
      {
        string s;
        s.append(1, expression[i]);
        v.push_back(s); // Store an operator and parenthese
      }
    }
  }

  // Store the last numeric string
  if (numberString.size() > 0)
    v.push_back(numberString);

  return v;
}

int main()
{
  cout << "Enter an expression: ";
  string expression;
  getline(cin, expression);
  vector<string> v = split(expression);

  for (int i = v.size() - 1; i >= 0; i--)
    cout << v[i] << endl;

  return 0;
}
