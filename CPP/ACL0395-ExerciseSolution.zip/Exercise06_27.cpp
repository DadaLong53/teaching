#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

// Find the square root of the value
double sqrt1(double num)
{
  double nextGuess = 1.0;
  double lastGuess;

  do
  {
    lastGuess = nextGuess;
    nextGuess = (lastGuess + (num / lastGuess)) * 0.5;
  }
  while (abs(nextGuess - lastGuess) >= 0.00001);

  return nextGuess;
}

int main()
{
  double number;
  cout << "Enter a number: ";
  cin >> number;
  cout << "The square root for " << number << " is " << sqrt1(number) << endl;

  return 0;
}
