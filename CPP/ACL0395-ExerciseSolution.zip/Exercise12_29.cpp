#include <iostream>
#include <vector>
#include <string>
using namespace std;

void sort(vector<char> &list)
{
	for (unsigned int i = 0; i < list.size(); i++) 
  {
    // Find the minimum in the list[i..listSize-1]
    char currentMin = list[i];
    int currentMinIndex = i;

    for (unsigned int j = i + 1; j < list.size(); j++) 
    {
      if (currentMin > list[j]) 
      {
        currentMin = list[j];
        currentMinIndex = j;
      }
    }

    // Swap list[i] with list[currentMinIndex] if necessary;
    if (currentMinIndex != i) 
    {
      list[currentMinIndex] = list[i];
      list[i] = currentMin;
    }
  }
}

bool isEqual(vector<char> &letters, vector<char> row)
{
	sort(row);

	for (unsigned int i = 0; i < row.size(); i++) 
		if (letters[i] != row[i])
			return false;
	
	return true;
}

vector<vector<char>> getTransposed(vector<vector<char>> matrix) 
{
  vector<vector<char>> result;
  for (int i = 0; i < matrix.size(); i++) 
	{
		result.push_back(vector<char>(matrix.size()));
	}

  for (int j = 0; j < matrix.size(); j++)
	{
		for (int i = 0; i < matrix.size(); i++) 
		{
			result[i][j] = matrix[j][i];
    }
  }
    
  return result;
}

int main()
{    
  cout << "Enter number n: ";
  int n;
  cin >> n;
    
	// Create letters
  vector<char> letters(n);
  for (int i = 0; i < n; i++)
    letters[i] = static_cast<char>('A' + i);

  // Enter matrix
  vector<vector<char>> matrix;
  cout << "Enter " << n << " rows of letters separated by spaces: " << endl;
  for (int i = 0; i < n; i++) 
	{
		matrix.push_back(vector<char>());
		for (int j = 0; j < n; j++)
		{
			string s;
			cin >> s;

			if (s.size() > 1) 
			{
				cout << "Wrong input: you need to enter single letters" << endl;
				return 0;
			}

			matrix[i].push_back(s[0]);
		}

		if (!isEqual(letters, matrix[i]))
		{
			cout << "Wrong input: the letters must be from " << letters[0] <<
          " to " << letters[letters.size() - 1] << endl;
			return 0;
		}
	}

	vector<vector<char>> transposedMatrix = getTransposed(matrix);
        
  for (int i = 0; i < transposedMatrix.size(); i++) 
	{
		sort(transposedMatrix[i]);
    if (!isEqual(letters, transposedMatrix[i]))
		{
      cout << "The input array is not a Latin square" << endl;
      return 0;
    }
  }

	cout << "The input array is a Latin square" << endl;

  return 0;
}