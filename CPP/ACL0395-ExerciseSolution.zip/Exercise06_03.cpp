#include <iostream>
using namespace std;

int reverse(int number) {
  int result = 0;
  while (number != 0) {
    int remainder = number % 10;

    result = result * 10 + remainder;

    number = number / 10;
  }

  return result;
}

bool isPalindrome(int number) {
  return number == reverse(number);
}

int main()
{
  int number;
  cout << "Enter a positive integer: ";
  cin >> number;

  if (isPalindrome(number))
    cout << number << " is a palindrome" << endl;
  else
    cout << number << " is not a palindrome" << endl;

  return 0;
}
