#include <iostream>
using namespace std;

int main()
{
  cout << "Enter today�s day: ";
  int today;
  cin >> today;

  cout << "Enter the number of days elapsed since today: ";
  int elapsedDays;
  cin >> elapsedDays;

  cout << "Today is ";

  if (today == 0)
	cout << "Sunday";
  else if (today == 1)
	cout << "Monday";
  else if (today == 2)
	cout <<  "Tuesday";
  else if (today == 3)
	cout <<  "Wednesday";
  else if (today == 4)
	cout <<  "Thursday";
  else if (today == 5)
	cout << "Friday";
  else // if (today == 6)
	cout << "Saturday";

  int futureDay = (today + elapsedDays) % 7;
  
  cout << " and the future day is ";
  if (futureDay == 0)
    cout << "Sunday";
  else if (futureDay == 1)
    cout << "Monday";
  else if (futureDay == 2)
    cout << "Tuesday";
  else if (futureDay == 3)
    cout << "Wednesday";
  else if (futureDay == 4)
    cout << "Thursday";
  else if (futureDay == 5)
    cout << "Friday";
  else // if (futureDay == 6)
    cout << "Saturday";

  return 0;
}
