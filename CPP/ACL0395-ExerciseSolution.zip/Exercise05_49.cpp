#include <iostream>
#include <string>
using namespace std;

int main()
{
  string s1, s2;

  cout << "Enter s1: ";
  cin >> s1;

  cout << "Enter s2: ";
  cin >> s2;

  string s3;
  for (int i = 0; i < s1.size() && i < s2.size(); i++)
  {
    if (s1[i] == s2[i])
      s3 += s1[i];
    else
      break;
  }

  if (s3.size() == 0)
    cout << "No common prefix" << endl;
  else
    cout << "The common prefix is " << s3 << endl;

  return 0;
}
