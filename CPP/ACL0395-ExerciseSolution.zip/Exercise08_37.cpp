#include <iostream>
using namespace std;

const int N = 3;

double deltaA(double A[][N])
{
  double result = A[0][0] * A[1][1] * A[2][2] +
    A[2][0] * A[0][1] * A[1][2] + A[0][2] * A[1][0] * A[2][1] -
    A[0][2] * A[1][1] * A[2][0] - A[0][0] * A[1][2] * A[2][1] -
    A[2][2] * A[1][0] * A[0][1];
  return result;
}

int main()
{
  double A[N][N];
  cout << "Enter a11, a12, a13, a21, a22, a23, a31, a32, a33: ";
  cin >> A[0][0] >> A[0][1] >> A[0][2] >>
    A[1][0] >> A[1][1] >> A[1][2] >>
    A[2][0] >> A[2][1] >> A[2][2];

  cout << "Enter b1, b2, b3: ";
  double b1, b2, b3;
  cin >> b1 >> b2 >> b3;

  double delta = deltaA(A);
  if (delta == 0)
    cout << "No solution" << endl;
  else
  {
    double x = ((A[1][1] * A[2][2] - A[1][2] * A[2][1]) * b1 +
      (A[0][2] * A[2][1] - A[0][1] * A[2][2]) * b2 +
      (A[0][1] * A[1][2] - A[0][2] * A[1][1]) * b3) / delta;
    double y = ((A[1][2] * A[2][0] - A[1][0] * A[2][2]) * b1 +
      (A[0][0] * A[2][2] - A[0][2] * A[2][0]) * b2 +
      (A[0][2] * A[1][0] - A[0][0] * A[1][2]) * b3) / delta;
    double z = ((A[1][0] * A[2][1] - A[1][1] * A[2][0]) * b1 +
      (A[0][1] * A[2][0] - A[0][0] * A[2][1]) * b2 +
      (A[0][0] * A[1][1] - A[0][1] * A[1][0]) * b3) / delta;

    cout << "The solution is " << x << " " << y << " " << z << endl;
  }

  return 0;
}
