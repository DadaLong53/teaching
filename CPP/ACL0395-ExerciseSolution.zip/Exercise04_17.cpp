#include <iostream>
#include <string>
using namespace std;

int main()
{
  // Prompt the user to enter an ISBN as a string
  cout << "Enter the first 9-digit of an ISBN number as a string: ";
  string s;
  cin >> s;

  if (s.size() != 9)
  {
    cout << "Incorrect input" << endl;
    exit(1);
  }

  // Calculate checksum
  int sum = (s[0] - '0') + (s[1] - '0') * 2 + (s[2] - '0') * 3 
    + (s[3] - '0') * 4 + (s[4] - '0') * 5 + (s[5] - '0') * 6
    + (s[6] - '0') * 7 + (s[7] - '0') * 8 + (s[8] - '0') * 9;

  int checksum = sum % 11;

  cout << "The ISBN number is ";

  cout << s;
  if (checksum == 10)
    cout << "X" << endl;
  else
    cout << checksum << endl;

  return 0;
}