#include <iostream>
using namespace std;

int main()
{
  int count = 1;
  for (int year = 2000; year <= 2100; year++) {
    if (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0))
      (count++ % 10 == 0) ? cout << year << "\n" : cout << year << " ";
  }

  return 0;
}
