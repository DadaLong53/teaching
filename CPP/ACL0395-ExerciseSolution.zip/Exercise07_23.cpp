#include <iostream>
#include <cstring>
using namespace std;

bool isEqual(const int list1[], const int list2[], int size)
{
  for (int i = 0; i < size; i++)
    if (list1[i] != list2[i])
      return false;

  return true;
}

void selectionSort(int list[], int listSize)
{
  for (int i = 0; i < listSize; i++)
  {
    // Find the minimum in the list[i..listSize-1]
    int currentMin = list[i];
    int currentMinIndex = i;

    for (int j = i + 1; j < listSize; j++)
    {
      if (currentMin > list[j])
      {
        currentMin = list[j];
        currentMinIndex = j;
      }
    }

    // Swap list[i] with list[currentMinIndex] if necessary;
    if (currentMinIndex != i)
    {
      list[currentMinIndex] = list[i];
      list[i] = currentMin;
    }
  }
}

int main()
{
  const int MAX_SIZE = 20;

  // Enter values for list1
  int list1[MAX_SIZE];
  cout << "Enter list1: ";
  int size1;
  cin >> size1;

  for (int i = 0; i < size1; i++)
    cin >> list1[i];

  // Enter values for list2
  cout << "Enter list2: ";
  int list2[MAX_SIZE];
  int size2;
  cin >> size2;

  for (int i = 0; i < size2; i++)
    cin >> list2[i];

  // Sort list1 and list2
  selectionSort(list1, size1);
  selectionSort(list2, size2);

  if (size1 != size2)
  {
    cout << "\nTwo lists are not identical" << endl;
    return 0;
  }

  if (isEqual(list1, list2, size1))
  {
    cout << "\nTwo lists are identical" << endl;
  }
  else
  {
    cout << "\nTwo lists are not identical" << endl;
  }

  return 0;
}
