#include <iostream>
#include <string>
using namespace std;

#ifndef STRING_H
#define STRING_H

class MyString : public string
{
public:
  // Return true if this string starts with the specified string
  bool startsWith(string s) const; 

  // Return true if this string ends with the specified string
  bool endsWith(string s) const; 
};
#endif

bool MyString::startsWith(string s) const
{
  if (this->size() < s.size())
    return false;

  for (unsigned i = 0; i < s.size(); i++)
    if (this->at(i) != s[i])
      return false;

  return true;
}

bool MyString::endsWith(string s) const
{
  if (this->size() < s.size())
    return false;

  for (unsigned i = 0; i < s.size(); i++)
    if (this->at(this->size() - i - 1) != s[s.size() - i - 1])
      return false;

  return true;
}

int main()
{
  MyString s1, s2;
  cout << "Enter string s1: ";
  getline(cin, s1);
  cout << "Enter string s2: ";
  getline(cin, s2);

  cout << "s1 starts with s2? " << (s1.startsWith(s2) ? "True" : "False") << endl;
  cout << "s1 ends with s2? " << (s1.endsWith(s2) ? "True" : "False") << endl;

  return 0;
}
