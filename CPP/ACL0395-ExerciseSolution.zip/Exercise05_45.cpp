#include <iostream>
using namespace std;

int main()
{
  for (int i = 1; i < 8; i++)
    for (int j = i + 1; j < 8; j++)
      cout << i << " " << j << endl;

  return 0;
}
