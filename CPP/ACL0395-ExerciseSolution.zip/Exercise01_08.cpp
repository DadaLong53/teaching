#include <iostream>
using namespace std;

int main()
{
  cout << "The area is " << 5.5 * 5.5 * 3.14159 << endl;
  cout << "The perimeter is " << 2 * 5.5 * 3.14159 << endl;
  return 0;
}
