#include <iostream>
#include <string>
#include <vector>
#include <fstream>
using namespace std;

vector<string> boyNames;
vector<int> boyCounts;
vector<string> girlNames;
vector<int> girlCounts;

int indexOf(const vector<string>& v, const string& name) 
{
  for (unsigned i = 0; i < v.size(); i++)
    if (v[i] == name)
      return i;
    
  return -1;
}

void processName(vector<string>& names, vector<int>& counts, const string& name, int count) 
{
  int k = indexOf(names, name);
  if (k >= 0)
    counts[k] += count;
  else 
  {
    names.push_back(name);
    counts.push_back(count);
  }
}

void readNames() 
{
  for (int i = 0; i < 10; i++) 
  {
    string filename;
    if (i == 9)
      filename = "C:\\cplusplusexercise\\Babynamesranking2010.txt";
    else
    {
      filename += "C:\\cplusplusexercise\\Babynamesranking200";
      filename += static_cast<char>((i + 1) + '0');
      filename += ".txt";
    }

    ifstream input(filename.c_str());
      
    string boyName, girlName;
    int boyCount, girlCount;

    int j = 0;
    while (!input.eof()) // (int j = 0; j < 1000; j++)
    {
      int dummy;
      input >> dummy; // Skip the ranking

      input >> boyName >> boyCount;
      processName(boyNames, boyCounts, boyName, boyCount);

      input >> girlName >> girlCount;
      processName(girlNames, girlCounts, girlName, girlCount);
      j++;
    }
  }
}

void displayNames() 
{
  cout << "Boys Ranking, Name, and Count: " << endl;
  for (int i = 0; i < boyNames.size(); i++) 
  {
    cout << i + 1 + " ";
    cout << boyNames[i] << " ";
    cout << boyCounts[i] << " " << endl;
  }
    
  cout << "Girls Ranking, Name, and Count: " << endl;
  for (int i = 0; i < girlNames.size(); i++) 
  {
    cout << i + 1 << " ";
    cout << girlNames[i] << " ";
    cout << girlCounts[i] << " " << endl;
  }
}

// Sort in decreasing order
void sort(vector<string>& names, vector<int>& counts) 
{
  for (int i = 0; i < counts.size() - 1; i++)
  {
    int currentMin = counts[i];
    int currentMinIndex = i;

    for (int j = i + 1; j < counts.size(); j++) 
    {
      if (currentMin < counts[j]) 
      {
        currentMin = counts[j];
        currentMinIndex = j;
      }
    }

    // Swap list[i] with list[currentMinIndex] if necessary;
    if (currentMinIndex != i) 
    {
      counts[currentMinIndex] = counts[i];
      counts[i] = currentMin;
        
      // Swap the corresponding names as well
      string temp = names[currentMinIndex];
      names[currentMinIndex] = names[i];
      names[i] = temp;        
    }
  }   
}

int main()
{
  readNames();
  sort(boyNames, boyCounts);
  displayNames();

  return 0;
}
