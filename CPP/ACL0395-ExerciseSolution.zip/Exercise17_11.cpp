#include <iostream>
using namespace std;

int sumDigits(long n)
{
  int result = 0;

  if (n != 0)
  {
    result = sumDigits(n / 10) + (int)(n % 10);
  }

  return result;
}

int main()
{
  cout << "Ente an integer: ";
  int n;
  cin >> n;

  cout << sumDigits(n) << endl;

  return 0;
}
