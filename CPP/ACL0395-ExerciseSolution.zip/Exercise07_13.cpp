#include <iostream>
using namespace std;

void eliminateDuplicates(int numbers[], int size1,
  int nonDupNumbers[], int &size2)
{
 size2 = 0;
 for (int i = 0; i < size1; i++) {
   bool isInArray = false;
   for (int j = 0; j < i && !isInArray; j++)
     if (numbers[j] == numbers[i]) {
       isInArray = true;
     }

   if (!isInArray) {
     nonDupNumbers[size2] = numbers[i];
     size2++;
   }
 }
}

int main()
{
  int numbers[10];
  int newNumbers[10];

  cout << "Enter ten integers: ";
  for (int i = 0; i < 10; i++) {
    // Read and store numbers in an array
    cin >> numbers[i];
  }

  int size = 0;
  eliminateDuplicates(numbers, 10, newNumbers, size);

  cout << "The number of distinct values is " << size << endl;

  cout << "The distinct numbers are: ";
  for (int i = 0; i < size; i++)
    cout << newNumbers[i] << " ";

  return 0;
}
