#include <iostream>
#include <cmath>
using namespace std;

int main()
{
  int counts[10] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

  for (int i = 0; i < 100; i++)
  {
    int value = rand() % 10;
    counts[value] ++;
  }

  for (int i = 0; i < 10; i++)
  {
    cout << "Count for " << i << " is " << counts[i] << endl;
  }

  return 0;
}
