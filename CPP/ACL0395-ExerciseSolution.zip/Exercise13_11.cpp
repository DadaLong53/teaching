#include <iostream>
#include <string>
#include <fstream>
using namespace std;

int main()
{
  ifstream input("c:\\cplusplusexercise\\SortedStrings.txt"); 

  string s1;
  input >> s1;

  while (!input.eof()) 
  {
    string s2;
    input >> s2;
    
    if (!input.eof() && s1 > s2) 
    {
      cout << "The two strings " << s1 << " and " << s2 << " are out of order" << endl;
      return 1;
    }

    s1 = s2;
  }
    
  cout << "The file is sorted" << endl;

  input.close();

  return 0;
}
