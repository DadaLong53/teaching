#include <iostream>
#include <cmath>
using namespace std;

int lcm(int number1, int number2);
int pow(int a, int b);
int getPrimeFactors(int number, int table[][2]);

int main()
{
  // Enter two integers
  int number1;
  cout << "Enter the first integer: ";
  cin >> number1;

  int number2;
  cout << "Enter the second integer: ";
  cin >> number2;

  cout << "The LCM for " <<  number1 <<  " and " << number2 <<  " is " <<
    lcm(number1, number2) << endl;
}

int lcm(int number1, int number2)
{
  int table1[100][2];
  for (int i = 0; i < 100; i++)
    for (int j = 0; j < 2; j++)
      table1[i][j] = 0;

  int i1 = getPrimeFactors(number1, table1);

  int table2[100][2];
  for (int i = 0; i < 100; i++)
    for (int j = 0; j < 2; j++)
      table2[i][j] = 0;

  int i2 = getPrimeFactors(number2, table2);

  int result = 1;

  int i = 0;
  int j = 0;
  while (i < i1 && j < i2)
  {
    if (table1[i] [0] < table2[j] [0])
    {
      result *= pow(table1[i] [0], table1[i] [1]);
      i++;
    }
    else if (table1[i] [0] == table2[j] [0])
    {
      result *= pow(table1[i] [0], max(table1[i] [1], table2[j] [1]));
      i++;
      j++;
    }
    else
    {
      result *= pow(table2[j] [0], table2[j] [1]);
      j++;
    }
  }

  while (i < i1)
  {
    result *= pow(table1[i] [0], table1[i] [1]);
    i++;
  }

  while (j < i2)
  {
    result *= pow(table2[j] [0], table2[j] [1]);
    j++;
  }

  return result;
}

int pow(int a, int b)
{
  int result = 1;
  for (int i = 1; i <= b; i++)
    result *= a;
  return result;
}

int getPrimeFactors(int number, int table[][2])
{
  int i = 0;
  int factor = 2;
  while (factor <= number)
  {
    if (number % factor == 0)
    {
      table[i] [0] = factor;
      while (number % factor == 0)
      {
        number = number / factor;
        table[i] [1] ++;
      }
      i++;
    }
    else
    {
      factor++;
    }
  }

  return i;
}
