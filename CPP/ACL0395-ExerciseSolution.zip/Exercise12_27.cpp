#include <iostream>
#include <vector>
using namespace std;

vector<int> findLargestBlock(const vector<vector<int> >& m);

int main()
{
  cout << "Enter the number of rows in the square matrix: ";
  int numberOfRows;
  cin >> numberOfRows;
	
  vector<vector<int>> m(numberOfRows);
  for (unsigned i = 0; i < numberOfRows; i++)
    m[i] = vector<int>(numberOfRows); // Each row has numberOfRows columns
    
  cout << "Enter the matrix row by row: ";
    
  for (unsigned i = 0; i < numberOfRows; i++) 
    for (unsigned j = 0; j < numberOfRows; j++)
      cin >> m[i][j];

  vector<int> result = findLargestBlock(m);
    
  cout << "The maximum square submatrix is at (" << result[0] << ", " << 
        result[1] << ") with size " << result[2] << endl;

  return 0;
}
  
vector<int> findLargestBlock(const vector<vector<int> >& m)
{
	vector< vector<int> > count(m.size());
	for (int i = 0; i < m.size(); i++)
	  count[i] = vector<int>(m.size()); 
    
	for (int i = m.size() - 1; i >= 0; i--)
	  for (int j = m[i].size() - 1; j >= 0; j--) 
			if (m[i][j] == 1) 
			{
				count[i][j] = 1;
				if (i < m.size() - 1 && j < m[i].size() - 1 && m[i + 1][j + 1] == 1)
				{
					// Check to expand the block with (i, j) at its upper right corner
					for (unsigned k = 1; k <= count[i + 1][j + 1]; k++)
						if (m[i][j + k] == 1 && m[i + k][j] == 1) 
						  count[i][j] += 1;
						else 
						  break;
				}
			}

	int max = count[0][0];
	int maxOfx = 0;
	int maxOfy = 0;
	for (int i = 0; i < m.size(); i++)
		for (int j = 0; j < m[i].size(); j++)
		if (count[i][j] > max)
		{
			max = count[i][j];
			maxOfx = i;
			maxOfy = j;
		}
          
	vector<int> result(3);
	result[0] = maxOfx;
	result[1] = maxOfy;
	result[2] = max;
 
	return result;
}