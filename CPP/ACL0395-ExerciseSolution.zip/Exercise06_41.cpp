#include <iostream>
#include <string>
using namespace std;

string reverse(string s)
{
  string result(s);
  int i = 0;

  for (int i = 0, j = s.length() - 1; i < s.length(); i++, j--)
    result[i] = s[j];

  return result;
}

string convertDecimalToBinary(int value)
{
  string s;

  while (value != 0)
  {
    int bit = value % 2;
    value = value / 2;
    s.append(1, (char)(bit + '0'));
  }

  return reverse(s);
}

int main()
{
  cout << "Enter a decimal number: ";
  int number;
  cin >> number;
  cout << convertDecimalToBinary(number) << endl;

  return 0;
}
