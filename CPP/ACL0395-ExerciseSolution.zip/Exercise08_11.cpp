#include <iostream>
using namespace std;

void toBinaryChars(short number, char binaryChars[]);

int main()
{
  cout << "Enter a number between 0 and 511: ";
  short number;
  cin >> number;

  char binaryChars[9];
  toBinaryChars(number, binaryChars);

  for (int i = 1; i <= 9; i++)
  {
    cout << ((binaryChars[i - 1] == '0') ? 'H' : 'T') << " ";
    if (i % 3 == 0)
      cout << endl;
  }

  return 0;
}

void toBinaryChars(short number, char binaryChars[])
{
  int i = 8;
  while (number != 0)
  {
    if (number % 2 == 0)
      binaryChars[i--] = '0';
    else
      binaryChars[i--] = '1';
    number /= 2;
  }

  for (int k = i; k >= 0; k--)
    binaryChars[k] = '0';
}
