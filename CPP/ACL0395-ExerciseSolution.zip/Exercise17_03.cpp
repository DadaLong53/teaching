#include <iostream>
using namespace std;

int gcd(int m, int n) 
{
  if (m % n == 0)
    return n;
  else
    return gcd(n, m % n);
}

int main()
{
  // Enter the first number
  cout << "Enter the first number: ";
  int m;
  cin >> m;

  // Enter the first number
  cout << "Enter the second number: ";
  int n;
  cin >> n;

  cout << "The GCD of " << m << " and " << n << " is " <<
    gcd(m, n) << endl;

  return 0;
}
