#include <iostream>
using namespace std;

class Circle
{
public:
  Circle();
  Circle::Circle(double newRadius);

  double getArea() const;
  double Circle::getRadius() const;
  void Circle::setRadius(double newRadius);
  bool Circle::operator<(const Circle& c) const;
  bool Circle::operator<=(const Circle& c) const;
  bool Circle::operator == (const Circle & c) const;
  bool Circle::operator != (const Circle & c) const;
  bool Circle::operator > (const Circle & c) const;
  bool Circle::operator >= (const Circle& c) const;

private:
  double radius;
};

Circle::Circle()
{
  radius = 1;
}

Circle::Circle(double newRadius)
{
  radius = newRadius;
}

double Circle::getArea() const
{
  return radius * radius * 3.14159;
}

double Circle::getRadius() const
{
  return radius;
}

void Circle::setRadius(double newRadius) 
{
  radius = (newRadius >= 0) ? newRadius : 0;
}


bool Circle::operator<(const Circle& c) const
{
  return radius < c.getRadius();
}

bool Circle::operator<=(const Circle& c) const
{
  return radius <= c.getRadius();
}

bool Circle::operator==(const Circle& c) const
{
  return radius == c.getRadius();
}

bool Circle::operator!=(const Circle& c) const
{
  return radius != c.getRadius();
}

bool Circle::operator>(const Circle& c) const
{
  return radius > c.getRadius();
}

bool Circle::operator>=(const Circle& c) const
{
  return radius >= c.getRadius();
}

int main()
{
  Circle c1(5);
  Circle c2(6);

  cout << (c1 < c2) << endl;
  cout << (c1 <= c2) << endl;
  cout << (c1 == c2) << endl;
  cout << (c1 != c2) << endl;
  cout << (c1 > c2) << endl;
  cout << (c1 >= c2) << endl;

  return 0;
}