#include <iostream>
using namespace std;

const int ROW_SIZE = 3;
const int COLUMN_SIZE = 4;
void locateLargest(const double a[][4], int location[]) 
{
  int row = 0;
  int column = 0;
  double maxValue = a[0][0];

  for (int i = 0; i < ROW_SIZE; i++)
    for (int j = 0; j < COLUMN_SIZE; j++)
      if (maxValue < a[i][j]) 
      {
	      row = i;
		    column = j;
	      maxValue = a[i][j];
	    }

  location[0] = row;
  location[1] = column;
}

int main()
{
  double p[ROW_SIZE][COLUMN_SIZE];

  // Enter the two-dimensional array
  cout << "Enter a 3 by 4 two-dimensional array: " << endl;
  for (int i = 0; i < ROW_SIZE; i++)
    for (int j = 0; j < COLUMN_SIZE; j++)
      cin >> p[i][j];
 
  int loc[2];
  locateLargest(p, loc);
  
  cout << "The location of the largest element is " <<
     p[loc[0]][loc[1]] << " at (" << loc[0] << ", " << loc[1] << ")" << endl;
 
  return 0;
}