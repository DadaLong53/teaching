#include <iostream>
#include <cmath>
#include "RationalWithOperators.h"
using namespace std;

int main()
{
  cout << "Enter a, b, c: ";
  int a, b, c;
  cin >> a >> b >> c;

  Rational h(-b, 2 * a);
  Rational k(4 * a * c - b * b, 4 * a);

  cout << "h is " << h << " " << "k is " << k << endl;

  return 0;
}

