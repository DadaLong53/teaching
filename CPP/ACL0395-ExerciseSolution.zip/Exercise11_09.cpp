#include <iostream>
#include <cmath>
using namespace std;

class Rectangle2D
{
private:
  double x, y; // Center of the rectangle
  double width, height;

public:
  Rectangle2D()
  {
    x = y = 0;
    width = height = 1;
  }

  Rectangle2D(double x, double y, double width, double height)
  {
    this->x = x;
    this->y = y;
    this->width = width;
    this->height = height;
  }


  double getX() const 
  {
    return x;
  }

  void setX(double x)
  {
    this->x = x;
  }

  double getY() const 
  {
    return y;
  }

  void setY(double y)
  {
    this->y = y;
  }

  double getWidth() const 
  {
    return width;
  }

  void setWidth(double width)
  {
    this->width = width;
  }

  double getHeight() const 
  {
    return height;
  }

  void setHeight(double height)
  {
    this->height = height;
  }

  double getPerimeter() const 
  {
    return 2 * (width + height);
  }

  double getArea() const 
  {
    return width * height;
  }

  bool contains(double x, double y) const 
  {
    return abs(x - this->x) <= width / 2 && abs(y - this->y) <= height / 2;
  }

  bool contains(const Rectangle2D & r) const 
  {
    return contains(r.x - r.width / 2, r.y + r.height / 2) && contains(r.x - r.width / 2, r.y - r.height / 2)
         && contains(r.x + r.width / 2, r.y + r.height / 2) && contains(r.x + r.width / 2, r.y - r.height / 2);
  }

  bool overlaps(const Rectangle2D & r) const 
  {
    return abs(r.x - x) <= (r.width + width) / 2 && abs(r.y - y) <= (r.height + height) / 2;
  }

  static double distance(double x1, double y1, double x2, double y2)
  {
    return sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
  }
};


int main()
{
  Rectangle2D r1(2, 2, 5.5, 4.9);
  cout << "Area: " << r1.getArea() << endl;
  cout << "Perimeter: " << r1.getPerimeter() << endl;

  cout << r1.contains(3, 3) << endl;
  Rectangle2D r2(4, 5, 10.5, 3.2);
  cout << r1.contains(r2) << endl;

  Rectangle2D r3(4, 5, 10.5, 3.2);
  cout << r1.overlaps(r3) << endl;

  return 0;
}
