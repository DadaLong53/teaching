#include <iostream>
#include <cmath>
using namespace std;

const int SIZE = 2;

bool linearEquation(const double a[][SIZE], const double b[], 
  double result[]);
bool getIntersectingPoint(const double points[][SIZE], 
  double result[]);
double getTriangleArea(double points[][SIZE]);
double distance(double x1, double y1, double x2, double y2); 
void selectionSort(double list[], int listSize);

int main()
{
  double p[4][2];    
  cout << "Enter x1, y1, x2, y2, x3, y3, x4, y4: ";
  for (int i = 0; i < 4; i++)
    for (int j = 0; j < 2; j++)
      cin >> p[i][j];

  double points[4][2];
  points[0][0] = p[0][0]; points[0][1] = p[0][1];
  points[1][0] = p[2][0]; points[1][1] = p[2][1];
  points[2][0] = p[1][0]; points[2][1] = p[1][1];
  points[3][0] = p[3][0]; points[3][1] = p[3][1];
  double x[2];
  bool status = getIntersectingPoint(points, x);
            
  double areas[4];
  double trianglePoints[3][2];   
  trianglePoints[0][0] = p[0][0]; trianglePoints[0][1] = p[0][1];
  trianglePoints[1][0] = p[1][0]; trianglePoints[1][1] = p[1][1];
  trianglePoints[2][0] = x[0]; trianglePoints[2][1] = x[1];    
  areas[0] = getTriangleArea(trianglePoints);
    
  trianglePoints[0][0] = p[2][0]; trianglePoints[0][1] = p[2][1];
  trianglePoints[1][0] = p[1][0]; trianglePoints[1][1] = p[1][1];
  areas[1] = getTriangleArea(trianglePoints);

  trianglePoints[0][0] = p[2][0]; trianglePoints[0][1] = p[2][1];
  trianglePoints[1][0] = p[3][0]; trianglePoints[1][1] = p[3][1];
  // trianglePoints[2][0] = x[0]; trianglePoints[2][1] = x[1];    
  areas[2] = getTriangleArea(trianglePoints);

  trianglePoints[0][0] = p[0][0]; trianglePoints[0][1] = p[0][1];
  trianglePoints[1][0] = p[3][0]; trianglePoints[1][1] = p[3][1];
  // trianglePoints[2][0] = x[0]; trianglePoints[2][1] = x[1];    
  areas[3] = getTriangleArea(trianglePoints);

  cout << "The areas are ";
  selectionSort(areas, 4);
  for (int i = 0; i < 4; i++)
    cout << areas[i] << " ";
  cout << endl;
  return 0;
}

bool getIntersectingPoint(const double p[][SIZE], 
  double result[])
{
  double k1 = (p[0][0] - p[1][0]) / (p[0][1] - p[1][1]);
  double k2 = (p[2][0] - p[3][0]) / (p[2][1] - p[3][1]);

  double a[2][2];
  double b[2];
  a[0][0] = 1;
  a[0][1] = k1;
  a[1][0] = 1;
  a[1][1] = k2;
  b[0] = p[0][0] - k1 * p[0][1];
  b[1] = p[2][0] - k2 * p[2][1];

  return linearEquation(a, b, result);
}

bool linearEquation(const double a[][SIZE], const double b[], 
  double result[])
{
  double detA = a[0][0] * a[1][1] - a[0][1] * a[1][0];
  if (detA == 0) 
    return false;
  else 
  {
    result[0] = (b[0] * a[1][1] - b[1] * a[0][1]) / detA;
    result[1] = (b[1] * a[0][0] - b[0] * a[1][0]) / detA;
      
    return true;
  }
}

double getTriangleArea(double p[][SIZE])
{
  double s1 = distance(p[0][0], p[0][1], p[1][0], p[1][1]);
  double s2 = distance(p[0][0], p[0][1], p[2][0], p[2][1]);
  double s3 = distance(p[2][0], p[2][1], p[1][0], p[1][1]);
  double s = (s1 + s2 + s3) / 2;
  double area = s * (s - s1) * (s - s2) * (s - s3);
    
  if (area < 0.0000000000001)
    return 0;
  else
    return sqrt(area);
}

double distance(double x1, double y1, double x2, double y2) 
{
  double d = sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
  return d;
}

void selectionSort(double list[], int listSize)
{
  for (int i = 0; i < listSize; i++)
  {
    // Find the minimum in the list[i..listSize-1]
    double currentMin = list[i];
    int currentMinIndex = i;

    for (int j = i + 1; j < listSize; j++)
    {
      if (currentMin > list[j])
      {
        currentMin = list[j];
        currentMinIndex = j;
      }
    }

    // Swap list[i] with list[currentMinIndex] if necessary;
    if (currentMinIndex != i)
    {
      list[currentMinIndex] = list[i];
      list[i] = currentMin;
    }
  }
}