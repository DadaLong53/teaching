#include <iostream>
#include <string>
#include "NewRational.h"
using namespace std;

template < typename T >
int binarySearch(T list[], T key, int arraySize)
{
  int low = 0;
  int high = arraySize - 1;

  while (high >= low)
  {
    int mid = (low + high) / 2;
    if (key < list[mid])
      high = mid - 1;
    else if (key == list[mid])
      return mid;
    else
      low = mid + 1;
  }

  return -low - 1;
}

int main()
{
  int intArray[] =
  {
    1, 2, 3, 4, 8, 15, 23, 31
  };
  cout << "binarySearch(intArray, 3, 8) is " << binarySearch(intArray, 3, 8) << endl;
  cout << "binarySearch(intArray, 10, 8) is " << binarySearch(intArray, 10, 8) << endl;

  return 0;
}
