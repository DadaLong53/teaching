#include <iostream>
using namespace std;

class EvenNumber
{
public:
  EvenNumber()
  {
    value = 0;
  }

  // Constructor
  EvenNumber(int newValue)
  {
    value = newValue;
  }

  int getValue()
  {
    return value;
  }

  EvenNumber getNext()
  {
    return EvenNumber(value + 2);
  }

  EvenNumber getPrevious()
  {
    return EvenNumber(value - 2);
  } 

  EvenNumber& operator++()
  {
    value += 2;
    return EvenNumber(value);
  }

  EvenNumber& operator++(int dummy)
  {
    value += 2;
    return EvenNumber(value - 2);
  }
    
  EvenNumber& operator--()
  {
    value -= 2;
    return EvenNumber(value);
  }

  EvenNumber& operator--(int dummy)
  {
    value -= 2;
    return EvenNumber(value + 2);
  }

// Data members
private:
  int value;
};

int main() {
  EvenNumber t(16);
  t++;
  cout << t.getValue() << endl;

  t--;
  cout << t.getValue() << endl;

  return 0;
}