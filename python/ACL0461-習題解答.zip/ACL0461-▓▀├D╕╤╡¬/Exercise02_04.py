pounds = eval(input("Enter a number in pounds: "))

kilograms = pounds * 0.454;

print(pounds, "pounds is", kilograms, "kilograms")
