print(4.5 * 7.9)
print(2 * (4.5 + 7.9))
