import turtle

turtle.right(60)
turtle.forward(50)
turtle.right(120)
turtle.forward(50)
turtle.right(120)
turtle.forward(100)

turtle.left(120)
turtle.forward(50)
turtle.left(120)
turtle.forward(50)

turtle.done() 
