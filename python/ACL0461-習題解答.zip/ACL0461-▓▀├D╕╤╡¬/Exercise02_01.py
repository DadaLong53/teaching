# Prompt the user to enter a degree in Celsius
celsius = eval(input("Enter a degree in Celsius: "))

# Convert it to Fahrenheit
fahrenheit = (9 / 5) * celsius + 32 

# Display the result
print(celsius, "Celsius is", fahrenheit, "Fahrenheit")
