i = 1

while i * i <= 12000:
    i += 1

print("This number is", i)
