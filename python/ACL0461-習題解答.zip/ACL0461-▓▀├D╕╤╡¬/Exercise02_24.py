import turtle

turtle.penup()
turtle.goto(-25, 0)
turtle.pendown()
turtle.circle(25, steps = 6) 

turtle.penup()
turtle.goto(-25, -50)
turtle.pendown()
turtle.circle(25, steps = 6) 

turtle.penup()
turtle.goto(25, 0)
turtle.pendown()
turtle.circle(25, steps = 6) 

turtle.penup()
turtle.goto(25, -50)
turtle.pendown()
turtle.circle(25, steps = 6) 

input("Press any key to exit...")
