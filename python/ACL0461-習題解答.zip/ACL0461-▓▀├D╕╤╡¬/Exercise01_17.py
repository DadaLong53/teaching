import turtle

turtle.penup()
turtle.goto(-39, 48) 
turtle.pendown()

turtle.write("(-39, 48)")
turtle.goto(50, -50) 
turtle.write("(50, -50)")

turtle.done()
