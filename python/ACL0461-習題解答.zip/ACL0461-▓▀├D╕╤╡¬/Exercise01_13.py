import turtle

turtle.forward(50)
turtle.right(180)
turtle.forward(100)
turtle.right(180)
turtle.forward(50)

turtle.left(90)
turtle.forward(50)
turtle.left(180)
turtle.forward(100)

turtle.done() 
