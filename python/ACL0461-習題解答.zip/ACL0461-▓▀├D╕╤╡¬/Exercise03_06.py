# Prompt the user to enter a degree in Celsius
code = eval(input("Enter an ASCII code: "))

# Display result
print("The character for ASCII code", code, "is", chr(code))
