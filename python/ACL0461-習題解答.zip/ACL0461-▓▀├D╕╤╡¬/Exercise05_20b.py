for i in range(1, 6 + 1):
    for j in range(1, 7 - i + 1):
        print(j, end = " ")
    print()
