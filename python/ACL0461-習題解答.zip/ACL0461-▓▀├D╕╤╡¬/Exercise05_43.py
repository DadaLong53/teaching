count = 0
for i in range(1, 8): 
    for j in range(i + 1, 8):
        print(str(i) + " " + str(j))
        count += 1
  
print("The total number of all combinations is", count)
