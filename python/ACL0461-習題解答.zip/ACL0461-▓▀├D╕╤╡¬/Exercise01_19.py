import turtle

turtle.penup()
turtle.goto(80, 0)  
turtle.pendown()

turtle.goto(40, -69.28)  
turtle.goto(-40, -69.28)  
turtle.goto(-80, -9.8)  
turtle.goto(-40, 69)  
turtle.goto(40, 69)  
turtle.goto(80, 0)  
            
turtle.hideturtle()

turtle.done()
