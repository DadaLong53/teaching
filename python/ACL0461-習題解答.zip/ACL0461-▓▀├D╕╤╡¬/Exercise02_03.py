feet = eval(input("Enter a value for feet: "))

meter = feet * 0.305

print(feet, "feet is", meter, "meters")
