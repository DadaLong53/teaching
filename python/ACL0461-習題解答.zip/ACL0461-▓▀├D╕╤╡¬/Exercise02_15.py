# Enter the side of the hexagon
side = eval(input("Enter the side: "))
    
# Compute the area
area = 3 * 1.732 * side * side / 2
    
print("The area of the hexagon is", area)
