print("Welcome to Python")
print("Welcome to Computer Science")
print("Programming is fun")
