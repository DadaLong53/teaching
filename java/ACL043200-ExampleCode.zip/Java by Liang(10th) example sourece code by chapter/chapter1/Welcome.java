package chapter1;

public class Welcome {
	public static void main(String[] args) {
		// Display message Welcome to Java! on the console
		System.out.println("Welcome to Java!");
	}
}