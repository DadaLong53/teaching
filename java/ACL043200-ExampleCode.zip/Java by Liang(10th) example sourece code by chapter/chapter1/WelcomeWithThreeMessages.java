package chapter1;

public class WelcomeWithThreeMessages { 
  public static void main(String[] args) { 
    System.out.println("Programming is fun!");
    System.out.println("Fundamentals First");
    System.out.println("Problem Driven");
  }
}
