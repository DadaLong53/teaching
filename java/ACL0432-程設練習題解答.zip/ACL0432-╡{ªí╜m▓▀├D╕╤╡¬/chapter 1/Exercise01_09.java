public class Exercise01_09 {
  public static void main(String[] args) {
  	// Display area
    System.out.println(5.3 * 8.6);

    // Display perimeter
    System.out.println(2 * (5.3 + 8.6));
  }
}
