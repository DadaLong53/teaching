public class Exercise01_10 {
  public static void main(String[] args) {
    System.out.println((1 / 50.5) * 60 * 15 / 1.6 );
  }
}
