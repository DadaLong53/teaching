public class Exercise01_02 {
  public static void main(String[] args) {
    System.out.println("I love Java");
    System.out.println("I love Java");
    System.out.println("I love Java");
    System.out.println("I love Java");
    System.out.println("I love Java");
  }
}
