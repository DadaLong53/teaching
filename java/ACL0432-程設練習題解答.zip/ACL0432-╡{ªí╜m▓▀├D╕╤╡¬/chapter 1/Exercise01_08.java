public class Exercise01_08 {
  public static void main(String[] args) {
  	// Display area
    System.out.println(6.5 * 6.5 * 3.14159);

    // Display perimeter
    System.out.println(2 * 6.5 * 3.14159);

  }
}
