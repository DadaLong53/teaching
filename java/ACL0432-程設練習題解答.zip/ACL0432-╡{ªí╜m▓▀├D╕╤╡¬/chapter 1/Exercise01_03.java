public class Exercise01_03 {
  public static void main(String[] args) {
      System.out.println("    J                     ");  
	  System.out.println("    J  aaa   v   v  aaa   ");   
	  System.out.println("J   J  a a    v v   a a   ");
	  System.out.println("  J    aaaa    v    aaaa  ");
  }
}
