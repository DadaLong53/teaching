import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Exercise14_13 extends Application {
  @Override // Override the start method in the Application class
  public void start(Stage primaryStage) {       
    Pane pane = new Pane();
       
    Arc arc1 = new Arc(100, 100, 80, 80, 0, 360 * 0.2);
    arc1.setFill(Color.RED);
    arc1.setType(ArcType.ROUND);
    Text text1 = new Text(110, 80, "Apple -- 20%");
    
    Arc arc2 = new Arc(100, 100, 80, 80, 360 * 0.2, 360 * 0.26);
    arc2.setFill(Color.BLUE);
    arc2.setType(ArcType.ROUND);
    Text text2 = new Text(80, 15, "HTC -- 26%");

    Arc arc3 = new Arc(100, 100, 80, 80, 360 * 0.2 + 360 * 0.26, 360 * 0.28);
    arc3.setFill(Color.GREEN);
    arc3.setType(ArcType.ROUND);
    Text text3 = new Text(5, 100, "Samsung -- 28%");

    Arc arc4 = new Arc(100, 100, 80, 80, 360 * 0.2 + 360 * 0.26 + 360 * 0.28, 360 * 0.26);
    arc4.setFill(Color.ORANGE);
    arc4.setType(ArcType.ROUND);
    Text text4 = new Text(100, 180, "Others -- 26%");

    pane.getChildren().addAll(arc1, text1, arc2, text2, arc3, text3, arc4, text4);

    // Create a scene and place it in the stage
    Scene scene = new Scene(pane, 200, 200);
    primaryStage.setTitle("Exercise14_13"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.show(); // Display the stage
  }

  /**
   * The main method is only needed for the IDE with limited
   * JavaFX support. Not needed for running from the command line.
   */
  public static void main(String[] args) {
    launch(args);
  }
} 
