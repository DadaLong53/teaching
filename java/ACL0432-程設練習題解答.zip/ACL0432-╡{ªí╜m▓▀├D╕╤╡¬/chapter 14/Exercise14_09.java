import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

public class Exercise14_09 extends Application {
  @Override // Override the start method in the Application class
  public void start(Stage primaryStage) {       
    GridPane pane = new GridPane();
            
    pane.add(new CircleTaichi1(), 0, 0);
    pane.add(new CircleTaichi1(), 1, 0);
    pane.add(new CircleTaichi1(), 0, 1);
    pane.add(new CircleTaichi1(), 1, 1);
   
    // Create a scene and place it in the stage
    Scene scene = new Scene(pane, 250, 250);
    primaryStage.setTitle("Exercise14_09"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.show(); // Display the stage
  }

  /**
   * The main method is only needed for the IDE with limited
   * JavaFX support. Not needed for running from the command line.
   */
  public static void main(String[] args) {
    launch(args);
  }
} 


class CircleTaichi1 extends Pane{
	double radius = 50;
	
public CircleTaichi1(){
	Circle circle = new Circle(60, 60, radius);
    circle.setStroke(Color.BLACK);
    circle.setFill(Color.WHITE);
    circle.setStrokeWidth(1);
    getChildren().add(circle);
    
    Arc arc1 = new Arc(60, 60, radius, radius, 270, 180);
    arc1.setFill(Color.BLACK);
    arc1.setType(ArcType.ROUND);
    Arc arc2 = new Arc(60, 35, radius/2, radius/2, 360, 360);
    arc2.setFill(Color.BLACK);
    arc2.setType(ArcType.ROUND);
    Arc arc3 = new Arc(60, 85, radius/2, radius/2, 360, 360);
    arc3.setFill(Color.WHITE);
    arc3.setType(ArcType.ROUND);
    Arc arc4 = new Arc(60, 35, radius/6, radius/6, 360, 360);
    arc4.setFill(Color.WHITE);
    arc4.setType(ArcType.ROUND);
    Arc arc5 = new Arc(60, 85, radius/6, radius/6, 360, 360);
    arc5.setFill(Color.BLACK);
    arc5.setType(ArcType.ROUND);
    getChildren().addAll(arc1, arc2, arc3, arc4, arc5); 
 
    
    }
}
