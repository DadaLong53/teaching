import java.util.ArrayList;

public class Exercise13_02 {
  public static void main(String[] args) {
    ArrayList<Integer> list = new ArrayList<Integer>();
    list.add(14);
    list.add(24);
    list.add(4);
    list.add(42);
    list.add(5);
    average(list);
    
  } 
  public static void average(ArrayList<Integer> list) {
	  double total = 0;
	  for (int i = 0; i < list.size(); i++) {
		  total += list.get(i);
      }
	  System.out.print(total/list.size());
  }
}
