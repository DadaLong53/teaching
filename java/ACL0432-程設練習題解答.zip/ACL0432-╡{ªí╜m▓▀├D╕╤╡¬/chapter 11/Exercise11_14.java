import java.util.Scanner;
import java.util.ArrayList;

public class Exercise11_14 {
  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    System.out.print("Enter five character for list1: ");
    ArrayList<String> list1 = new ArrayList<String>();
    String[] inputStrings;
    inputStrings = input.nextLine().split(" ");
    for (int i = 0; i < inputStrings.length; i++)
      list1.add(inputStrings[i]);

    System.out.print("Enter five character for list2: ");
    ArrayList<String> list2 = new ArrayList<String>();
    inputStrings = input.nextLine().split(" ");
    for (int i = 0; i < inputStrings.length; i++)
        list2.add(inputStrings[i]);
    
    ArrayList<String> list3 = union(list1, list2);
      
    System.out.print("The combined list is ");
    for (int i = 0; i < list3.size(); i++) 
      System.out.print(list3.get(i) + " ");
  }
  
  public static ArrayList<String> union(
      ArrayList<String> list1, ArrayList<String> list2) {
    ArrayList<String> result = new ArrayList<String>();
    
    for (int i = 0; i < list1.size(); i++)
      result.add(list1.get(i));
    
    for (int i = 0; i < list2.size(); i++)
      result.add(list2.get(i));

    return result;
  }
}
