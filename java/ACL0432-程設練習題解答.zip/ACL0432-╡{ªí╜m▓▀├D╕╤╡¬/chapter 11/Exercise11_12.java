import java.util.ArrayList;
import java.util.Scanner;

public class Exercise11_12 {
  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);

    ArrayList<Double> list = new ArrayList<Double>();
    System.out.print("Enter five double values: ");
    for (int i = 0; i < 5; i++)
      list.add(input.nextDouble());

    System.out.println("The mutiplication is " + mutiply(list));
  }

  public static double mutiply(ArrayList<Double> list) {
    double ans = 1;
    for (int i = 0; i < list.size(); i++)
      ans *= list.get(i);
    return ans;
  }
}
