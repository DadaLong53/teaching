import java.util.Scanner;
import java.util.ArrayList;

public class Exercise11_13 {
  public static void main(String[] args) {
    System.out.print("Enter twenty integers: ");
    ArrayList<Integer> list = new ArrayList<>();
    Scanner input = new Scanner(System.in);
    for (int i = 0; i < 20; i++) {
      list.add(input.nextInt());
    }

    saveDuplicate(list);
    System.out.print("The same integers are: ");
    for (int i = 0; i < list.size(); i++)
      System.out.print(list.get(i) + " ");
  }

  public static void saveDuplicate(ArrayList<Integer> list) {
    ArrayList<Integer> temp = new ArrayList<Integer>();
    Integer tempInt;
    for (int i = 0; i < list.size();) {
      tempInt = list.remove(i);
      if (list.contains(tempInt))
        temp.add(tempInt);
      else if (temp.contains(tempInt))
        temp.add(tempInt);
    }

    list.clear();
    for (int i = 0; i < temp.size(); i++)
      list.add(temp.get(i));
  }
}