import java.util.Scanner;

public class Exercise05_01 {
  public static void main(String[] args) {
    int num;

    while (true) {
    	Scanner input = new Scanner(System.in);
        System.out.print("Enter your score: ");
        num = input.nextInt();
        if (num == -1)
    	    break;
        else if(num >= 60){
    	    System.out.println("You pass the exam.");
        }
	        else{
	            System.out.println("You don't pass the exam.");
	        }

        }

    }
}
