
public class Exercise05_50 {

	public static void main(String[] args) {
		System.out.println("for-loop version");
		for(int a = 1; a <= 9; a++){
			for(int b = 1 ; b <= 9; b++){
				System.out.printf("%d*%d=%2d  ", b, a, a*b);
			}
			System.out.println();
		}
		
		System.out.println();
		System.out.println("while-loop verion");
		int a = 0, b = 0;
		while(a < 9){
			a++;
			while(b < 9){
				b++;
				System.out.printf("%d*%d=%2d  ", b, a, a*b);
			}
			System.out.println();
			b = 0;
		}
		
		System.out.println();
		System.out.println("do-while-loop version");
		int c = 0, d = 0;
		do{
			c++;
			do{
				d++;
				System.out.printf("%d*%d=%2d  ", d, c, c*d);
			}while(d < 9);
			System.out.println();
			d = 0;
		}while(c < 9);

	}

}
