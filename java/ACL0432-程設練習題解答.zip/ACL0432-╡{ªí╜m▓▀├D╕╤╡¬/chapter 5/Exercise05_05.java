public class Exercise05_05 {
  public static void main(String[] args) {
    System.out.printf("%10s%10s  |  %10s%10s\n", "Celsius", "  Fahrenheit",
        "Fahrenheit", "Celsius");
    System.out.println("---------------------------------------------");
                            
    // Use while loop
    int celsius = 0;
    int fahrenheit = 20;
    int count = 0;
    while (count <= 50) {
      System.out.printf("%10d%10.3f    |  %10d%10.3f\n", celsius, celsius * 9/5. + 32, fahrenheit, (fahrenheit -32) *5/9.);
      celsius += 2;
      fahrenheit += 5;
      count++;
    }

    
  }
}
