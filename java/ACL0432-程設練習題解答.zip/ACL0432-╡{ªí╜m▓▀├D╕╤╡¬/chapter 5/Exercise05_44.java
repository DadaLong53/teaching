import java.util.Scanner;

public class Exercise05_44 { 
  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    System.out.print("Enter an integer: ");
    byte value = input.nextByte();
    
    System.out.print("The 8 bits are ");
    byte mask = 1;
    for (int i = 7; i >= 0; i--) {
      byte temp = (byte) (value >> i);
      byte bit = (byte) (temp & mask);
      System.out.print(bit);
    }
  }
}
