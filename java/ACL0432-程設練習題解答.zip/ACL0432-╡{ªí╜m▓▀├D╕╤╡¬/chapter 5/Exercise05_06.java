public class Exercise05_06 {
  public static void main(String[] args) {
    System.out.printf("%15s%15s    |  %15s%15s\n", "Ping", "Square meter",
        "Square meter", "Ping");
    System.out.println("--------------------------------------------------------------------");

    // Use while loop
    int ping = 10;
    int squareMeter = 30;
    int count = 0;
    while (count <= 14) {
      System.out.printf("%15d%15.3f    |  %15d%15.3f\n", ping, ping * 3.305,
    		  squareMeter, squareMeter / 3.305);
      ping += 5;
      squareMeter += 5;
      count++;
    }

    /*
     * Use for loop int miles = 1; int kilometers = 20; for (int count = 1;
     * count <= 10; miles++, kilometers += 5, count++) {
     * System.out.printf("%10d%10.3f    |  %10d%10.3f\n", miles, miles * 1.609,
     * kilometers, kilometers / 1.609); }
     */
  }
}
