public class Exercise05_04 {
  public static void main(String[] args) {
    System.out.println("Inch\t\tCentimeter");
    System.out.println("-------------------------------");

    // Use while loop
    int inch = 1; 
    while (inch <= 10) {
      System.out.println(inch + "\t\t\t" + inch * 2.54);
      inch++;
    }
   
/** Alternatively use for loop    
    for (int inch = 1; inch <= 10; inch++) {
      System.out.println(inch + "\t\t\t" + inch * 2.54);
    }
*/
  }
}
