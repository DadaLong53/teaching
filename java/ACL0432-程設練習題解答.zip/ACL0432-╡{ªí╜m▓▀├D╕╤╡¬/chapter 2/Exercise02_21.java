public class Exercise02_21 {
  // Main method
  public static void main(String[] args) {
    java.util.Scanner input = new java.util.Scanner(System.in);
    // Receive the amount entered from the keyboard
    System.out.print(
      "Enter the number of a1, d and n in Arithmetic progression: ");
    double a1 = input.nextDouble();

    double d = input.nextDouble();

    int n = input.nextInt();

    // Find the number of an
    double an = a1 + (n-1) * d;
    

    // Display results
    System.out.println("Your a1 and d is " + a1 + " and " + d);
    System.out.println("Difference in Arithmetic progression is " + d);
    System.out.println("a" + n + " is " + an);

  }
}
