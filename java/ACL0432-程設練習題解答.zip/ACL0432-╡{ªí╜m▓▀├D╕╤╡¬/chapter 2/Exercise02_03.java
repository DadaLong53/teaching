public class Exercise02_03 {
  public static void main(String[] args) {
    // Enter meter
    java.util.Scanner input = new java.util.Scanner(System.in);
    System.out.print("Enter a value for meter: ");
    double meter = input.nextDouble();

    double feet = meter * 3.2786;

    System.out.println(meter + " meter is " + feet + " feet");
  }
}
