import java.util.Scanner;

public class Exercise02_22 {
  public static void main(String args[]) {
    Scanner input = new Scanner(System.in);
    System.out.print("Enter the a1: ");
    double a1 = input.nextDouble();
    
    System.out.print("Enter the n : ");
    int n = input.nextInt();
    
    System.out.print("Enter the d: ");
    double difference = input.nextDouble();

    double an = a1 + (n-1) * difference;

    System.out.println("The sum of all terms from a1 to a" + 
        n + " is " + n * (a1 + an) / 2);
  }
}
