public class Exercise02_18 {
  // Main method
  public static void main(String[] args) {
    System.out.println("a         b        Middle Point");
    System.out.println("(0, 0)   (2, 1)    (" + (double)(0+2)/2 + ", " + (double)(0+1)/2 + ")");
    System.out.println("(1, 4)   (4, 2)    (" + (double)(1+4)/2 + ", " + (double)(4+2)/2 + ")");
    System.out.println("(2, 7)   (6, 3)    (" + (double)(2+6)/2 + ", " + (double)(7+3)/2 + ")");
    System.out.println("(3, 9)   (10, 5)   (" + (double)(3+10)/2 + ", " + (double)(9+5)/2 + ")");
    System.out.println("(4, 11)  (12, 7)   (" + (double)(4+12)/2 + ", " + (double)(11+7)/2 + ")");
  }
}
