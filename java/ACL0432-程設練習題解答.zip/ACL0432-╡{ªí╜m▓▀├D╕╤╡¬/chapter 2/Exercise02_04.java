public class Exercise02_04 {
  public static void main(String[] args) {
    // Prompt the input
    java.util.Scanner input = new java.util.Scanner(System.in);
    System.out.print("Enter a number in square meters: ");
    double square_meters = input.nextDouble();
    double ping = square_meters * 0.3025;

    System.out.println(square_meters + " square meters is " + ping + " pings");
  }
}
