public class Exercise18_04 {
  public static void main(String[] args) {
    for (int i = 0; i <= 10; i++)
      System.out.println(m(i));
  }

  public static double m(int i) {
    if (i == 0)
      return 1;
    else
      return  1.0 / (2 * i);
  }
}
