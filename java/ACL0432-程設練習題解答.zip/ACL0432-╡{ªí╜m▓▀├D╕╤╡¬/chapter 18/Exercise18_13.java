import java.util.Scanner;

public class Exercise18_13 {
  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    System.out.print("Enter 8 integers: ");
    
    int[] list = new int[8];
    for (int i = 0; i < list.length; i++)
      list[i] = input.nextInt();
    
    System.out.println(smallest(list));
  }

  public static int smallest(int[] list) {
    return smallest(list, list.length - 1);
  }

  public static int smallest(int[] list, int high) {
    if (high == 0) {
      return list[0];
    }
    else {
      return Math.min(smallest(list, high - 1), list[high]);
    }
  }
}
