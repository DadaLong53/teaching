import java.util.Scanner;

public class Exercise18_14 {
  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    System.out.print("Enter a string: ");
    String s = input.nextLine();
    System.out.println("The lowercase letters in " + s + " is " + countLowercase(s));
  }

  public static int countLowercase(String str) {
    return countLowercase(str, str.length() - 1);
  }

  public static int countLowercase(String str, int high) {
    if (high < 0)
      return 0;
    else
      return countLowercase(str, high - 1) +
        (Character.isLowerCase(str.charAt(high)) ? 1 : 0);
  }
}
