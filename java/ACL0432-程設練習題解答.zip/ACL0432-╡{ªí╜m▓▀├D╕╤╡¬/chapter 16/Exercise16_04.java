import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class Exercise16_04 extends Application {
  private double paneWidth = 250;
  private double paneHeight = 60;

  @Override // Override the start method in the Application class
  public void start(Stage primaryStage) {
    TextField celsius = new TextField();
    TextField fahrenheit = new TextField();
    celsius.setAlignment(Pos.BOTTOM_RIGHT);
    fahrenheit.setAlignment(Pos.BOTTOM_RIGHT);

    GridPane pane = new GridPane();
    pane.setAlignment(Pos.CENTER);
    pane.add(new Label("Celsius"), 0, 0);
    pane.add(celsius, 1, 0);
    pane.add(new Label("Fahrenheit"), 0, 1);
    pane.add(fahrenheit, 1, 1);

    // Create a scene and place it in the stage
    Scene scene = new Scene(pane, paneWidth, paneHeight);
    primaryStage.setTitle("Exercise16_04"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.show(); // Display the stage

    celsius.setOnAction(e -> {
      double cel = new Double(celsius.getText().trim()).doubleValue();
      double fah = (9 *cel)/5 + 32 ;
      fahrenheit.setText(new Double(fah).toString());
    });

    fahrenheit.setOnAction(e -> {
      double fah = new Double(fahrenheit.getText().trim()).doubleValue();
      double cel = (fah-32) *5/9;
      celsius.setText(new Double(cel).toString());
    });
  }

  /**
   * The main method is only needed for the IDE with limited
   * JavaFX support. Not needed for running from the command line.
   */
  public static void main(String[] args) {
    launch(args);
  }
}
