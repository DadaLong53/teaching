public class Exercise03_35 {
  public static void main(String[] args) {
    java.util.Scanner input = new java.util.Scanner(System.in);

    // Enter a number
    System.out.print("Enter an integer: ");
    int number = input.nextInt();
    
    if (number % 2 == 0) {
      System.out.println(number + " is even number");
    }
    
    if (number % 2 != 0) {
      System.out.println(number + " is odd number");
    }
   
  }
}
