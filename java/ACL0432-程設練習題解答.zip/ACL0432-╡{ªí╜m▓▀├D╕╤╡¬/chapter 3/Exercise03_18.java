import java.util.Scanner;

public class Exercise03_18 {
  public static void main(String args[]) {
    Scanner input = new Scanner(System.in);
    System.out.print("Enter package weight: ");
    double w = input.nextDouble();
    
    if (w <= 2) {
      System.out.println("The shipping cost is $2.5");
    }
    else if (w <= 4) {
      System.out.println("The shipping cost is $4.5");
    }     
    else if (w <= 10) {
      System.out.println("The shipping cost is $7.5");
    }     
    else if (w <= 20) {
      System.out.println("The shipping cost is $10.5");
    }     
    else {
      System.out.println("The package cannot be shipped");
    }
  }
}
