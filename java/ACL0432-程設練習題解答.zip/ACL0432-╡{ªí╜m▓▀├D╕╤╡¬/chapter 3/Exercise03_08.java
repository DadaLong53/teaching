
public class Exercise03_08 {

	public static void main(String[] args) {
		
		java.util.Scanner input = new java.util.Scanner(System.in);
		System.out.print("Enter three intergers: ");
		
		int a = input.nextInt();
		int b = input.nextInt();
		int c = input.nextInt();
		int temp = 0;
		
		if(b > a){
			temp = a;
			a = b ;
			b = temp;
		}
		if(c > b){
			temp = b;;
			b = c ;
			c = temp;
		}
		if(b > a){
			temp = a;
			a = b ;
			b = temp;
		}
		System.out.println("The integers in decreasing order is " + a +", " + b + ", " + c + ".");

	}

}
