public class Exercise03_16 {
  public static void main(String[] args) {
    double x = Math.random() * 50 - 25;
    double y = Math.random() * 150 - 75;
    
    System.out.println(x + ", " + y);
  }
}
