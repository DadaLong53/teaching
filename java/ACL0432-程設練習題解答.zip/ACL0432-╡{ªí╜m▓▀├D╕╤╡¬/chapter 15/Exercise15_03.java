import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public class Exercise15_03 extends Application {
  @Override
  // Override the start method in the Application class
  public void start(Stage primaryStage) {
    Pane pane = new Pane();
    Rectangle rectangle = new Rectangle(40, 50, 30, 30);
    rectangle.setFill(Color.WHITE);
    rectangle.setStroke(Color.BLACK);
    pane.getChildren().add(rectangle);
    
    // Create four buttons
    HBox hBox = new HBox(5);
    Button btLeft = new Button("Left");
    Button btRight = new Button("Right");
    Button btUp = new Button("Up");
    Button btDown = new Button("Down");
    hBox.setAlignment(Pos.CENTER);
    hBox.getChildren().addAll(btLeft, btRight, btUp, btDown);
    
    BorderPane borderPane = new BorderPane();
    borderPane.setCenter(pane);
    borderPane.setBottom(hBox);
    BorderPane.setAlignment(hBox, Pos.TOP_CENTER);

    // Create a scene and place it in the stage
    Scene scene = new Scene(borderPane, 200, 150);
    primaryStage.setTitle("Exercise15_03"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.show(); // Display the stage
    
    btLeft.setOnAction(e -> {
    	rectangle.setX(rectangle.getX() > 0 ? rectangle.getX() - 2 : 0);
    });

    btRight.setOnAction(e -> {
    	rectangle.setX(rectangle.getX() < scene.getWidth() ? rectangle.getX() + 2 : 0);
    });

    btUp.setOnAction(e -> {
    	rectangle.setY(rectangle.getY() > 0 ? rectangle.getY() - 2 : 0);
    });

    btDown.setOnAction(e -> {
    	rectangle.setY(rectangle.getY() < scene.getHeight() ? rectangle.getY() + 2 : 0);
    });
    

  }
  
  /**
   * The main method is only needed for the IDE with limited
   * JavaFX support. Not needed for running from the command line.
   */
  public static void main(String[] args) {
    launch(args);
  }
} 
