import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.geometry.HPos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class Exercise15_05 extends Application {
  private TextField initialvelocit = new TextField();
  private TextField acceleration = new TextField();
  private TextField time = new TextField();
  private TextField finalvelocity = new TextField();
  private Button btCalculate = new Button("Calculate");
  
  @Override // Override the start method in the Application class
  public void start(Stage primaryStage) {
    // Create UI
    GridPane gridPane = new GridPane();
    gridPane.setHgap(5);
    gridPane.setVgap(5);
    gridPane.add(new Label("Initial velocity:"), 0, 0);
    gridPane.add(initialvelocit, 1, 0);
    gridPane.add(new Label("Acceleration:"), 0, 1);
    gridPane.add(acceleration, 1, 1);
    gridPane.add(new Label("Time:"), 0, 2);
    gridPane.add(time, 1, 2);
    gridPane.add(new Label("Final velocity:"), 0, 3);
    gridPane.add(finalvelocity, 1, 3);
    gridPane.add(btCalculate, 1, 4);

    // Set properties for UI
    gridPane.setAlignment(Pos.CENTER);
    time.setAlignment(Pos.BOTTOM_RIGHT);
    acceleration.setAlignment(Pos.BOTTOM_RIGHT);
    initialvelocit.setAlignment(Pos.BOTTOM_RIGHT);
    finalvelocity.setAlignment(Pos.BOTTOM_RIGHT);
    finalvelocity.setEditable(false);
    GridPane.setHalignment(btCalculate, HPos.RIGHT);

    // Process events
    btCalculate.setOnAction(e -> calculateLoanPayment());

    // Create a scene and place it in the stage
    Scene scene = new Scene(gridPane, 260, 150);
    primaryStage.setTitle("Exercise15_05"); // Set title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.show(); // Display the stage
  }
  
  private void calculateLoanPayment() {
    // Get values from text fields
    double tim =
      Double.parseDouble(time.getText());
    int acce = Integer.parseInt(acceleration.getText());
    double initialt =
      Double.parseDouble(initialvelocit.getText());
    double fv = initialt + acce *tim;
/*
    double monthlyInterestRate = annualInterestRate / 1200;
    double futureValue = investmentAmount * 
        Math.pow(1 + monthlyInterestRate, numberOfYears * 12);
*/
    // Display monthly payment and total payment
    finalvelocity.setText(String.format("%.2f", fv));
  }
  
  /**
   * The main method is only needed for the IDE with limited
   * JavaFX support. Not needed for running from the command line.
   */
  public static void main(String[] args) {
    launch(args);
  }
}
