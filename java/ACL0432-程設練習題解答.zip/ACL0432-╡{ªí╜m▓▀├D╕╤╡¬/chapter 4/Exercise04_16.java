public class Exercise04_16 {
  public static void main(String args[]) {
    char ch = (char)(Math.random() * 26 + 'a');
    System.out.println("A random lowercase letter is " + ch);
  }
}