public class Exercise04_08 {
  public static void main(String args[]) {
    java.util.Scanner input = new java.util.Scanner(System.in);

    // Enter an ASCII code
    System.out.print("Enter a character: ");
    char code = input.next().charAt(0);

    // Display result
    System.out.println("The ASCII code for character "
      + code + " is " + (int)code);
  }
}
