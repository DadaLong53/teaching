import java.util.Scanner;

public class Exercise04_11 {
  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    System.out.print("Enter a binary value (0000 to 1111): ");

    String binary = input.nextLine();
    String test = binary.replace("1", "").replace("0", "");
    if (test.trim().length() != 0 && binary.length() != 4)
        System.out.println(binary + " is an invalid input");
    else
        System.out.println("The decimal value is " + Integer.parseInt(binary, 2));
  }
}

