import java.util.Scanner;

public class Exercise07_03 {
  public static void main (String[] args) {
    Scanner input = new Scanner(System.in);
    int[] counts = new int[50];
    
    System.out.print("Enter the integers between 1 and 50: ");
    
    // Read all numbers
    int number = input.nextInt(); // number read from a file
    while (number != 0) {
      if (number <= 50 && number > 0)
        counts[number - 1]++;
      number = input.nextInt(); 
    }

    // Display result
    for (int i = 0; i < 50; i++) {
      if (counts[i] > 0)
        System.out.println((i + 1) + " occurs " + counts[i]
          + ((counts[i] == 1) ? " time" : " times"));
    }
  }
}
