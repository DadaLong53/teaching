import java.util.Scanner;

public class Exercise06_41 {
	private static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		
		while(true){
			System.out.print("Enter your weight(kg): ");
			double weight = sc.nextDouble();
			if(weight == -1){
				System.out.print("Over !");
				break;
			}
			System.out.print("Enter your height(m): ");
			double height = sc.nextDouble();
			
			
			
			bmi(weight,height);
		}
		
		
	}
	public static void bmi(double weight, double height){
		System.out.printf("Your BMI is %.3f\n\n", weight/Math.pow(height, 2));
		
	}

}