import java.util.Scanner;

public class Exercise06_40 {
	private static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		
		System.out.print("Enter a year: ");
		int input = 0; 
		while ((input = sc.nextInt()) != -1) {
			leap(input);
			System.out.print("Enter a year: ");
		}
		
	}
	public static void leap(int input){
		if ((input % 4 == 0 && input % 100 != 0) || input % 400 == 0) {
			System.out.println(input + " is leap year.");
			
		} else {
			System.out.println(input + " is not leap year.");
		}
		
	}

}