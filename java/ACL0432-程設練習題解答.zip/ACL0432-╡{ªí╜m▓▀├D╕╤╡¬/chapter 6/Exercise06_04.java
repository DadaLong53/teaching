public class Exercise06_04 {
  public static void main(String[] args) {
    System.out.print("Enter an integer: ");
    java.util.Scanner input = new java.util.Scanner(System.in);
    int number1 = input.nextInt();
    int number2 = input.nextInt();
    GCD(number1, number2);
  }

  public static void GCD(int num1, int num2) {
	if (num1 < num2) {
    	int temp = num1;
    	num1 = num2;
    	num2 = temp;
	}
    while (num2 >= 1) {
    	int temp = num1 % num2;
    	num1 = num2;
    	num2 = temp;
    }

    System.out.println(num1);
  }
}
