public class Exercise06_12 {
  public static void main(String[] args) {
      printChars(1, 100, 10);
  }

  public static void printChars(int num1, int num2, int numberPerLine) {
      int count = 1;
      for (int i = num1; i <= num2; i++, count++)
        if (count % numberPerLine == 0)
          System.out.printf("%3d\n", i);
        else
          System.out.printf("%3d ", i);
  }
}
