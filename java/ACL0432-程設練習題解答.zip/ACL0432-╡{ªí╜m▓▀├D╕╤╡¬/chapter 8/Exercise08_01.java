import java.util.Scanner;

public class Exercise08_01 {
  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    
    System.out.print("Enter a 3 by 4 matrix row by row: ");
    double[][] m = new double[3][4];
    
    for (int i = 0; i < m.length; i++)
      for (int j = 0; j < m[i].length; j++)
        m[i][j] = input.nextDouble();

    for (int j = 0; j < m.length; j++) {
      System.out.println("Sum of the elements at row " + j + " is " + 
        sumRow(m, j));      
    } 
  }
  
  public static double sumRow(double[][] m, int rowIndex) {
    double total = 0;
    
    for (int i = 0; i < m[rowIndex].length; i++)
      total += m[rowIndex][i];
    
    return total;
  }  
}
